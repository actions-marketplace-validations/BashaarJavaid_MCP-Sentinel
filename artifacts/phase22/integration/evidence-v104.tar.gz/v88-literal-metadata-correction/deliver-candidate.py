"""Deliver the authorized correction to the existing draft for normal CI."""
import hashlib,json,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent;BASE=OUT.parent;ROOT=OUT.parents[3]
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=lambda *args:subprocess.check_output(args,cwd=ROOT,text=True,stderr=subprocess.STDOUT,timeout=180)
def save(name,value):
 with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def pr():return json.loads(run('gh','pr','view','37','--json','number,state,isDraft,headRefName,headRefOid,baseRefName,title,body'))
def guard(p):assert p['number']==37 and p['state']=='OPEN' and p['isDraft'] and p['headRefName']=='phase22/integration' and p['baseRefName']=='phase22/description-poisoning'
c=read(OUT/'candidate-commit.json');intake=read(OUT/'intake.json');head=c['source']
assert run('git','rev-parse','HEAD').strip()==head and not run('git','diff','HEAD')
for name,d in c['candidate_engineering_files_sha256'].items():assert sha(ROOT/name)==d,name
for name,d in intake['protected_user_files_sha256'].items():assert sha(ROOT/name)==d,name
current=pr();guard(current)
assert current==intake['pr']
assert run('gh','api','repos/BashaarJavaid/MCP-Sentinel/branches/phase22/integration','--jq','.commit.sha').strip()==intake['baseline_delivery']
save('candidate-pre-pr37.json',current)
body=f'''Candidate `{head}` permits source-proved literal dictionary metadata copies in the existing Python module-table recognizer. Dynamic mappings, aliases, mutations, shadowed constructors and visible builtin namespace replacements remain unsupported. The first synthetic attempt missed direct `del dict`; its 1-failure/141-pass result and correction are retained. All 513 focused tests, lint, formatting and strict typing pass. Full local and hosted engineering and six zero-call production request replays are pending actual completion.

The separately approved V87 exposed regression at `884d376` is complete: 111 observations on 63 input records, all 48 entire ordered pairs equal, verified cleanup and closed budget. Taskwarrior, Lightning, Engram and prior Python narrow conditions retain their qualifications. Two nominal-fixed Meta operator errata remain. Proxmox still misses both vulnerable reads and has four unsupported negatives: literal metadata dictionary copies prevent discovery of the entire dispatch table. All 3,959 findings, 343,791 diagnostic occurrences, 5,686 surfaces and complete ordered differences are source-assessed; 101 reports equal prior references and 10 Meta reports have 268 assessed changed occurrences. Raw findings and every original failure remain unchanged.

The current source correction continues the authorized bounded ordinary correctness work. It has no actual corpus result yet. Any new numerical regression requires a separately delivered exact proposal and approval. No new repositories, retries, profiles, performance attempts, target execution or paid calls are authorized. The previous 111-observation budget is closed and cannot be reused.

All 463 existing requirements and 26 unaccepted limitations remain preserved; added rows will be reconciled against actual evidence. Normal FAF completion within 1,800 seconds remains unestablished; V68 is unapproved and unimplemented. Git remains 312/1,040 incomplete with 728 deferred; paid benchmark/pilots are deferred, Phase 21 incomplete, and Phase 24/15 unchanged. Historical spend is $0.071799; zero new paid calls.

Phase 22 remains incomplete pending current-source gates, updated review, separate explicit human technical acceptance and verified accepted-closeout delivery. This remains the existing OPEN DRAFT PR; no merge, ready-state change, release, outreach or Phase 23 is authorized.
'''
title='Phase 22: literal metadata correction; engineering in progress'
with (OUT/'candidate-pr-body.md').open('x') as f:f.write(body)
save('candidate-metadata-update.json',{'title':title,'body':body})
print(run('git','push','https://github.com/BashaarJavaid/MCP-Sentinel.git','HEAD:refs/heads/phase22/integration'),flush=True)
response=json.loads(run('gh','api','--method','PATCH','repos/BashaarJavaid/MCP-Sentinel/pulls/37','--input',str(OUT/'candidate-metadata-update.json'),'--jq','{number,state,draft,title,head:.head.sha,base:.base.ref}'));save('candidate-patch-response.json',response)
history=[]
for attempt in range(12):
 current=pr();guard(current);branch=run('gh','api','repos/BashaarJavaid/MCP-Sentinel/branches/phase22/integration','--jq','.commit.sha').strip();history.append({'pr':current,'branch':branch})
 if current['headRefOid']==branch==head and current['title']==title and current['body']==body:break
 time.sleep(5)
else:
 save('candidate-readback-history.json',history);raise AssertionError('Retain writes and verify by reads only; never rerun mutation.')
save('candidate-readback-history.json',history)
save('candidate-delivery.json',{'passed':True,'head':head,'recorded_at':datetime.now(timezone.utc).isoformat(),'pr':current,'body_sha256':sha(OUT/'candidate-pr-body.md'),'paid_calls':0,'engineering':'pending','technical_acceptance_received':False})
print('Exact candidate draft delivery verified.',head,flush=True)
