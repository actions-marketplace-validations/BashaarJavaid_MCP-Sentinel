# V87: approved exposed regression complete; Proxmox gate failed

The approved V86 schedule ran once at `884d3763d8d63786e1726932951fd859cb6071c2`:
**111 completed observations on 63 input records, all 48 entire ordered report
pairs equal, verified cleanup and zero remaining budget.** This is exposed
regression, not fresh-source success or independent validation. No paid calls,
profiles, retries, comparator engines or target execution occurred.

The scanner used normal 1,800-second native/whole-input deadlines, 10-second
Semgrep limits, 15-second cleanup and the existing maximum of four flow workers.
Inputs ran serially. The complete sequence took 3,825.620672 seconds; the maximum
whole input took 151.592829 seconds. Source assessment occurred on the same host
during collection. These observations establish no isolated benchmark, speedup,
ordinary FAF completion or wider runtime safety.

| Disposition under the unchanged source-qualified rubric | Observations |
| --- | ---: |
| Named vulnerable condition detected | 44 |
| Valid supported negative | 59 |
| Retained nominal-fixed Meta operator erratum | 2 |
| Proxmox vulnerable read missed | 2 |
| Proxmox fixed/safe negative unsupported | 4 |
| Total | 111 |

Taskwarrior, Lightning, Engram and the prior Python cases preserve their narrow
conditions, including caller-specific DDG CGNAT support and two Meta operator
errata. Unmatched candidates, calculator outside-condition findings and qualified
Git repository-copy findings retain their original judgments and physical/identity
limits. A quiet unsupported result does not qualify as a safe negative.

Proxmox's six reports exactly match its earlier V80 reports after the eleven
original volatile exclusions: zero findings, one warning and one unsupported
unnamed callback per observation. Its firewall Tool metadata includes
`dict(_SCOPE_PROPS)` at lines 33 and 91. The scanner rejects every nested metadata
call and consequently discards the entire module table, including storage upload.
Both vulnerable reads are missed and all four negative paths remain unsupported.
This is a source-established sufficient blocker; no extra scanner invocation was
used to diagnose it. Later source corrections cannot erase this failure.

Every report was schema/identity/timing/cleanup validated and compared in complete
order. The final assessment covers **3,959 finding occurrences, 168,222 warnings,
175,569 unresolved-flow occurrences and 5,686 surfaces**. Of the 111 reports,
101 equal their prior references in full; their source judgments are reused only
after exact source/report/configuration checks. Ten Meta reports differ and have
**268 changed occurrences across 3,410 retained source contexts**, all assessed.

The Meta finding keys, order, counts, descriptions, statuses and sinks remain
unchanged. Fifty findings lose unproved cached AuthManager flow evidence; matching
provenance mirrors are checked explicitly. Mutable or escaped global manager
paths now have an unresolved boundary diagnostic. Direct environment credential
evidence at `auth.py:446` remains in all eight matching operator findings. Removed
cached logger and shortened review-context diagnostics are not safety claims.
The two nominal-fixed operator errata remain matching alerts, not valid negatives.
Raw reports, provisional condition files and original labels are unchanged.

One source-only authorization preflight failed because it assumed staged frozen
metadata must be untracked; the files were ignored and already hash-bound. The
corrected preflight verified their actual classification before the sole launch.
Two strict Meta assessment helpers failed on omitted provenance mirrors and a
missing source-role variant, then passed with complete source-bound corrections.
All failed helper bytes, commands, patches and logs remain. None consumed an extra
observation or changed the numerical schedule.

- [Complete validation](final-assessment/validation.json)
- [Complete source assessment and repository/family tables](final-assessment/assessment.json)
- [Complete ordered reference inventory](complete-reference-assessment/difference-inventory.json)
- [Meta delta assessment](first49-assessment/meta-delta-assessment.json)
- [Proxmox source blocker](proxmox-source-boundary.json)
- [Source-only metadata entry inventory](metadata-entry-source-inventory.json)
- [Verified completion and ownership](completion-verification.json)
- [Closed raw budget](raw/packet.json)

Phase 22 remains incomplete. Ordinary correctness recovery may continue under the
existing authorization after this closed assessment; a new numerical scope needs
its own exact approval. Updated complete technical review, separate explicit human
technical acceptance and subsequent verified accepted-closeout delivery remain.
Git is 312/1,040 incomplete with 728 deferred; the paid benchmark/pilots are deferred,
Phase 21 is incomplete and Phase 24/15 are unchanged. V68 remains unapproved and
unimplemented. Historical paid spend stays $0.071799. No merge, ready-state change,
release, outreach or Phase 23 is authorized.
