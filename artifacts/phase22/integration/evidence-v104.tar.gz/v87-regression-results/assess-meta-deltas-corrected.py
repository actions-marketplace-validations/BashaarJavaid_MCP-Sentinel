"""Assess the complete observed Meta deltas without another scanner invocation."""
import collections,copy,hashlib,importlib.util,json,sys
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3];BASE=OUT.parent;PREP=BASE/'v86-regression-preparation';DEST=OUT/'first49-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase20_scoring import candidate_identity,score
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();inv=read(DEST/'difference-inventory.json');equal=read(DEST/'assessment.json');prior_path=BASE/'v75-prior-language-results/final-assessment/assessment.json';prior=read(prior_path);source=read(OUT/'meta-source-review.json');pending=equal['pending_changed_reports'];assert len(pending)==10
roles={
 ('meta_ads_mcp/core/auth.py',118):'Cached TokenInfo construction reads an access_token dictionary field.',
 ('meta_ads_mcp/core/auth.py',119):'Cached TokenInfo construction reads an expires_in dictionary field.',
 ('meta_ads_mcp/core/auth.py',120):'Cached TokenInfo construction reads a user_id dictionary field.',
 ('meta_ads_mcp/core/auth.py',122):'Cached token created_at is restored from its dictionary.',
 ('meta_ads_mcp/core/auth.py',133):'AuthManager initialization records whether the operator configured a Pipeboard token.',
 ('meta_ads_mcp/core/auth.py',287):'Mutable manager chooses its Pipeboard branch.',
 ('meta_ads_mcp/core/auth.py',288):'Mutable manager delegates cached credential acquisition to pipeboard_auth_manager.',
 ('meta_ads_mcp/core/auth.py',298):'Mutable manager chooses a Pipeboard invalidation branch.',
 ('meta_ads_mcp/core/auth.py',460):'Post-environment-token fallback reads configured app_id.',
 ('meta_ads_mcp/core/auth.py',467):'Post-environment-token fallback checks configured app_id and Pipeboard mode.',
 ('meta_ads_mcp/core/auth.py',476):'Post-environment-token fallback checks the token returned by the mutable manager.',
 ('meta_ads_mcp/core/auth.py',564):'Module initializes an operator app ID before constructing AuthManager.',
 ('meta_ads_mcp/core/auth.py',567):'Global AuthManager construction is now conservative because included source declares it global and mutates token_info. This is uncertainty, not a proved exploit or safe cached credential path.',
 ('meta_ads_mcp/core/pipeboard_auth.py',385):'Pipeboard cache/response token construction reads access_token.',
 ('meta_ads_mcp/core/api.py',400):'Missing-token fallback consults mutable manager app_id/Pipeboard configuration.',
 ('meta_ads_mcp/core/api.py',403):'Missing-token fallback branches on mutable manager Pipeboard configuration.',
 ('meta_ads_mcp/core/api.py',345):'Same missing-token manager app_id/Pipeboard branch at this earlier upstream revision.',
 ('meta_ads_mcp/core/api.py',348):'Same missing-token manager Pipeboard branch at this earlier upstream revision.',
}
rows=[];flow_deltas=[];context_roles={};occurrences=[];diagnostic_kinds=collections.Counter()
allowed_logs={('meta_ads_mcp/core/pipeboard_auth.py',333,'info'),('meta_ads_mcp/core/pipeboard_auth.py',139,'debug'),('meta_ads_mcp/core/pipeboard_auth.py',424,'info'),('meta_ads_mcp/core/pipeboard_auth.py',426,'debug'),('meta_ads_mcp/core/auth.py',315,'info')}
for item in pending:
 input_id=item['input_id'];assert input_id.startswith('meta-') and item['group']=='py-development'
 original=next(x for x in prior['rows'] if x['input_id']==input_id and x['report_sha256']==item['reference_report_sha256'])
 before=r.supervisor.clean(read(ROOT/item['reference_report']),r.prior.EXCLUDED);after=r.supervisor.clean(read(ROOT/item['current_report']),r.prior.EXCLUDED)
 assert set(item['changed_paths'])=={'findings','warnings','static_analysis/coverage/unresolved_flows'}
 assert [f['dedup_key'] for f in before['findings']]==[f['dedup_key'] for f in after['findings']]
 tree=item['source_tree_sha256'];sources=source['rows'][tree]['files'];auth=sources['meta_ads_mcp/core/auth.py']['source'].splitlines()
 assert auth[338].strip()=='auth_manager.token_info = long_lived_token_info' and auth[361].strip()=='auth_manager.token_info = token_info'
 assert auth[455].strip()=='global auth_manager' and auth[566].strip()=='auth_manager = AuthManager(META_APP_ID)'
 # The frozen environment credential path returns before consulting the mutable singleton.
 assert 'os.environ.get("META_ACCESS_TOKEN")' in auth[445]
 assert any('return env_token' in s or 'return phase22OperatorToken' in s for s in auth[446:454])
 changed=[]
 for left,right in zip(before['findings'],after['findings'],strict=True):
  if left==right:continue
  old=left['evidence']['flow_locations'];new=right['evidence']['flow_locations'];copy_left=copy.deepcopy(left);copy_left['evidence']['flow_locations']=new
  assert len(left['provenance'])==len(right['provenance'])==1
  assert left['provenance'][0]['evidence']==left['evidence'] and right['provenance'][0]['evidence']==right['evidence']
  copy_left['provenance'][0]['evidence']['flow_locations']=new
  assert copy_left==right
  serial=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'))
  old_serial=list(map(serial,old));new_serial=list(map(serial,new));assert len(set(old_serial))==len(old_serial) and len(set(new_serial))==len(new_serial)
  assert set(new_serial).issubset(old_serial) and [x for x in old_serial if x in set(new_serial)]==new_serial
  removed=[]
  for loc in old:
   if serial(loc) in set(new_serial):continue
   key=(loc['path'],loc['range']['start_line']);assert key in roles,key
   source_file=sources[key[0]];assert source_file['sha256']==inv['source_file_bindings'][tree][key[0]]
   context=f'{tree}:{key[0]}:{key[1]}';assert context in inv['contexts'];context_roles[context]=roles[key]
   removed.append({'location':loc,'context':context,'source_assessment':roles[key]})
  changed.append(left['dedup_key']);flow_deltas.append({'input_id':input_id,'dedup_key':left['dedup_key'],'rule_id':left['rule_id'],'sink':left['location'],'removed_flow_locations':removed,'remaining_order_preserved':True,'all_other_finding_fields_equal':True,'provenance_evidence_mirror_equal':True,'assessment':'Conservative global receiver handling no longer traverses cached mutable AuthManager paths. All candidate keys, descriptions, statuses, sinks and remaining ordered flow evidence are unchanged. Environment credential selection precedes this fallback; image literal-host guards and their request paths are outside these removed auth/cache locations. Unmatched candidates remain needs_review; shorter traces do not prove cache/credential/URL safety.'})
 refreshed={**original['source_assessment'],'candidate_identity':candidate_identity(read(ROOT/item['current_report'])['findings']),'rationale':original['source_assessment']['rationale']+' Current884d376 identity refreshed only after complete ordered report/finding/diagnostic/source assessment. Cached mutable AuthManager flow locations are removed and explicit unknown-global diagnostics added; direct operator environment selection and the initial literal-private URL condition remain unchanged. No broad cached-credential or URL safety is inferred.'}
 actual_score=score(label=original['label'],state='completed',findings=read(ROOT/item['current_report'])['findings'],assessment=refreshed);assert actual_score==original['score']
 erratum=original.get('approved_meta_operator_erratum',False)
 passed=actual_score['candidate_detected'] if original['label']=='vulnerable' else (actual_score['false_alarm'] is False or bool(erratum))
 assert passed
 if erratum:assert input_id in ['meta-operator-fallback-fixed','meta-operator-fallback-fixed-mutation'] and len(actual_score['matched_keys'])==2
 rows.append({'input_id':input_id,'group':item['group'],'batch':item['batch'],'label':original['label'],'report_sha256':item['current_report_sha256'],'reference_report_sha256':item['reference_report_sha256'],'source_tree_sha256':tree,'source_assessment':refreshed,'score':actual_score,'condition_passed':True,'condition_disposition':'retained_nominal_fixed_operator_erratum' if erratum else ('vulnerable_detected' if original['label']=='vulnerable' else 'valid_supported_negative'),'retained_nominal_fixed_operator_erratum':erratum,'changed_finding_keys':changed,'previous_complete_source_assessment':original,'prior_assessment_sha256':sha(prior_path),'qualification':'Narrow image private-literal qualification and direct operator environment condition retained. Unknown mutable/cached AuthManager paths are explicitly unsupported; original nominal-fixed errata remain errata.'})
for item in inv['changed_occurrences']:
 entry=item['entry'];keys=item['contexts'];assessment=''
 if item['kind']=='finding':
  assert any(d['input_id']==item['input_id'] and d['dedup_key']==entry['dedup_key'] for d in flow_deltas)
  assessment='Complete old/new finding pair assessed in finding_flow_deltas; only individually listed cached-manager flow locations and their exact provenance evidence mirror were removed. Every remaining field and ordered location is unchanged. The complete entry and all its source contexts remain retained.'
 else:
  message=entry['message']
  if item['direction']=='added':
   assert message in {f'SENT-{rule} at meta_ads_mcp/core/auth.py:567: global instance escaped or was mutated; protection is not established' for rule in ['012','015','016']}
   assessment='Explicit conservative global AuthManager boundary. Included source uses global auth_manager and assigns token_info at auth.py339/362. This warning replaces assumed stable receiver traversal; it neither confirms a vulnerability nor establishes a safe cached credential path.'
   diagnostic_kinds['global_boundary_added']+=1
   for key in keys:context_roles[key]=roles[('meta_ads_mcp/core/auth.py',567)]
  elif any(message==f'SENT-016 at {path}:{line}: unresolved call to logger.{method}; protection is not established' for path,line,method in allowed_logs):
   assessment='Logger-call uncertainty inside cached-manager branches no longer traversed after the new global boundary. Its removal is not successful modeling or safety; the retained source and new unknown-global warning preserve the unsupported path.'
   diagnostic_kinds['cached_logger_removed']+=1
   for key in keys:context_roles[key]='Logger statement inside the now-untraversed cached AuthManager/related Pipeboard branch; no protection or successful logging model is established.'
  else:
   assert item['kind']=='warning' and message in {f'SENT-016 at meta_ads_mcp/core/api.py:{line}: resolved source/guard/sink evidence extends beyond the supplied review context.' for line in [199,235]}
   assessment='Review-context-size diagnostic disappears after cached-manager evidence is removed. Candidate identity, description, sink and remaining flow still exist; this does not repair credential authorization or establish full runtime context.'
   diagnostic_kinds['review_context_warning_removed']+=1
   for key in keys:context_roles.setdefault(key,'HTTP request sink retained in the same candidate; its trace is shorter because cached-manager traversal is now unknown.')
 occurrences.append({**item,'assessment':assessment})
# Every context not affected by a removed path/new diagnostic is an exact source
# context from an unchanged portion of the retained complete prior findings.
contexts={}
for key,c in inv['contexts'].items():
 assert c['source_sha256']==inv['source_file_bindings'][c['tree_sha256']][c['path']]
 contexts[key]={'source':c,'assessment':context_roles.get(key,'Exact source context retained from the fully source-assessed reference finding. The complete finding comparison proves this location/sink and all surrounding non-flow fields unchanged. Reuse retains its previous caller/value/sink, unmatched-candidate or unknown-path qualification without broadening safety.'),'new_or_changed_context_judgment':key in context_roles}
assert len(occurrences)==268 and len(rows)==10
result={'recorded_at':datetime.now(timezone.utc).isoformat(),'scanner':p['scanner'],'source_assessment_complete':True,'completed_meta_reports':10,'rows':rows,'finding_flow_deltas':flow_deltas,'changed_occurrence_assessments':occurrences,'context_assessments':contexts,'changed_occurrences':len(occurrences),'source_contexts':len(contexts),'distinct_new_context_judgments':len(context_roles),'diagnostic_change_counts':dict(diagnostic_kinds),'all_narrow_conditions_preserved':True,'retained_nominal_fixed_operator_errata':sum(bool(r['retained_nominal_fixed_operator_erratum']) for r in rows),'full_ordered_differences_sha256':sha(DEST/'complete-report-differences.jsonl.gz'),'difference_inventory_sha256':sha(DEST/'difference-inventory.json'),'complete_source_review_sha256':sha(OUT/'meta-source-review.json'),'prior_full_assessment_sha256':sha(prior_path),'paid_calls':0,'new_observations':0,'target_execution':False,'technical_acceptance_received':False,'phase22_complete':False,'initial_helper_failure':'Initial assessor verified top-level evidence but omitted the exact mirrored provenance evidence; strict equality failed before writing an assessment. Original helper/wrapper remain retained. Corrected helper verifies one provenance row, exact old/new evidence mirrors and complete equality after applying the same listed flow delta to both; no field is excluded.','qualification':'Full changed arrays and ordered evidence retained. No new volatile exclusion, report rewrite, raw condition refresh, target execution or detector invocation. More conservative mutable-global treatment narrows cached-manager support; it is not credential/URL safety. Original fresh and proposed limitation dispositions remain unaccepted.'}
with (DEST/'meta-delta-assessment.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Ten Meta reports:',len(flow_deltas),'changed findings,268changed occurrences,',len(contexts),'source contexts assessed;',dict(diagnostic_kinds),'; two operator errata retained.')
