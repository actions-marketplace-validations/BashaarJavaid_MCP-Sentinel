"""Reuse full source judgments only after exact source and entire ordered report equality."""
import collections, hashlib, json, sys
from datetime import datetime, timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3];BASE=OUT.parent;PREP=BASE/'v86-regression-preparation';DEST=OUT/sys.argv[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase20_scoring import score
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=read(PREP/'evaluation-proposal.json');inv=read(DEST/'difference-inventory.json');assert inv['complete_ordered_reconstruction_passed']
prior_paths={name:BASE/name/'final-assessment/assessment.json' for name in ['v80-unseen-results','v73-corrected-four-results','v75-prior-language-results']}
priors={name:read(path) for name,path in prior_paths.items()};rows=[];pending=[];counts=collections.Counter();files={}
for item in inv['rows']:
 group=item['group'];input_id=item['input_id'];expected=p['groups'][group]['inputs'][input_id];path=ROOT/item['current_report'];report=read(path)
 assert sha(path)==item['current_report_sha256'] and sha(ROOT/item['reference_report'])==item['reference_report_sha256']
 assert item['source_tree_sha256']==expected['input']['tree_sha256'] and item['source_tree_sha256'] in inv['source_file_bindings']
 if not item['entire_ordered_reference_equal']:
  pending.append(item);continue
 which='v80-unseen-results' if p['groups'][group]['corpus_kind']=='unseen_v1_exposed' else ('v73-corrected-four-results' if group in ['lightning-discover-linklocal','engram-export-home'] else 'v75-prior-language-results')
 previous=next(r for r in priors[which]['rows'] if r['input_id']==input_id and r['report_sha256']==item['reference_report_sha256'])
 label=expected['input']['label'];erratum=False;matched=[]
 if which=='v80-unseen-results':
  matched=previous['matching_keys'];passed=previous['named_vulnerable_detected'] if label=='vulnerable' else previous['supported_negative'];disposition='vulnerable_detected' if label=='vulnerable' and passed else ('valid_supported_negative' if passed else ('vulnerable_missed' if label=='vulnerable' else 'unsupported_negative'))
 elif which=='v73-corrected-four-results':
  passed=previous['narrow_condition_passed'];matched=previous['matching_keys'];disposition='vulnerable_detected' if label=='vulnerable' else 'valid_supported_negative'
 else:
  scoring=score(label=label,state='completed',findings=report['findings'],assessment=previous['source_assessment']);assert scoring==previous['score']
  erratum=previous.get('approved_meta_operator_erratum',False);matched=scoring['matched_keys'];passed=bool(scoring['candidate_detected']) if label=='vulnerable' else (scoring['false_alarm'] is False or bool(erratum))
  disposition='retained_nominal_fixed_operator_erratum' if erratum else ('vulnerable_detected' if label=='vulnerable' else 'valid_supported_negative')
  if erratum:assert input_id in ['meta-operator-fallback-fixed','meta-operator-fallback-fixed-mutation'] and len(matched)==2
  assessment_source=BASE/which/previous['assessment_source']/'assessment.json';assert sha(assessment_source)==previous['assessment_source_sha256'];files[str(assessment_source.relative_to(ROOT))]=sha(assessment_source)
 assert passed or group=='proxmox-upload-root',(input_id,previous)
 coverage=report['static_analysis']['coverage'];occurrences={'findings':len(report['findings']),'warnings':len(report['warnings']),'unresolved_flows':len(coverage['unresolved_flows']),'surfaces':len(coverage['surfaces'])}
 counts.update(occurrences);counts[disposition]+=1
 rows.append({**item,'label':label,'condition_passed':bool(passed),'condition_disposition':disposition,'matching_keys':matched,'negative_support_established':bool(passed) and not bool(erratum) if label!='vulnerable' else None,'retained_nominal_fixed_operator_erratum':erratum,'previous_complete_assessment':str(prior_paths[which].relative_to(ROOT)),'previous_complete_assessment_sha256':sha(prior_paths[which]),'previous_source_bound_row':previous,'occurrences':occurrences,'assessment':'Every ordered report field equals the complete source-assessed reference after only the11original volatile exclusions, and the full source tree/overlay/condition/configuration identities are unchanged. Reuse covers every finding, warning, unresolved flow, surface and source-context judgment, including unmatched candidates and conservative unknowns. No matching key is refreshed and no unsupported negative becomes supported.'})
for path in prior_paths.values():files[str(path.relative_to(ROOT))]=sha(path)
by_group={}
for group in p['groups']:
 selected=[r for r in rows if r['group']==group]
 by_group[group]={'observations_assessed':len(selected),'condition_counts':dict(collections.Counter(r['condition_disposition'] for r in selected)),'all_collected_conditions_passed':all(r['condition_passed'] for r in selected) if selected else None}
result={'recorded_at':datetime.now(timezone.utc).isoformat(),'scanner':p['scanner'],'proposal_sha256':sha(PREP/'evaluation-proposal.json'),'approval_sha256':sha(PREP/'evaluation-authorization.json'),'difference_inventory_sha256':sha(DEST/'difference-inventory.json'),'rows':rows,'pending_changed_reports':pending,'source_assessment_complete_for_collected_reports':not pending,'entire_ordered_reference_equal':len(rows),'observations_in_snapshot':len(inv['rows']),'occurrence_and_condition_counts':dict(counts),'groups':by_group,'prior_assessment_files_sha256':files,'new_source_context_judgments':0,'prior_contexts_reused':'All contexts for exact equal reports retain their immutable prior complete assessment chains. These reused context sets overlap and are not summed as independent contexts. Changed reports remain pending explicit assessment.','original_fresh_proxmox_failure_retained':True,'current_proxmox_source_boundary':str((OUT/'proxmox-source-boundary.json').relative_to(ROOT)),'current_proxmox_source_boundary_sha256':sha(OUT/'proxmox-source-boundary.json'),'paid_calls':0,'new_observations':0,'target_execution':False,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Same-agent source assessment of retained reports, not a new scanner/comparator run, independent validation, fresh-source success, runtime execution, population accuracy, speedup or broad safety. DDG caller-specific CGNAT, Meta operator errata, Git physical/identity qualifiers and all unrelated findings remain. Proxmox remains failed; the new nested metadata-call blocker is source-assessed separately. Engineering remains bound to884d376.'}
with (DEST/'assessment.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(len(rows),'complete reports source-assessed through exact identity;',len(pending),'changed reports remain pending;',dict(counts))
