"""Reconcile every requirement against the completed exposed regression."""
import copy,hashlib,json
from collections import Counter
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=read(BASE/'v34-import-binding/audit.json');p=copy.deepcopy(old);a=read(OUT/'assessment.json');assert a['source_assessment_complete']
refs=['assessment.json','condition-assessment.json','finding-source-assessment.json','diagnostic-source-assessment.json','other-source-assessment.json','validation.json','recovery-proposal.json']
common='Approved87-observation exposed regression at a50e9b7 is closed. Execution and source assessment are recorded separately from failed DDG guard coverage and Meta fixed-path compatibility. Historical first-frozen results, exact engineering source, source-compatible TypeScript reuse and Git312/1040 remain. No new paid calls, technical acceptance or completion.'
for r in p['requirements']:
 r['historical_v34_assessment']={'disposition':r['disposition'],'assessment':r['assessment']};r['interpretation']=common;r['evidence']+=['artifacts/phase22/integration/v35-ddg-regression/'+n for n in refs]
 if r['id'] in {*(f'R{i:02}' for i in range(18,27)),'R35','R36','R63','R64'}:
  assert a['historical_python_conditions_passed']
  r['disposition']='passed';r['assessment']='Current a50e9b7 affected Python historical conditions pass all31 inputs twice with14 vulnerable hits and zero matching alerts on17 negatives in each batch; ordered repeats and source-assessed diagnostics pass. Meta operator retains its approved two nominal-fixed erratum inputs/two keys each. Unchanged TypeScript behavior reuses actualf85a90f54-observation compatibility and Lighthouse results under v34 source proof; filesystem/kubernetes were not remeasured here. Original whole25 reuse and45+45 Linux timing remain at1f3f72f; partial compatibility is not pooled into a new whole batch.'
 elif r['id'] in {'R33','R65'}:
  r['disposition']='unresolved';r['assessment']='Current Python development detects all6 vulnerable conditions but the two Meta image fixed variants each gain3 unqualified matching initial-private-boundary alerts. Five of7 valid negatives have no matching alert; the public Meta control retains3 broader unmatched candidates. The two operator erratum inputs retain4 raw matched-key occurrences. These are measured/source-assessed failures, not a passed development gate.'
 elif r['id'] in {'R67','R69'}:
  r['disposition']='passed';r['assessment']='Every87 report/status/timing/repeat and every changed finding/diagnostic/derived report field is retained and source-assessed. Changed candidate identities have explicit post-observation rationales; raw reports, initial conditions and historical70-warning backlog remain unchanged. False alarms, public-control scope and broader uncertainties are separate.'
 elif r['id']=='R84':r['assessment']='The user approved evaluation only. DDG initialCGNAT guard qualification and Meta fixed-path compatibility fail. Final technical acceptance has neither been requested nor received; final closeout remains pending after successful correction or an explicit scope decision. Paid benchmark/pilots remain deferred.'
 elif r['id'] in {'R62','R83'}:r['assessment']='Owning docs now report the actual closed87-observation regression failure, source judgments, retained engineering and fresh history, concrete source-only recovery proposal and pending technical acceptance. No completion or new hosted/full-Linux pass is claimed.'
for r in p['additional_scope_requirements']:
 if r['id'] in {'V33-FIXED-COVERAGE','V34-REGRESSION'}:
  r['historical_v34_assessment']=copy.deepcopy(r);r['disposition']='unresolved';r['assessment']='All6 DDG fixed/control observations cover actualclient.send but lack initialCGNAT qualification. Both vulnerable variants remain detected per batch; two fixed variants each gain a matching generic alert. Meta compatibility separately fails. The closed87-observation evaluation does not satisfy the correction gate; no limitation is accepted.'
for id,requirement in [('V35-AUTH','Consume only the exact approved87-observation sequence at frozena50e9b7'),('V35-EXECUTION','Validate all approved observations, bounds, schemas, cleanup and36 entire ordered repeats'),('V35-ASSESSMENT','Source-assess every changed report item, preserve measured failures and close all budget')]:
 p['additional_scope_requirements'].append({'id':id,'requirement':requirement,'disposition':'passed' if a['execution_gate_passed'] else 'unresolved','assessment':common,'evidence':['artifacts/phase22/integration/v35-ddg-regression/'+n for n in refs]})
p.update(recorded_at=datetime.now(timezone.utc).isoformat(),prior_audit={'path':'v34-import-binding/audit.json','sha256':sha(BASE/'v34-import-binding/audit.json')},source='500e27c42c0ebfe6b4c1253fddb3b4895ab456d5',current_source_corpus_runs=1,current_source_native_observations=a['native_observations'],current_source_comparator_observations=0,current_exposed_evaluation_approved=True,current_exposed_evaluation_executed=True,current_exposed_gate_passed=False,current_compatibility_passed=False,current_compatibility_observations_this_continuation=77,acceptance_packet_ready=False,technical_acceptance_requested=False,technical_acceptance_received=False,phase22_complete=False,new_paid_calls=0,status=common)
p['historical_source_and_test_file_bindings']={'source':old['source'],'files':old['current_source_and_test_files'],'earlier':old['historical_source_and_test_file_bindings']}
p['current_source_and_test_files']={n:sha(ROOT/n) for n in old['current_source_and_test_files']}
p['references_sha256'].update({'artifacts/phase22/integration/v35-ddg-regression/'+n:sha(OUT/n) for n in refs})
p['full_sequence_status_basis']='Original whole25 reuse and45+45 Linux at1f3f72f unchanged. Current31Python historical repeats pass; prior14TypeScript historical inputs retain source-compatible reuse. This is not a pooled current whole45 execution. Current15Python development fails Meta negatives.'
p['fresh_evaluation_status_basis']='Original first-frozen DDG f85a90f detection remains unchanged. Currenta50 exposed87-observation regression fails fixed guard qualification and Meta compatibility.'
p['owning_document_binding']='Current owning docs are bound after the final status update in documentation-binding.json.'
p['dispositions']=dict(Counter(r['disposition'] for r in p['requirements']));p['additional_scope_dispositions']=dict(Counter(r['disposition'] for r in p['additional_scope_requirements']))
assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==97
assert p['dispositions']=={'passed':84,'explicitly user-deferred':2,'unresolved':3}
with (OUT/'audit.json').open('x') as f:json.dump(p,f,indent=2);f.write('\n')
print(p['dispositions'],p['additional_scope_dispositions'])
