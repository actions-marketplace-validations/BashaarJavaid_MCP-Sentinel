# Phase 22: exposed regression complete; guard correction still required

The approved **87-observation exposed regression at `a50e9b7` is complete**,
but **the correction gate fails**. All 87 inputs complete within the uniform
300-second native/whole-input maximum; 79 meet the 120-second target and
8 use extended time. The longest whole input takes
**241.846285 seconds**. All **36 entire ordered repeats** agree
after the established volatile exclusions. JSON/SARIF, source/configuration
identity and process cleanup validate. All 87 observations are consumed and the
budget is closed: **zero retries, comparators, target executions or paid calls**.

DDG still detects both vulnerable variants in each batch. Its six fixed/control
reports now cover the actual HTTPX `client.send`, with `build_request`/`send`
unresolved diagnostics removed. However, **none carries the required initial
`100.64.0.0/10` rejection qualification**. Each fixed variant gains one generic
matching alert; the public control retains a broader unmatched candidate.
Supporting the request operation alone does not satisfy guard coverage.

Python compatibility also finds a regression: the two Meta image fixed variants
each gain **three unqualified alerts** on paths protected against the named
initial private/loopback/prohibited-scheme condition. Its public-literal control
retains three broader unmatched candidates. Development still detects all six
vulnerable conditions; five of seven valid negatives have no matching alert.
The two nominal fixed Meta operator erratum inputs retain their original two
matched keys each. No condition labels, prerequisites or raw reports changed.

Both 31-input Python historical batches retain **14 vulnerable hits and zero
matching alerts on 17 negatives** each. Every changed finding and diagnostic is
source-assessed; removed diagnostics do not establish full safety. Unchanged
TypeScript behavior retains source-compatible evidence at `f85a90f`. The original
whole development/historical Linux results remain measured at `1f3f72f`; these
partial compatibility checks are not a new pooled whole-batch timing pass.

Engineering retains its actual **`8a3db58`** verification: **2,280 passed / 36
skipped** locally and in all 12 hosted suites, **89.87%** local branch coverage,
all 29 normal CI jobs and docs, source-bound packages and six zero-call production
replays. Product, tests and workflows did not change during this evaluation.
No new hosted engineering pass is claimed for the documentation delivery.

The **first-frozen DDG fresh detection at `f85a90f` remains unchanged**, including
its fixed-path coverage limitation. This later correction is exposed regression.
Original fresh misses, held-out failures and every earlier closed attempt remain
preserved. Git campaigns stay **312/1,040 incomplete**, as requested. Paid
benchmark/pilots remain deferred; Phase 21 incomplete and Phase 24/15 unchanged.

The audit covers **89 original rows: 84 passed, two user-deferred, three
unresolved (R33, R65, R84)**, plus **97 added rows: 90 passed, five historical
proposed limitations and two unresolved**. The added DDG coverage/regression gates
remain unresolved. **Phase 22 is incomplete; technical acceptance is not requested.**
The prepared `v35-ddg-regression/recovery-proposal.json` requests source-only
reproduction/correction and ordinary engineering with **zero corpus observations
or paid calls**. It requires a new decision under the approved no-automatic-repair
clause; later exact evaluation and final human acceptance remain separate.
No merge, ready-state, release, outreach or Phase 23 is authorized.

Review `artifacts/phase22/integration/v35-ddg-regression/` for the closed87-observation packet, source assessments, audit and source-only recovery proposal. Seal62 retains new evidence after all61 prior seals.

Retained CI: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34668626907
Retained docs: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34668626916
