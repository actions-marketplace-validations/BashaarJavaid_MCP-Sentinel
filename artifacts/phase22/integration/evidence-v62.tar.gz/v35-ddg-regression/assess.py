"""Source-adjudicate retained changes and frozen conditions; no target execution."""
import ast,hashlib,json,importlib.util
from collections import Counter,defaultdict
from pathlib import Path
from scripts.phase20_scoring import candidate_identity,score,metrics
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,d):
 with (OUT/n).open('x') as f:json.dump(d,f,indent=2);f.write('\n')
p=read(BASE/'v34-import-binding/evaluation-proposal.json');v=read(OUT/'validation.json');assert v['budget_closed']
spec=importlib.util.spec_from_file_location('retained_evaluator',BASE/'v34-import-binding/evaluate.py');evaluator=importlib.util.module_from_spec(spec);spec.loader.exec_module(evaluator)
contexts=read(OUT/'source-contexts.json');ds=read(OUT/'diagnostic-change-inventory.json');fs=read(OUT/'finding-change-inventory.json');other=read(OUT/'other-change-inventory.json')
tree=ast.parse((BASE/'v33-fresh-v6/assess.py').read_text());roles=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ROLES' for t in n.targets)))
roles['fetch.py']['_get_with_validated_redirects']='Fixed source validates and pins the URL, builds a prepared request, dispatches client.send, bounds streamed bytes and closes responses. Current reports support the actual send and remove build_request/send unresolved diagnostics, but the send candidate lacks the required initial CGNAT qualification. Removed post-request stream/close/response diagnostics reflect changed abstract traversal and are not evidence of complete response/redirect safety.'
roles['fetch.py']['_pinned_request_url']='Reconstructs a URL from the parsed scheme, selected validated address, port and original path/query/fragment. The new urllib reconstruction handling preserves caller flow into a prepared request; it does not establish DNS/redirect safety or the required guard qualification in this observed report.'
roles['urls.py']={'validate_url_for_ssrf':'Lowercases the parsed hostname before checking blocked names. This normalization is now modeled; the existing source scheme/IP/allowlist/DNS checks still need their own evidence. No named-condition finding changes occur in these historical inputs.','_check_ip_address':'Uses isinstance on a parsed ipaddress value to unwrap IPv4-mapped IPv6 before rejecting non-global addresses. The bound external type inspection is now modeled without executing the target; this removes one diagnostic, not a new whole-network safety claim.','_hostname_matches_allowlist':'Lowercases the hostname before exact or dot-delimited suffix matching. Known string normalization removes its diagnostic; this alone neither validates the caller URL nor proves safe DNS.'}
reviewed=[]
for d in ds:
 c=contexts[d['context']];assert d['direction']=='removed' and d['rule_id']=='SENT-015'
 explanation=roles[Path(c['path']).name][c['enclosing_name']]
 if Path(c['path']).name=='text.py':explanation+=' Removed diagnostic reflects reduced downstream response taint after the supported HTTPX send response, not newly proved content sanitization or destination protection.'
 elif Path(c['path']).name=='security.py':explanation+=' Current bound string/IP/network helpers remove this particular unresolved diagnostic. The DDG final merged send still lacks CGNAT qualification; no source guard is promoted to measured native recognition.'
 reviewed.append({**d,'source':c,'assessment':explanation,'disposition':'Source-assessed removed analysis diagnostic; no runtime proof or full-safety conclusion.'})
write('diagnostic-source-assessment.json',{'rows':reviewed,'occurrences':len(reviewed),'unique_source_contexts':len({d['context'] for d in ds})})
reviewed=[]
for f in fs:
 c=contexts[f['context']];assert f['before'] is None and f['after']['rule_id']=='SENT-015';finding=f['after'];locations={(l['path'],l['range']['start_line']) for l in finding['evidence']['flow_locations']}
 assert '100.64' not in finding['description']
 if f['group']=='ddg':
  assert c['path']=='src/mcp_ddg_research/fetch.py' and c['line']==135 and 'client.send(request, stream=True)' in c['text'];assert ('src/mcp_ddg_research/server.py',238) in locations
  explanation='The native candidate carries the registered web_fetch URL to the actual prepared-request send. Fixed validate_url_shape/is_unsafe_ip explicitly rejects initial100.100.200.200 via100.64/10 before resolution/request. This generic alert lacks that qualification and therefore falsely implicates the named fixed initial boundary; broader DNS/redirect/other-entry uncertainty remains. Public-safe input is not a violated public-literal condition. See retained exact source and preliminary mixed-entry review; pre-merge cause is not yet measured.'
 else:
  assert f['group']=='development' and f['input_id'].startswith('meta-image-ssrf-');assert c['path']=='meta_ads_mcp/core/utils.py' and c['line'] in {282,346,362};assert ('meta_ads_mcp/core/ads.py',1322) in locations
  explanation='upload_ad_image image_url reaches this request through try_multiple_download_methods. Its up-front validate_public_url rejects prohibited schemes and literal private/loopback addresses; download_image additionally validates and request hooks revalidate. A generic unqualified candidate falsely implicates the named fixed initial boundary. The same candidate on the public-safe control is unmatched to that accepted-public-literal condition. DNS rebinding, CGNAT and other broader candidates remain separately uncertain. Exact source is retained in meta-source-review.json.'
 matches='fixed' in f['input_id'];reviewed.append({**f,'source':c,'matches_named_condition':matches,'disposition':'Named fixed-condition false alarm; broader uncertainty retained.' if matches else 'Unmatched broader SSRF candidate on public-safe control; no full-safety claim.','assessment':explanation})
write('finding-source-assessment.json',{'rows':reviewed,'occurrences':len(reviewed)})
allowed={'/static_analysis/rule_outcomes','/static_analysis/total_matches','/review_activity/static/candidate_count','/review_activity/static/unreviewed_count','/summary/by_status/needs_review','/summary/total','/summary/by_severity/Medium'}
for d in other:
 assert d['pointer'] in allowed,d['pointer']
 added=[f for f in fs if f['input_id']==d['input_id'] and f['batch']==d['batch']]
 assert len(added) in {1,3}
 if d['pointer']!='/static_analysis/rule_outcomes':assert d['after']-d['before']==len(added)
 else:
  before={r['rule_id']:r for r in d['before']};after={r['rule_id']:r for r in d['after']};assert before.keys()==after.keys()
  assert all(before[k]==after[k] for k in before if k!='SENT-015')
  assert after['SENT-015']['match_count']-before['SENT-015']['match_count']==len(added)
  assert {k:v for k,v in before['SENT-015'].items() if k!='match_count'}=={k:v for k,v in after['SENT-015'].items() if k!='match_count'}
 d['assessment']='Derived finding counters/rule outcome reflect exactly the individually assessed added SENT-015 candidates. No source, manifest, surface, label or other report field changes.'
write('other-source-assessment.json',{'rows':other,'occurrences':len(other),'surface_changes':0})
rows=[];batches=defaultdict(list)
for a in v['attempts']:
 if a['state']!='completed':continue
 item=p['groups'][a['group']]['inputs'][a['input_id']];label=item['input']['label'];r=read(OUT/'raw'/a['directory']/a['input_id']/'report.json');findings=r['findings'];assessment=item['assessment'];matches=[]
 changes=[f for f in reviewed if f['input_id']==a['input_id'] and f['batch']==a['batch']]
 reference=read(ROOT/item['reference_report']);old_keys={f['dedup_key'] for f in reference['findings']};retained=[f for f in findings if f['dedup_key'] in old_keys]
 assert evaluator.supervisor.clean(retained,set(p['volatile_exclusions']))==evaluator.supervisor.clean(reference['findings'],set(p['volatile_exclusions']))
 assert len(findings)-len(retained)==len(changes)
 if a['group']=='ddg':
  if label=='vulnerable':
   matches=[f['dedup_key'] for f in findings if f['rule_id']=='SENT-015'];assert len(matches)==1
   f=next(f for f in findings if f['dedup_key']==matches[0]);assert f['location']['range']['start_line']==76 and '100.64' not in f['description']
  else:
   matches=[f['dedup_key'] for f in changes if f['matches_named_condition']]
   assert not any('SENT-015 at src/mcp_ddg_research/fetch.py:'+str(line)+':' in w['message'] for w in r['warnings'] for line in [129,135])
 elif changes:
  assert a['input_id'].startswith('meta-image-ssrf-');matches=[f['dedup_key'] for f in changes if f['matches_named_condition']]
 else:
  assert a['condition']['ordered_findings_equal'];matches=assessment['matches']
 rationale='Exact prior ordered findings/condition assessment reused where unchanged. New candidates are individually source-assessed in finding-source-assessment.json with explicit fixed-boundary false alarms, separate public-control scope, and broader uncertainty; original labels and raw reports are unchanged.'
 assessment={'candidate_identity':candidate_identity(findings),'matches':matches,'rationale':rationale};s=score(label=label,state='completed',findings=findings,assessment=assessment)
 erratum=a['input_id'] in {'meta-operator-fallback-fixed','meta-operator-fallback-fixed-mutation'}
 row={'group':a['group'],'batch':a['batch'],'input_id':a['input_id'],'label':label,'source_condition':item['input']['condition'],'report_sha256':a['report_sha256'],'reference_sha256':a['reference_sha256'],'raw_condition':a['condition'],'source_assessment':assessment,**s,'approved_meta_operator_erratum':erratum,'whole_seconds':a['timing']['elapsed_seconds'],'native_seconds':a['native_seconds'],'timing_class':a['timing_class']}
 if erratum:assert len(matches)==2 and s['false_alarm']
 rows.append(row);batches[a['group']+'/'+a['batch']].append(row)
write('condition-assessment.json',{'rows':rows,'batches':{k:metrics(r) for k,r in batches.items()},'raw_scorer_unadjudicated_keys_retained':True,'new_keys_not_applied_to_historical_reports':True})
completed=len(rows);neg=[r for r in rows if r['group']=='ddg' and r['label']!='vulnerable'];hist=[r for r in rows if r['group']=='historical'];dev=[r for r in rows if r['group']=='development'];ddg=[r for r in rows if r['group']=='ddg']
result={'scanner':p['scanner'],'execution_gate_passed':v['passed'],'detection_and_coverage_gate_passed':False,'ddg_guard_coverage_passed':False,'ddg_negative_guard_coverage':{'required':6,'observed':len(neg),'qualified':0},'ddg_actual_send_supported':len(neg)==6,'python_compatibility_passed':False,'historical_python_conditions_passed':len(hist)==62 and all(r['retained_detected'] if r['label']=='vulnerable' else not r['false_alarm'] for r in hist),'native_observations':len(v['attempts']),'completed':completed,'whole_ordered_repeats':sum(a.get('ordered_repeat_equal',False) for a in v['attempts']),'timing_classes':dict(Counter(r['timing_class'] for r in rows)),'maximum_whole_seconds':max(r['whole_seconds'] for r in rows),'maximum_native_seconds':max(r['native_seconds'] for r in rows),'sequence_seconds':read(OUT/'exit.json')['elapsed_seconds'],'new_finding_occurrences':len(fs),'diagnostic_change_occurrences':len(ds),'other_change_occurrences':len(other),'surface_changes':0,'budget_closed':True,'remaining':0,'unstarted_closed':v['unstarted_closed'],'paid_calls':0,'target_execution':False,'technical_acceptance_received':False,'phase22_complete':False,'original_fresh_result_unchanged':True,'unresolved':['DDG actual send is supported but required initialCGNAT qualification is absent on all fixed/control reports.','Meta image fixed and fixed-mutation each gain three generic named-boundary false alarms; public-safe candidate uncertainties remain separately unmatched.'],'source_assessment_complete':True,'assessment_references_sha256':{n:sha(OUT/n) for n in ['validation.json','condition-assessment.json','finding-source-assessment.json','diagnostic-source-assessment.json','other-source-assessment.json','meta-source-review.json','preliminary-source-review.json']},'qualification':'Exposed regression after source correction, not fresh detection or a new whole25/45 Linux sequence. Original f85 fresh detection, all failed/closed budgets and incompleteGit312/1040 remain. No automatic repair or new observations.'}
write('assessment.json',result);print(json.dumps({k:result[k] for k in ['execution_gate_passed','completed','whole_ordered_repeats','timing_classes','maximum_whole_seconds','new_finding_occurrences','diagnostic_change_occurrences','detection_and_coverage_gate_passed']},indent=2))
