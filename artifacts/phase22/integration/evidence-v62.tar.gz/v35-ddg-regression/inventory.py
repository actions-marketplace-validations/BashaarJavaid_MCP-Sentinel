"""Index every changed retained diagnostic and finding for source adjudication."""
import ast,hashlib,json,re
from collections import Counter
from pathlib import Path
from scripts.phase20_corpus import validate
from scripts.phase22_corpus import frozen,input_files
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
p=read(BASE/'v34-import-binding/evaluation-proposal.json');v=read(OUT/'validation.json');assert v['budget_closed']
contexts={};occurrences=[];finding_changes=[];other_changes=[];cache={};manifests={}
def files_for(group,input_id):
 key=(group,input_id)
 if key not in cache:
  if group not in manifests:
   g=p['groups'][group];manifests[group]=validate() if group=='historical' else frozen(approval_path=ROOT/g['source_freeze_approval'])
  m=manifests[group];i=next(i for i in m.inputs if i.id==input_id);s=next(s for s in m.snapshots if s.revision==i.snapshot);files=input_files(i,s,ROOT);prefix='' if i.scan_root=='.' else i.scan_root+'/'
  cache[key]={n[len(prefix):]:b for n,b in files.items() if n.startswith(prefix)}
 return cache[key]
def context(files,path,line):
 data=files[path];lines=data.decode().splitlines();assert 0<line<=len(lines),(path,line)
 tree=ast.parse(data);nodes=[n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.lineno<=line<=n.end_lineno]
 node=min(nodes,key=lambda n:n.end_lineno-n.lineno) if nodes else None
 start=node.lineno if node else max(1,line-3);end=node.end_lineno if node else min(len(lines),line+3)
 key=sha(json.dumps([path,sha(data),line]).encode())
 contexts[key]={'path':path,'source_sha256':sha(data),'line':line,'text':lines[line-1],'enclosing_name':node.name if node else '<module>','start_line':start,'end_line':end,'source_excerpt':'\n'.join(f'{n}: {lines[n-1]}' for n in range(start,end+1))}
 return key
for row in v['attempts']:
 if row['state']!='completed':continue
 files=files_for(row['group'],row['input_id']);common={k:row[k] for k in ['group','batch','input_id','report_sha256','reference_sha256']}
 for delta in row['reference_deltas']:
  pointer=delta['pointer']
  if pointer=='/findings':
   old={f['dedup_key']:f for f in delta['before']};new={f['dedup_key']:f for f in delta['after']}
   for key in sorted(old.keys()|new.keys()):
    if old.get(key)==new.get(key):continue
    f=new.get(key,old.get(key));location=f['location'];ctx=context(files,location['path'],location['range']['start_line'])
    finding_changes.append({**common,'dedup_key':key,'before':old.get(key),'after':new.get(key),'context':ctx})
  elif pointer in {'/warnings','/static_analysis/coverage/unresolved_flows'}:
   dumps=lambda x:json.dumps(x,sort_keys=True);before=Counter(map(dumps,delta['before']));after=Counter(map(dumps,delta['after']))
   for direction,items in [('removed',before-after),('added',after-before)]:
    for text,count in items.items():
     d=json.loads(text);match=re.fullmatch(r'(SENT-\d+) at (.*):(\d+): (.*)',d['message'])
     assert match,('Unlocated changed diagnostic',d)
     rule,path,line,reason=match.groups();ctx=context(files,path,int(line))
     for occurrence in range(count):occurrences.append({**common,'pointer':pointer,'direction':direction,'occurrence':occurrence,'diagnostic':d,'rule_id':rule,'reason':reason,'context':ctx})
  else:other_changes.append({**common,**delta})
for name,data in [('source-contexts.json',contexts),('diagnostic-change-inventory.json',occurrences),('finding-change-inventory.json',finding_changes),('other-change-inventory.json',other_changes)]:
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
print('Contexts',len(contexts),'diagnostic occurrences',len(occurrences),'finding changes',len(finding_changes),'other changes',len(other_changes))
