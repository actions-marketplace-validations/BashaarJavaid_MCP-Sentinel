"""Retain source-only evidence for new Meta fixed-path candidates; never import targets."""
import ast,hashlib,json
from pathlib import Path
from scripts.phase22_corpus import frozen,input_files
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
m=frozen(approval_path=ROOT/'artifacts/phase22/authorization.json');rows=[]
for name in ['meta-image-ssrf-fixed','meta-image-ssrf-fixed-mutation','meta-image-safe']:
 i=next(i for i in m.inputs if i.id==name);s=next(s for s in m.snapshots if s.revision==i.snapshot);files=input_files(i,s,ROOT);records=[]
 for path,names in [('meta_ads_mcp/core/utils.py',{'_ip_is_disallowed','validate_public_url','_ssrf_guard_request_hook','download_image','try_multiple_download_methods'}),('meta_ads_mcp/core/ads.py',{'upload_ad_image'})]:
  data=files[path];lines=data.decode().splitlines()
  for n in ast.walk(ast.parse(data)):
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names:records.append({'path':path,'sha256':hashlib.sha256(data).hexdigest(),'function':n.name,'start_line':n.lineno,'end_line':n.end_lineno,'source':'\n'.join(f'{k}: {lines[k-1]}' for k in range(n.lineno,n.end_lineno+1))})
 rows.append({'input':i.model_dump(mode='json'),'records':records})
p={'inputs':rows,'source_judgment':'upload_ad_image forwards image_url to try_multiple_download_methods, whose up-front validate_public_url rejects prohibited schemes and literal addresses with private/loopback/etc flags before any of the three image requests. download_image repeats validation; request hooks revalidate outbound requests. These facts cover the named initial literal condition, not DNS rebinding or every special address. A public8.8.8.8 literal is admitted by design.','new_findings':'Three generic SENT-015 findings at utils.py282/346/362 carry upload_ad_image caller locations and the actual request boundary. Their absence of the known initial private-address qualification is a regression for the two fixed-condition inputs. Safe-public input has the same candidates but does not itself violate the public-control condition. Retain them as broader candidates rather than treat safe-source equality as proof of full safety.','source_only':True,'target_execution':False,'paid_calls':0}
with (OUT/'meta-source-review.json').open('x') as f:json.dump(p,f,indent=2);f.write('\n')
print('Retained three exact source assessments')
