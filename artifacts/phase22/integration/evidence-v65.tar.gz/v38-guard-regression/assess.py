"""Adjudicate retained caller-route reporting changes; never execute targets."""
import hashlib,json
from collections import Counter,defaultdict
from pathlib import Path
from scripts.phase20_scoring import candidate_identity,score,metrics
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
p=read(BASE/'v37-ddg-trace/evaluation-proposal.json');v=read(OUT/'validation.json');assert v['budget_closed']
contexts=read(OUT/'source-contexts.json');fs=read(OUT/'finding-change-inventory.json');ds=read(OUT/'diagnostic-change-inventory.json');other=read(OUT/'other-change-inventory.json')
# Unexpected report changes require additional source review, not automatic acceptance.
assert not ds and not other,(len(ds),len(other))
prior=read(BASE/'v35-ddg-regression/condition-assessment.json');prior_rows={(r['group'],r['batch'],r['input_id']):r for r in prior['rows']}
prior_f=read(BASE/'v35-ddg-regression/finding-source-assessment.json');prior_changes={(r['group'],r['batch'],r['input_id'],r['dedup_key']):r for r in prior_f['rows']}
reviewed=[]
for f in fs:
 before,after=f['before'],f['after'];assert before and after and after['rule_id']=='SENT-015'
 assert {k:x for k,x in before.items() if k!='description'}=={k:x for k,x in after.items() if k!='description'}
 previous=prior_changes[(f['group'],f['batch'],f['input_id'],f['dedup_key'])];c=contexts[f['context']]
 assert c==previous['source'] and before==previous['after']
 locations={(l['path'],l['range']['start_line']) for l in after['evidence']['flow_locations']}
 if f['group']=='ddg':
  assert c['path']=='src/mcp_ddg_research/fetch.py' and c['line']==135 and 'client.send(request, stream=True)' in c['text']
  assert ('src/mcp_ddg_research/server.py',238) in locations
  route='src/mcp_ddg_research/server.py:245:21 -> src/mcp_ddg_research/fetch.py:261:29 -> src/mcp_ddg_research/fetch.py:135:25'
  qualified=('Only the analyzed caller route '+route+' has recognized initial shared-space IPv4 (100.64.0.0/10) rejection; this candidate does not allege that initial bypass on that route.') in after['description']
  assert qualified and 'Other caller routes, subsequent URL transformations, DNS, redirects and broader destination protection remain unestablished.' in after['description']
  explanation='The unchanged registered web_fetch URL reaches validate_url_shape/is_unsafe_ip before resolution and the prepared send. The source rejects initial100.100.200.200 with100.64/10; the actual report now explicitly qualifies that exact direct caller route. The separate deep-search route does not receive this qualification. The candidate remains visible for other routes and broader DNS, redirects and transformation uncertainty. The first-frozen unsupported fixed path and later v35 generic false alarm remain historical results; this is an exposed correction.'
 else:
  assert f['group']=='development' and f['input_id'].startswith('meta-image-ssrf-') and c['path']=='meta_ads_mcp/core/utils.py' and c['line'] in {282,346,362}
  assert ('meta_ads_mcp/core/ads.py',1322) in locations
  qualified=after['description'].startswith('The source rejects private literal IPv4 destinations for this caller URL before the request.')
  assert qualified and 'this candidate does not allege an initial literal IPv4 loopback bypass.' in after['description'] and 'DNS, redirects and broader IPv6 protection are not established' in after['description']
  explanation='The unchanged upload_ad_image image_url flows through try_multiple_download_methods and its up-front validate_public_url. Source scheme and literal-address checks reject the named initial private/loopback boundary before these three requests. The report now preserves the narrow private-literal qualification instead of the v35 generic false alarm. Six address flags are not treated as CGNAT rejection or complete destination protection. Request hooks and DNS source code do not establish runtime protection; broader candidates remain visible and unmatched to the narrow fixed/public-control conditions.'
 reviewed.append({**f,'source':c,'prior_assessment_sha256':sha(BASE/'v35-ddg-regression/finding-source-assessment.json'),'matches_named_condition':False,'guard_qualification_established':qualified,'assessment':explanation,'disposition':'Qualified broader candidate; zero matching alert for the unchanged named negative condition.'})
write('finding-source-assessment.json',{'rows':reviewed,'occurrences':len(reviewed),'change':'Description-only qualifications; no candidate added, removed, relocated or reordered against immediatev35 reports.'})
for name,previous in [('diagnostic-source-assessment.json','diagnostic-source-assessment.json'),('other-source-assessment.json','other-source-assessment.json')]:
 write(name,{'rows':[],'occurrences':0,'surface_changes':0,'basis':'Entire warnings, unresolved flows, coverage, counters and surfaces equal immediatev35 reports. Its individually assessed changes relative to original references retain their actual source-bound judgment. No warning or coverage suppression is inferred.','prior_source_assessment':'artifacts/phase22/integration/v35-ddg-regression/'+previous,'prior_source_assessment_sha256':sha(BASE/'v35-ddg-regression'/previous)})
rows=[];batches=defaultdict(list)
for a in v['attempts']:
 if a['state']!='completed':continue
 key=(a['group'],a['batch'],a['input_id']);old=prior_rows[key];item=p['groups'][a['group']]['inputs'][a['input_id']];label=item['input']['label']
 r=read(OUT/'raw'/a['directory']/a['input_id']/'report.json');findings=r['findings'];prior_report=read(ROOT/a['prior_scanner_report']);assert [f['dedup_key'] for f in findings]==[f['dedup_key'] for f in prior_report['findings']];changes=[f for f in reviewed if (f['group'],f['batch'],f['input_id'])==key]
 assert set(d['pointer'] for d in a['prior_scanner_deltas'])==({'/findings'} if changes else set())
 assert old['report_sha256']==a['prior_scanner_report_sha256'] and old['label']==label and old['source_condition']==item['input']['condition']
 removed={f['dedup_key'] for f in changes};matches=[k for k in old['source_assessment']['matches'] if k not in removed]
 assessment={'candidate_identity':candidate_identity(findings),'matches':matches,'rationale':'Reuse exact prior source adjudication for unchanged ordered findings. Individually reviewed description-only qualifications remove named-negative matches only where the actual retained report now explicitly excludes the established initial bypass. Original labels, raw reports, broader unmatched findings and previous failures remain unchanged.'}
 s=score(label=label,state='completed',findings=findings,assessment=assessment)
 erratum=a['input_id'] in {'meta-operator-fallback-fixed','meta-operator-fallback-fixed-mutation'}
 if erratum:assert len(matches)==2 and s['false_alarm']
 if a['group']=='ddg' and label=='vulnerable':
  assert len(matches)==1
  f=next(f for f in findings if f['dedup_key']==matches[0]);assert f['rule_id']=='SENT-015' and f['location']['range']['start_line']==76 and '100.64' not in f['description']
 if a['group']=='ddg' and label!='vulnerable':
  assert len(changes)==1 and changes[0]['guard_qualification_established']
  assert not any('SENT-015 at src/mcp_ddg_research/fetch.py:'+str(line)+':' in w['message'] for w in r['warnings'] for line in [129,135])
 row={'group':a['group'],'batch':a['batch'],'input_id':a['input_id'],'label':label,'source_condition':item['input']['condition'],'report_sha256':a['report_sha256'],'reference_sha256':a['reference_sha256'],'prior_scanner_report_sha256':a['prior_scanner_report_sha256'],'raw_condition':a['condition'],'source_assessment':assessment,**s,'approved_meta_operator_erratum':erratum,'whole_seconds':a['timing']['elapsed_seconds'],'native_seconds':a['native_seconds'],'timing_class':a['timing_class']}
 rows.append(row);batches[a['group']+'/'+a['batch']].append(row)
write('condition-assessment.json',{'rows':rows,'batches':{k:metrics(r) for k,r in batches.items()},'raw_scorer_unadjudicated_keys_retained':True,'new_keys_not_applied_to_historical_reports':True,'prior_condition_assessment_sha256':sha(BASE/'v35-ddg-regression/condition-assessment.json')})
def conditions(group,count):
 selected=[r for r in rows if r['group']==group]
 return len(selected)==count and all(r['retained_detected'] if r['label']=='vulnerable' else (r['approved_meta_operator_erratum'] or r['false_alarm'] is False) for r in selected)
neg=[r for r in rows if r['group']=='ddg' and r['label']!='vulnerable'];guard=len(neg)==6 and sum(f['group']=='ddg' and f['guard_qualification_established'] for f in reviewed)==6
compat=conditions('development',15) and conditions('historical',62);gate=v['passed'] and guard and conditions('ddg',10) and compat
result={'scanner':p['scanner'],'execution_gate_passed':v['passed'],'detection_and_coverage_gate_passed':gate,'ddg_guard_coverage_passed':guard,'ddg_negative_guard_coverage':{'required':6,'observed':len(neg),'qualified':sum(f['group']=='ddg' and f['guard_qualification_established'] for f in reviewed)},'ddg_actual_send_supported':len(neg)==6,'python_compatibility_passed':compat,'historical_python_conditions_passed':conditions('historical',62),'native_observations':len(v['attempts']),'completed':len(rows),'whole_ordered_repeats':sum(a.get('ordered_repeat_equal',False) for a in v['attempts']),'timing_classes':dict(Counter(r['timing_class'] for r in rows)),'maximum_whole_seconds':max(r['whole_seconds'] for r in rows),'maximum_native_seconds':max(r['native_seconds'] for r in rows),'sequence_seconds':read(OUT/'exit.json')['elapsed_seconds'],'changed_finding_occurrences':len(fs),'new_finding_occurrences':0,'diagnostic_change_occurrences':len(ds),'other_change_occurrences':len(other),'surface_changes':0,'budget_closed':True,'remaining':0,'unstarted_closed':v['unstarted_closed'],'paid_calls':0,'target_execution':False,'technical_acceptance_received':False,'phase22_complete':False,'original_fresh_result_unchanged':True,'source_assessment_complete':True,'assessment_references_sha256':{n:sha(OUT/n) for n in ['validation.json','condition-assessment.json','finding-source-assessment.json','diagnostic-source-assessment.json','other-source-assessment.json']},'qualification':'Exposed regression at8c62567 after correction, not fresh detection or a new whole25/45 Linux sequence. Originalf85 fresh result, all failed/closed budgets and incompleteGit312/1040 remain. No automatic technical acceptance, new observation or runtime proof.'}
write('assessment.json',result);print(json.dumps(result,indent=2))
