"""Publish only measured, source-assessed regression and pending acceptance facts."""
import json
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());a=read(OUT/'assessment.json');assert a['detection_and_coverage_gate_passed']
t=a['timing_classes'];local=read(BASE/'v37-ddg-trace/local-checks.json')
text=f'''The separately approved **87-observation exposed regression passes** at frozen
scanner **`8c62567`**. All **87/87** inputs complete and all **36 entire ordered
repeats agree**, excluding only the established 11 volatile fields. Native JSON,
SARIF, source/configuration identities and process cleanup validate. **{t.get('completed_within_target',0)}**
observations finish within the **120-second target** and **{t.get('completed_using_extended_time',0)}** use the approved
extended allowance. Maximum whole-input time is **{a['maximum_whole_seconds']:.6f} seconds**;
maximum native time is **{a['maximum_native_seconds']:.3f} seconds**, both within the uniform
**300-second maximum**. The single serial macOS sequence took
**{a['sequence_seconds']:.3f} seconds**. Its **87-observation budget is closed**;
zero retries, profiles, comparators, corpus target executions or paid calls occurred.

DDG detects **both vulnerable variants in each batch**. All **six fixed/control
reports** support the actual prepared-request `client.send` and retain recognized
initial **100.64.0.0/10 rejection on the direct `web_fetch` caller route**. The
build/send calls are no longer unresolved. There are **zero matching alerts on
all three negative inputs per batch**. Broader SSRF findings remain visible;
other caller routes, later transformations, DNS, redirects, IPv6 and broader
destination protection remain unestablished. This resolves the requested actual
fixed-path coverage gate without accepting the earlier unsupported-path limitation.

Python development completes **15/15**: **six vulnerable condition hits**, **zero
matching alerts on seven valid negatives**, and the unchanged Meta operator
erratum: **two nominal fixed input cases, each with two raw matched candidate
keys**. Meta image fixed/control reports retain their narrow private-literal
qualification at all three request sinks. Each whole **31-input Python historical
batch** passes with **14 vulnerable hits and zero matching alerts on 17 negatives**.
All source labels, prerequisites and unrelated candidates remain unchanged.

Against the immediate `a50e9b7` regression, there are **{a['changed_finding_occurrences']} description-only finding
changes**, individually assessed against exact retained source: six DDG direct-route
qualifications and nine Meta private-literal qualifications. No findings are added,
removed or reordered; no warnings, unresolved flows, coverage, surfaces or counters
change. Earlier source-assessed deltas against original references remain bound to
their actual reports. Raw scorer identities and unmatched broader candidates stay
visible. This is source-grounded static evidence, not runtime protection proof.

The original fresh repository **`isyuricunha/mcp-ddg-research`** remains measured
at pre-curation scanner **`f85a90f`**: **10 native + five Semgrep observations**,
two correlated vulnerable hits per native batch, zero matching negative alerts,
five whole ordered repeats, and **Semgrep 0/2**. Its original fixed-path coverage
gap remains recorded. The later `8c62567` correction is **exposed regression**;
it does not replace that first-frozen result. This is one repository and one narrow
vulnerability, curated by the implementation agent after scanner freeze, with
source exposure disclosed; no independent human review, broad accuracy or
training-data novelty is claimed.

Prior exposed TypeScript families, Lighthouse and TypeScript compatibility retain
their actual **`f85a90f` source-compatible evidence**. Historical whole Linux timing
retains **`1f3f72f`**: both whole 45-input batches pass, with the explicitly approved
reuse of the previously passed whole 25-input development batch. Current Python
and prior TypeScript subsets are **not pooled into a new whole-batch execution**.
All original misses, the failed `a50e9b7` regression, stopped experiments and closed
budgets remain preserved. No speedup or new fresh-source result is claimed.

Product, tests and workflows are unchanged from verified **`8c62567`**. Local and
all **12 hosted quality suites pass 2,283 tests / 36 skips**; local branch coverage
is **{local['full_suite']['branch_coverage_percent']:.2f}%**. All **29 normal CI jobs** and docs pass at that
actual source. Package source bindings and six zero-call production replays retain
their verified source identities; final status-only documentation/package metadata
is checked separately. Existing Git runtime components/image remain compatible,
and **Git coverage stays incomplete at 312/1,040 attempts**, as the user requested.

The reconciled audit accounts for **89 original requirements: 86 passed, two
user-deferred and only R84 (human technical acceptance) unresolved**. All **108 added
scope rows** are retained: **103 passed and five historical closure dispositions
awaiting explicit acceptance**. Those five preserve the failed optimization,
stale-assessment sequence, reused-source preparation and two stopped Lighthouse
corrections; accepting their closure never converts failures into passes.

The concrete **technical acceptance proposal** is
`artifacts/phase22/integration/v38-guard-regression/acceptance-proposal.json`.
**Human technical acceptance has not been received; Phase 22 remains incomplete.**
Acceptance must explicitly cover the final technical scope and retained limitations,
then the authorized closeout must be delivered to existing draft PR #37. The full
paid benchmark and pilots remain user-deferred; Phase 21 remains incomplete and
Phase 24/15 gates are unchanged. No paid calls, further observations, merge,
ready-state change, release, outreach or Phase 23 is authorized by this packet.
'''
old='## Current v37 diagnostic and caller-route correction checkpoint\n\n'+(BASE/'v37-ddg-trace/summary.md').read_text().split('\n\n',1)[1]+'\n'
new='## Current v38 regression pass and technical acceptance checkpoint\n\n'+text+'\n'
for name in read(BASE/'v37-ddg-trace/documentation-binding.json')['owning_docs_sha256']:
 path=ROOT/name;s=path.read_text();assert s.count(old)==1,name;path.write_text(s.replace(old,new))
path=BASE/'README.md';s=path.read_text().replace('batches 1–64','batches 1–65',1)
start=s.index('Review [measured diagnostic](v37-ddg-trace/diagnostic-assessment.json)');end=s.index('\n',start)
s=s[:start]+'Review [passed exposed regression](v38-guard-regression/assessment.json), [89 + 108 row audit](v38-guard-regression/audit.json) and [explicit technical acceptance proposal](v38-guard-regression/acceptance-proposal.json). Restore seal 65 after seals 1–64, verifying every archive and member hash. The [original fresh result](v33-fresh-v6/assessment.json) and [v35 failed regression](v35-ddg-regression/assessment.json) remain unchanged.'+s[end:];path.write_text(s)
(OUT/'summary.md').write_text('# Phase 22 regression pass and technical acceptance checkpoint\n\n'+text)
(OUT/'pr-body.md').write_text('# Phase 22: regression passed; explicit technical acceptance pending\n\n'+text+'\nReview `artifacts/phase22/integration/v38-guard-regression/` for all reports, source assessments, audit and acceptance proposal. Seal65 preserves new evidence after all64 preceding seals.\n\nCI: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34697303579\nDocs: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34697303580\n')
print('Owning docs now bind the actual regression result and pending explicit acceptance.')
