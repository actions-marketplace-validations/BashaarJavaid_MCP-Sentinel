import collections,json,sys,time
from pathlib import Path
sys.path.insert(0,'/private/tmp/mcp-phase22-options/src')
from sentinel.static import workers
counts=collections.Counter()
output=Path('/private/tmp/mcp-phase22-options/artifacts/phase22/integration/v5-auth-fixed-mutation-native-profile-e87b7c9/credential-replacement-counts.json')
if sys.argv[-1]=='SENT-016':
 from sentinel.static.rules import sent016
 original=sent016.replace
 def counted(value,**changes):
  caller=sys._getframe(1).f_code.co_name
  counts['replace_calls']+=1;counts[caller+':replace_calls']+=1
  if all(getattr(value,key)==replacement for key,replacement in changes.items()):
   counts['unchanged_replace_calls']+=1;counts[caller+':unchanged_replace_calls']+=1
  if counts['replace_calls']%10000==0:output.write_text(json.dumps(dict(counts),indent=2)+'\n')
  return original(value,**changes)
 sent016.replace=counted
started=time.monotonic();used=time.process_time()
try:workers._worker()
finally:
 (output.parent/('worker-'+sys.argv[-1]+'-timing.json')).write_text(json.dumps({'rule':sys.argv[-1],'wall_seconds':time.monotonic()-started,'cpu_seconds':time.process_time()-used},indent=2)+'\n')
 if counts:output.write_text(json.dumps(dict(counts),indent=2)+'\n')
