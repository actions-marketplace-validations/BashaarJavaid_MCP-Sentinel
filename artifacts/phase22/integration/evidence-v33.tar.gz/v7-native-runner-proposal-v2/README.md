# Proposed bounded Linux historical measurement

Explicit execution decision pending. No workflow change or dispatch has occurred.

The local strict gate remains failed:43/45 complete, two native timeouts and one
native-completed wall overrun. The subsequent copy-skipping experiment completed
only2/6 and was reverted; all source bytes now match e87b7c9. No deadline waiver
or pooled success is proposed.

The attached exact CI patch adds an optional manual job to the existing workflow.
Normal quality/package/Docker/isolation jobs remain unchanged for ordinary runs;
the manual benchmark selection skips those jobs to avoid a duplicate matrix.
The job checks out62987a6, runs the existing native historical runner sequentially,
and enforces the original120-second native and end-to-end limit plus20 condition
hits and zero matching fixed/control alerts. It stops after at most two entire
batches, with the second requiring the first to pass. Its190-minute job ceiling
includes the180-minute maximum nominal scan budget and setup. Runner environment
and all raw outcomes will be retained; no hardware-isolation guarantee is claimed.

This authorizes no fresh-corpus evaluation, paid calls, target execution, tested
Git environment change, merge or release. Fresh freeze and final acceptance remain
separate decisions. See packet.json, ci.patch and gate.py for exact identities and
commands. Normal final quality and other authorized closeout work continue locally.
