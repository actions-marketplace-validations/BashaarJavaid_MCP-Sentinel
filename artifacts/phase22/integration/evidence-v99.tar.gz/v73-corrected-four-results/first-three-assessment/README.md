# First 18 corrected-source observations

This is a partial result from the approved 24-observation V73 experiment at
`cec0322e904bbf63c33cd95796e7289101a93e5d`. The six FAF observations remain outside
this partial assessment; this packet does not close the experiment or Phase 22.

[Validation](validation.json) verifies 18 completed observations and nine entire
ordered report pairs. [Source assessment](assessment.json) passes the frozen
narrow conditions for no-bash, Lightning and Engram, retaining all 260 findings,
38,372 diagnostic occurrences, 270 surfaces and 1,971 source contexts.
[Complete differences](report-difference-assessment.json) cover both original
`2e0efb2` and preceding `4145d35` reports, with only the 11 approved volatile
fields excluded. Full ordered before/after arrays remain in the adjacent gzip
files; no sorting or diagnostic omission changes the equality gate.

Lightning's fixed/safe candidate now states initial private-literal IPv4
rejection. The V72 rubric expressly permits that qualifier when the actual
link-local rejection and caller/guard/sink identity are established; the
[retained source](lightning-caller-guard-sink-source.json) supplies that proof.
The provisional runner recognizes only the older link-local wording and still
records a failed provisional condition. Its raw result is preserved; the final
source assessment applies the already approved rubric. DNS, redirects,
rebinding and broader IPv6 safety remain unestablished.

No-bash retains its lexical-boundary/physical-containment distinction. Engram
retains its initial home guard and reconstructed-use uncertainty. All original
fresh failures and unmatched findings remain. The 181 earlier-language
observations are excluded and unapproved; no paid call or target execution ran.
