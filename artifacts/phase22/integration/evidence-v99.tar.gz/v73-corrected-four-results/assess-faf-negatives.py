"""Assess completed first FAF fixed/safe outputs; no scanner or target execution."""
import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
DEST = OUT / 'first-faf-negatives-assessment'
OLD = OUT.parent / 'v70-uncapped-four-results/final-assessment'
PREP = OUT.parent / 'v72-prototype-property-correction'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value):
    with (DEST / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

inv = read(DEST/'inventory.json')
validation = read(DEST/'validation.json')
assert validation['passed'] and validation['completed']==2 and len(inv['rows'])==2
assert [r['input_id'] for r in inv['rows']]==['faf-read-root-fixed','faf-read-root-safe']
proof = read(OUT/'faf-fixed-named-source-review.json')
assert proof['supported_narrow_fixed_qualification']
assert inv['rows'][0]['report_sha256']==proof['report_sha256']
old_inv = read(OLD/'inventory.json')
previous = read(OLD/'source-context-assessment.json')['contexts']
roles = {c['source']['path']:c['assessment'] for c in previous.values() if c['source']['case_id']=='faf-read-root'}
fixed_proof = proof['assessment']
for path in ('src/cli.ts','src/index.ts','src/server.ts','src/handlers/tools.ts'):
    roles[path] = ('FAF entry, handler instance, SDK registration or tool dispatch. Constructor '
        'parameter-property support enables the actual selected read analysis. Two unnamed '
        'ambiguous-dispatch surfaces and independent static-binding limitations remain. '
        'Flow-location lists include accumulated source contexts, not an ordered runtime trace. '
        'Other branches, dynamic imports, indexed values and unresolved calls remain separate. ' + fixed_proof)
roles['src/handlers/fileHandler.ts'] = ('FAF read/write handlers. Only read131 is the selected '
    'condition. The qualified write and generic mkdir candidates remain outside it. ' + fixed_proof)
roles['src/utils/safe-path.ts'] = fixed_proof
snapshot = inv['rows'][0]['snapshot']
assert all(r['snapshot']==snapshot for r in inv['rows'])
for name,binding in proof['anchors'].items():
    assert inv['source_files'][snapshot][name]==binding['source_sha256']
contexts={}
for key,c in inv['contexts'].items():
    before=previous.get(key)
    if before:
        assert before['source']==c
    assert c['path'] in roles,c['path']
    contexts[key]={'source':c,'assessment':roles[c['path']],
        'prior_identical_source_context':before is not None,
        'disposition':'Retain exact source role and unresolved operation. Narrow ordinary-file qualification only; no broad physical or runtime safety.'}
write('source-context-assessment.json',{'contexts':contexts,'count':len(contexts),'unassessed':0,
    'prior_source_assessment_sha256':sha(OLD/'source-context-assessment.json'),
    'named_fixed_source_review_sha256':sha(OUT/'faf-fixed-named-source-review.json')})
findings,diagnostics,surfaces,rows=[],[],[],[]
qualifier='The source enforces a lexical directory boundary on this path, but physical containment through symlinks is not established on every path.'
for row,v in zip(inv['rows'],validation['observations'],strict=True):
    assert row['input_id']==v['input_id'] and row['report_sha256']==v['report_sha256']
    old_row=next(r for r in old_inv['rows'] if r['input_id']==row['input_id'] and r['batch']=='first')
    assert row['surfaces']==old_row['surfaces']
    named=[]
    for index,item in enumerate(row['findings']):
        f=item['finding'];c=contexts[item['context']]['source']
        assert f['rule_id']=='SENT-012' and all(k in contexts for k in item['flow_contexts'])
        selected=c['path']=='src/handlers/fileHandler.ts' and c['line']==131
        qualified=selected and f['description']==qualifier
        assessment=(fixed_proof + (' The frozen inside-root safe control is admitted to this same checked return/read route, subject to the unchanged size/readability prerequisites.' if row['label']=='safe' else '')) if selected else (
            f"Source-bound filesystem candidate at {c['path']}:{c['line']}: {f['evidence']['snippet']}. "
            'The exact statement and full flow-context list are retained with source roles. This '
            'operation is outside the selected faf_read read131 condition; it supplies neither an '
            'extra named hit nor a matching negative alert. Its own caller/branch/guard assumptions '
            'and unresolved state remain review limits. Generic or qualified wording is retained '
            'without inferring an independent vulnerability, false-positive verdict or runtime proof.')
        result={'input_id':row['input_id'],'batch':'first','report_sha256':row['report_sha256'],
            'index':index,**item,'named_sink':selected,'matches_condition':selected and not qualified,
            'supported_qualified_negative':qualified,'assessment':assessment,
            'disposition':'supported qualified named negative' if qualified else 'named qualification failure' if selected else 'unmatched broader filesystem candidate; retained for review'}
        if selected:
            assert f['evidence']['snippet']=="fs.readFile(filePath, 'utf8')"
            flow={(contexts[k]['source']['path'],contexts[k]['source'].get('line')) for k in item['flow_contexts']}
            assert {('src/server.ts',91),('src/utils/safe-path.ts',125),('src/utils/safe-path.ts',179)} <= flow
            named.append(result)
        findings.append(result)
    support=len(named)==1 and all(f['supported_qualified_negative'] for f in named)
    matching=[f['finding']['dedup_key'] for f in named if f['matches_condition']]
    for d in row['diagnostics']:
        assert d['context'] in contexts
        diagnostics.append({'input_id':row['input_id'],'batch':'first','report_sha256':row['report_sha256'],
            **d,'assessment_context':d['context'],'disposition':'Retain exact unresolved operation and source role; no suppression or safety inference.'})
    for s in row['surfaces']:
        surfaces.append({'input_id':row['input_id'],'batch':'first','report_sha256':row['report_sha256'],**s,
            'assessment':'Unchanged unnamed ambiguous-dispatch surface. CLI lists five examined flow rules; index lists none. Actual selected read support does not resolve metadata, every tool route, or the unknown surface denominator.'})
    rows.append({**v,'case_id':row['case_id'],'label':row['label'],'coverage':row['coverage'],
        'matching_keys':matching,'named_negative_false_alert':bool(matching),
        'supported_qualified_negative':support,'narrow_negative_gate_passed':support and not matching})
write('finding-source-assessment.json',{'rows':findings,'count':len(findings),'unassessed':0})
write('diagnostic-source-assessment.json',{'rows':diagnostics,'count':len(diagnostics),
    'by_kind':dict(Counter(d['kind'] for d in diagnostics)),'unmapped':0})
write('surface-source-assessment.json',{'rows':surfaces,'count':len(surfaces),'unassessed':0,'total_possible_surfaces':'unknown'})
changes=[]
for reference in ('original','preceding'):
    inventory=read(DEST/f'{reference}-report-difference-inventory.json')
    assert inventory['complete_ordered_reconstruction_passed']
    with gzip.open(DEST/f'{reference}-complete-report-differences.jsonl.gz','rt') as stream:
        records=list(map(json.loads,stream))
    assert len(records)==2
    for record in records:
        for delta in record['changes']:
            path='/'.join(map(str,delta['path']))
            if path=='findings':
                assert delta['before']==[]
                judgment='Every newly emitted raw filesystem candidate is individually source-assessed; only the actual read131 enters this frozen negative condition. Its qualification remains explicit.'
            elif path in ('warnings','static_analysis/coverage/unresolved_flows'):
                judgment='Full ordered before/after diagnostics retained. Current occurrences all have source roles; downstream traversal follows newly supported constructors. Removed class/flow-call barriers do not resolve independent binding, loop termination, SDK, filesystem or dynamic-value uncertainties.'
            elif path=='static_analysis/coverage/surfaces':
                assert reference=='original' and delta['before']==[] and len(delta['after'])==2
                judgment='Two unresolved registration surfaces added since original source; individually assessed with no invented coverage denominator.'
            else:
                assert path in {'review_activity/static/candidate_count','review_activity/static/unreviewed_count',
                    'static_analysis/rule_outcomes','static_analysis/total_matches','summary/by_severity/Medium',
                    'summary/by_status/needs_review','summary/total'},path
                judgment='Raw candidate/status/rule accounting follows the newly emitted needs_review filesystem candidates; these totals are not named-condition alerts or model-reviewed results.'
            changes.append({'reference':reference,'input_id':record['input_id'],'batch':'first','path':delta['path'],
                'assessment':judgment,'full_ordered_delta_sha256':sha(DEST/f'{reference}-complete-report-differences.jsonl.gz')})
write('report-difference-assessment.json',{'rows':changes,'completed_report_comparisons':4,
    'references':['2e0efb2','4145d35'],'unassessed_changes':0,'entire_ordered_reconstruction_verified':True})
write('assessment.json',{'scanner':validation['scanner'],'proposal_sha256':sha(PREP/'evaluation-proposal.json'),
    'approval_sha256':sha(PREP/'evaluation-authorization.json'),'rubric_sha256':sha(PREP/'scoring-rubric.json'),
    'completed':2,'rows':rows,'narrow_negative_gates_passed':sum(r['narrow_negative_gate_passed'] for r in rows),
    'source_assessment_complete_for_these_reports':True,'complete_report_difference_assessment_pending':False,
    'finding_count':len(findings),'diagnostic_count':len(diagnostics),'surface_count':len(surfaces),'source_context_count':len(contexts),
    'FAF_repeats_pending':True,'four_repository_sequence_complete':False,'budget_closed':False,'paid_calls':0,
    'target_execution':False,'technical_acceptance_received':False,'phase22_complete':False,
    'qualification':'Only completed first fixed/safe observations. Narrow ordinary-file source qualification does not establish general physical/runtime safety, normal1800-second completion, or the pending repeats and earlier-language compatibility.',
    'evidence_sha256':{n:sha(DEST/n) for n in ['inventory.json','validation.json','source-context-assessment.json',
        'finding-source-assessment.json','diagnostic-source-assessment.json','surface-source-assessment.json','report-difference-assessment.json']}})
print('First FAF fixed/safe source assessment:',sum(r['narrow_negative_gate_passed'] for r in rows),'of2 narrow negative gates passed; all findings,diagnostics,surfaces and full differences retained. Repeats remain pending.')
