"""Source-assess one immutable completed report; never scan or alter the active run."""
import gzip
import hashlib
import json
import tarfile
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
DEST = OUT / 'first-faf-assessment'
PREP = OUT.parent / 'v72-prototype-property-correction'
OLD = OUT.parent / 'v70-uncapped-four-results/first-faf-assessment'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value):
    with (DEST / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

inv = read(DEST / 'inventory.json')
validation = read(DEST / 'validation.json')
previous = read(OLD / 'source-context-assessment.json')['contexts']
old_inv = read(OLD / 'inventory-source-corrected.json')
assert validation['passed'] and len(inv['rows']) == 1
row = inv['rows'][0]
v = validation['observations'][0]
assert row['input_id'] == v['input_id'] == 'faf-read-root-vulnerable'
assert row['report_sha256'] == v['report_sha256']
assert inv['source_files'] == old_inv['source_files']
roles = {c['source']['path']: c['assessment'] for c in previous.values()}
named_proof = ('The registered server.ts91 CallToolRequestSchema handler passes request.params.name '
    'and arguments to this.toolHandler.callTool at94-96. The actual instance is constructed at57; '
    'FafToolHandler uses the now-supported private engineAdapter parameter property. The faf_read '
    'arm at tools.ts694-701 passes args to fileHandlers.faf_read at696, bound to handleFafRead. '
    'That function destructures path at fileHandler.ts99 and uses the same filePath at fs.readFile127. '
    'PathValidator normalizes and denies traversal/system prefixes, but does not enforce '
    'FAF_ALLOWED_ROOTS. The frozen ordinary readable, size-admitted /srv/faf-outside/fixture.txt '
    'passes those checks and reaches the selected read outside /srv/faf-project. The actual '
    'SENT-012 finding binds CLI/server registration and this sink; it passes this one vulnerable '
    'condition. No target execution, exploit validation or general tool coverage is established.')
for path in ('src/cli.ts', 'src/index.ts', 'src/server.ts'):
    roles[path] = ('FAF entry and SDK registration. Current SENT-012 analysis emits the named read '
        'with CLI/server flow evidence. Two unnamed ambiguous-dispatch surfaces and an independent '
        'static-binding warning for this.toolHandler.callTool remain. These metadata/binding '
        'limitations are retained separately from source-supported named sink detection. ' + named_proof)
roles['src/handlers/tools.ts'] = ('FAF listing and dispatch: the supported constructor parameter '
    'property now allows the actual handler receiver into flow analysis. The selected arm is '
    'source-bound below. Dynamic imports, indexed values, mutable computed fields, formatting, '
    'other tool paths and unresolved calls retain their exact uncertainty. A file-only dynamic '
    'import diagnostic has no invented line. ' + named_proof)
roles['src/handlers/fileHandler.ts'] = ('FAF read/write handlers. Only the selected read is scored; '
    'mkdir/write candidates remain separate and require their own conditions. Validation, size, '
    'Promise.race, and later metadata diagnostics remain visible. ' + named_proof)
contexts = {}
for key, source in inv['contexts'].items():
    before = previous.get(key)
    if before:
        assert source == before['source']
    assert source['path'] in roles
    contexts[key] = {'source': source, 'assessment': roles[source['path']],
        'prior_identical_source_context': before is not None,
        'disposition': 'Exact source role and unresolved statement/binding retained; no general safety or reachability inference.'}
assert len(contexts) == 2380
write('source-context-assessment.json', {'contexts': contexts, 'count': len(contexts),
    'prior_identical_contexts': sum(c['prior_identical_source_context'] for c in contexts.values()),
    'unassessed': 0, 'prior_source_assessment_sha256': sha(OLD / 'source-context-assessment.json')})

findings = []
for index, item in enumerate(row['findings']):
    f = item['finding']
    c = contexts[item['context']]['source']
    assert f['rule_id'] == 'SENT-012' and f['status'] == 'needs_review'
    assert all(key in contexts for key in item['flow_contexts'])
    named = c['path'] == 'src/handlers/fileHandler.ts' and c['line'] == 127
    if named:
        assert f['evidence']['snippet'] == "fs.readFile(filePath, 'utf8')"
        assert any(contexts[k]['source']['path'] == 'src/server.ts' and contexts[k]['source']['line'] == 91 for k in item['flow_contexts'])
    operation = f['evidence']['snippet']
    findings.append({'input_id': row['input_id'], 'batch': row['batch'], 'report_sha256': row['report_sha256'],
        'index': index, **item, 'named_sink': named, 'matches_condition': named,
        'assessment': named_proof if named else (
            f"Source-bound filesystem candidate at {c['path']}:{c['line']}: {operation}. "
            'Its entire caller-flow contexts and source role are retained. This operation is not '
            'the selected faf_read read at fileHandler.ts127; it supplies no extra named-condition '
            'hit. Branch choices, operator defaults, external operations and unresolved state '
            'remain route-specific uncertainties. No independent vulnerability or false-positive '
            'verdict is inferred from the generic missing-containment description.'),
        'disposition': 'supported selected vulnerable sink' if named else 'unmatched broader filesystem candidate; retained for review'})
assert len(findings) == 89 and sum(f['matches_condition'] for f in findings) == 1
write('finding-source-assessment.json', {'rows': findings, 'count': 89, 'named_matches': 1, 'unmatched': 88, 'unassessed': 0})
diagnostics = [{'input_id': row['input_id'], 'batch': row['batch'], 'report_sha256': row['report_sha256'],
    **d, 'assessment_context': d['context'], 'disposition': 'Retain exact unresolved operation and source role; no inferred safety or suppression.'} for d in row['diagnostics']]
assert len(diagnostics) == 8174 and all(d['context'] in contexts for d in diagnostics)
write('diagnostic-source-assessment.json', {'rows': diagnostics, 'count': len(diagnostics),
    'by_kind': dict(Counter(d['kind'] for d in diagnostics)), 'unmapped': 0})
assert row['surfaces'] == old_inv['rows'][0]['surfaces']
surfaces = [{**s, 'assessment': ('Unchanged unnamed ambiguous-dispatch surface at ' + s['surface']['location']['path']
    + '. CLI lists five examined flow rules; index lists none. The shared server handler remains '
    'source-bound, and the actual report now supplies the selected read finding. No per-tool '
    'metadata resolution, invented name or coverage denominator is inferred.')} for s in row['surfaces']]
write('surface-source-assessment.json', {'rows': surfaces, 'count': 2, 'unassessed': 0,
    'total_possible_surfaces': 'unknown', 'workspace': row['coverage']['workspace']})

archive = OUT.parent / 'v43-four-fresh-preparation/research/source-archives/faf-vulnerable.tar.gz'
anchors = {}
with tarfile.open(archive) as stream:
    for path, ranges in {'src/handlers/tools.ts': [(20,32),(690,708)], 'src/server.ts': [(53,59),(86,110)],
                         'src/handlers/fileHandler.ts': [(11,49),(55,68),(95,144),(250,275)]}.items():
        member = next(m for m in stream if m.isfile() and m.name.endswith('/' + path))
        data = stream.extractfile(member).read()
        lines = data.decode().splitlines()
        digest = hashlib.sha256(data).hexdigest()
        assert digest == inv['source_files'][row['snapshot']][path]
        anchors[path] = {'source_sha256': digest, 'ranges': {f'{a}-{b}': '\n'.join(
            f'{i+1}: {lines[i]}' for i in range(a-1, min(b,len(lines)))) for a,b in ranges}}
write('named-source-assessment.json', {'archive_sha256': sha(archive), 'anchors': anchors,
    'assessment': named_proof, 'prerequisites': read(PREP / 'scoring-rubric.json')['qualification_review']['faf-read-root']})

differences = []
for reference in ('original', 'preceding'):
    inventory = read(DEST / f'{reference}-report-difference-inventory.json')
    assert inventory['complete_ordered_reconstruction_passed']
    with gzip.open(DEST / f'{reference}-complete-report-differences.jsonl.gz', 'rt') as stream:
        records = list(map(json.loads, stream))
    assert len(records) == 1
    for change in records[0]['changes']:
        path = '/'.join(map(str,change['path']))
        if path == 'findings':
            assert change['before'] == [] and len(change['after']) == 89
            judgment = 'All 89 newly emitted candidates individually source-assessed; exactly one matches the selected condition.'
        elif path in ('warnings', 'static_analysis/coverage/unresolved_flows'):
            judgment = ('Full ordered before/after diagnostics retained. Current occurrences all map to exact source roles; '
                'new traversal reaches downstream dispatch, command/parser/filesystem paths after constructor support. '
                'Removed unsupported-class/call diagnostics do not certify other bindings. Original source judgments '
                'remain bound to their historical reports; remaining dynamic/control/indexed/SDK uncertainties are retained.')
        elif path == 'static_analysis/coverage/surfaces':
            assert reference == 'original' and change['before'] == [] and len(change['after']) == 2
            judgment = 'Two unresolved registration surfaces added since original source; both individually assessed, with unknown total denominator.'
        else:
            assert path in {'review_activity/static/candidate_count','review_activity/static/unreviewed_count',
                'static_analysis/rule_outcomes','static_analysis/total_matches','summary/by_severity/Medium',
                'summary/by_status/needs_review','summary/total'}
            judgment = 'Aggregate candidate/status/rule accounting changes with the 89 raw unreviewed SENT-012 findings; not 89 condition hits or model-reviewed results.'
        differences.append({'reference': reference, 'path': change['path'], 'assessment': judgment,
            'full_ordered_delta_sha256': sha(DEST / f'{reference}-complete-report-differences.jsonl.gz')})
write('report-difference-assessment.json', {'rows': differences, 'completed_report_comparisons': 2,
    'references': ['2e0efb2','4145d35'], 'unassessed_changes': 0, 'entire_ordered_reconstruction_verified': True,
    'qualification': 'Source-attributed review, not isolation of a performance effect; no additional exclusions.'})
write('assessment.json', {'scanner': validation['scanner'], 'proposal_sha256': sha(PREP / 'evaluation-proposal.json'),
    'approval_sha256': sha(PREP / 'evaluation-authorization.json'), 'rubric_sha256': sha(PREP / 'scoring-rubric.json'),
    'completed': 1, 'input_id': row['input_id'], 'report_sha256': row['report_sha256'],
    'whole_seconds': v['timing']['elapsed_seconds'], 'cleanup_verified': True,
    'within_normal_1800_policy': False, 'uncapped_execution_gate_passed': True,
    'source_assessment_complete_for_this_report': True, 'complete_report_difference_assessment_pending': False,
    'vulnerable_hit': True, 'named_sink_support_established': True, 'vulnerable_detection_gate_passed': True,
    'fixed_and_safe_pending': True, 'repeat_pending': True, 'finding_count': 89,
    'diagnostic_count': 8174, 'surface_count': 2, 'source_context_count': 2380,
    'four_repository_sequence_complete': False, 'budget_closed': False, 'paid_calls': 0,
    'target_execution': False, 'technical_acceptance_received': False, 'phase22_complete': False,
    'qualification': 'One completed observation of the sole approved active sequence; selected vulnerable read now detected. Fixed/safe and repeats remain pending. Same-agent source assessment, no runtime or broad accuracy claim.',
    'evidence_sha256': {n: sha(DEST / n) for n in ['inventory.json','validation.json',
        'source-context-assessment.json','finding-source-assessment.json','diagnostic-source-assessment.json',
        'surface-source-assessment.json','named-source-assessment.json','report-difference-assessment.json']}})
print('First FAF source assessment: selected vulnerable hit; 89 findings,8174 diagnostics,2 surfaces,2380 contexts and both full reference differences retained. Fixed/safe/repeats pending.')
