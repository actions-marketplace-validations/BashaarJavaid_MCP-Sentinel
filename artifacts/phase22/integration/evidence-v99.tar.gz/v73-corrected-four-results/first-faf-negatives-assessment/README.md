# First corrected FAF negatives — partial assessment

Both first fixed/safe reports pass the frozen narrow condition at scanner
`cec0322e904bbf63c33cd95796e7289101a93e5d`. Each identifies the actual
`fs.readFile` at `src/handlers/fileHandler.ts:131` and explicitly qualifies the
path as lexically confined, with physical/symlink uncertainty retained.
There are **zero matching named-condition alerts** and **two supported qualified
negatives**, not quiet unsupported outputs.

The fixed observation took **2,371.140097 seconds**; safe took
**2,615.573678 seconds**. Both completed with verified cleanup and exceeded the
unchanged normal **1,800-second** policy. No speedup is established.

All **178 findings, 16,544 diagnostic occurrences, four unresolved surfaces and
2,430 unique source contexts** are retained and source-assessed. Only one read
per report enters the selected condition. Other filesystem candidates remain
review candidates; no general accuracy or runtime safety is claimed.

- [Assessment](assessment.json), [source inventory](inventory.json) and
  [exact named source proof](../faf-fixed-named-source-review.json).
- [Finding judgments](finding-source-assessment.json),
  [diagnostic judgments](diagnostic-source-assessment.json) and
  [surface judgments](surface-source-assessment.json).
- [Complete ordered differences](report-difference-assessment.json) against
  original `2e0efb2` and preceding `4145d35`.

The three FAF repeats remain pending in the same sole approved experiment.
Earlier-language compatibility, explicit technical acceptance and final
closeout remain outstanding. Zero new paid calls, retries, profiles or target
executions. Phase 22 remains incomplete.
