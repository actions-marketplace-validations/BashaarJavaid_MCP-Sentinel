# First corrected FAF observation — partial assessment

At scanner `cec0322e904bbf63c33cd95796e7289101a93e5d`, the first vulnerable
FAF observation completed in **2,297.758465 seconds**, with verified cleanup.
The selected `faf_read` call reaches the reported `fs.readFile` at
`src/handlers/fileHandler.ts:127`: **one named vulnerable hit**. Its exact
caller, exported handler binding and unchanged source prerequisites are retained.

All **89 findings, 8,174 diagnostic occurrences, two unresolved surfaces and
2,380 source contexts** are source-assessed. The other 88 filesystem candidates
are outside the selected condition and remain review candidates. Unnamed
registration surfaces and the independent static-binding warning remain;
this is not complete tool discovery, general accuracy or runtime validation.

- [Assessment](assessment.json), [source inventory](inventory.json) and
  [named source evidence](named-source-assessment.json).
- [Actual export binding and diagnostic deltas](source-binding-and-diagnostic-supplement.json).
  This also records the initial helper's empty out-of-range export excerpt.
- [Complete reference differences](report-difference-assessment.json) against
  original `2e0efb2` and preceding `4145d35`; all ordered arrays are preserved.
- [Inventory-helper correction](inventory-helper-correction.json): the
  conceptual dynamic-import diagnostic retains verified file-only attribution.

This is one completed observation within the sole approved 24-observation run.
FAF fixed/safe support and its three ordered repeats remain pending here. The
normal **1,800-second** deadline is unchanged and was exceeded; no speedup is
established. Zero new paid calls, retries, profiles or target executions.
Earlier-language compatibility, explicit technical acceptance and final closeout
remain outstanding. Phase 22 is incomplete.
