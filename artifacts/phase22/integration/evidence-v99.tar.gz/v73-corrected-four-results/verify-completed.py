"""Verify stopped owned work and unchanged tested source after the sole approved run."""
import hashlib
import importlib.metadata
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
PREP=OUT.parent/'v72-prototype-property-correction'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
command=lambda *args:subprocess.check_output(args,cwd=ROOT,text=True)
intake=read(OUT.parent/'v73-corrected-regression-intake.json')
proposal=read(PREP/'evaluation-proposal.json')
assessment=read(OUT/'final-assessment/assessment.json')
execution=read(OUT/'execution.json')
assert assessment['all_four_narrow_gates_passed'] and assessment['entire_ordered_pairs_equal']==12
assert execution['budget_closed'] and execution['completed']==24 and execution['remaining']==0
assert execution['returncode']==0 and execution['paid_calls']==0
assert command('git','rev-parse','HEAD').strip()==intake['head']
assert not command('git','diff','HEAD')
assert command('git','worktree','list','--porcelain')==intake['worktrees']
assert not command('git','-C','/Users/bashaarjavaid/Projects/MCP-Sentinel','status','--short')
frozen=Path(proposal['frozen_checkout'])
assert not command('git','-C',str(frozen),'status','--short')
inputs=read(PREP/'local-checks.json')['candidate_engineering_files_sha256']
assert len(inputs)==303
for name,digest in inputs.items():
    assert sha(ROOT/name)==sha(frozen/name)==digest,name
for name,digest in proposal['files_sha256'].items():
    assert sha(ROOT/name)==digest,name
user_files=intake['protected_user_files_sha256']
assert len(user_files)==10
assert set(command('git','ls-files','--others','--exclude-standard').splitlines())==set(user_files)
for name,digest in user_files.items():
    assert sha(ROOT/name)==digest,name
os.chdir(frozen)
sys.path[:0]=[str(frozen/'src'),str(frozen)]
from scripts.phase20_measurements import scanner_identity
from sentinel.static import engine,workers,typescript_path_flow,semgrep_adapter
assert scanner_identity()==proposal['scanner']
assert engine.STATIC_TIMEOUT_SECONDS==1800 and semgrep_adapter.SEMGREP_TIMEOUT_SECONDS==10
imports={m.__name__:m.__file__ for m in (engine,workers,typescript_path_flow,semgrep_adapter)}
assert all(Path(p).is_relative_to(frozen/'src') for p in imports.values())
runtime={n:importlib.metadata.version(n) for n in intake['runtime']}
assert runtime==intake['runtime']
processes={}
for line in command('ps','-axo','pid=,ppid=,command=').splitlines():
    parts=line.strip().split(None,2)
    if len(parts)==3:processes[int(parts[0])]={'parent':int(parts[1]),'command':parts[2]}
ancestors=set();pid=os.getpid()
while pid in processes and pid not in ancestors:
    ancestors.add(pid);pid=processes[pid]['parent']
markers=['phase22-check.py','v73-','v72-','v71-','/launch.py','/evaluate.py','mcp-phase22-four-fresh-']
owned=[{'pid':pid,**row} for pid,row in processes.items() if pid not in ancestors
    and any(m in row['command'] for m in markers) and ('phase22' in row['command'] or 'v73-' in row['command'])]
managed=command('docker','ps','-aq','--filter','label=com.securemcp.sentinel=true').splitlines()
named=command('docker','ps','-aq','--filter','name=sentinel').splitlines()
assert not owned and not managed and not named,(owned,managed,named)
result={'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),
    'scanner':proposal['scanner'],'imports':imports,'runtime':runtime,
    'engineering_inputs_verified':303,'proposal_bound_files_verified':len(proposal['files_sha256']),
    'protected_user_files_sha256':user_files,'worktrees_unchanged':True,'main_clean':True,
    'integration_head':intake['head'],'owned_processes':owned,'managed_container_ids':managed,
    'sentinel_named_container_ids':named,'available_bytes':shutil.disk_usage(ROOT).free,
    'normal_static_deadline_seconds':1800,'normal_semgrep_rule_timeout_seconds':10,
    'experimental_semgrep_rule_timeout_seconds':0,'completed_observations':24,
    'ordered_pairs_equal':12,'budget_closed':True,'remaining':0,'new_paid_calls':0,
    'assessment_sha256':sha(OUT/'final-assessment/assessment.json'),'execution_sha256':sha(OUT/'execution.json'),
    'technical_acceptance_received':False,'phase22_complete':False,
    'qualification':'Post-run read-only ownership/source verification. No unrelated work terminated. Existing2450/36 engineering remains source-bound; no new hosted code pass, profile, retry or target execution. Earlier-language compatibility remains unapproved.'}
with (OUT/'completion-verification.json').open('x') as stream:
    json.dump(result,stream,indent=2);stream.write('\n')
print('Closed24-observation budget,12ordered pairs,303tested files,10protected documents and stopped owned work verified; normal1800/10policy intact.')
