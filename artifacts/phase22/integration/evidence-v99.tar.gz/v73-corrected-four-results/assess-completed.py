"""Assemble source judgments only after all24 reports and12 ordered pairs pass validation."""
import copy
import gzip
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
DEST = OUT/'final-assessment'
PREP = OUT.parent/'v72-prototype-property-correction'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name,value):
    with (DEST/name).open('x') as stream:
        json.dump(value,stream,indent=2)
        stream.write('\n')

def deltas(folder,reference):
    with gzip.open(folder/f'{reference}-complete-report-differences.jsonl.gz','rt') as stream:
        return {(r['input_id'],r['batch']):r for r in map(json.loads,stream)}

validation=read(DEST/'validation.json')
inventory=read(DEST/'inventory.json')
execution=read(OUT/'execution.json')
assert validation['passed'] and validation['completed']==24 and validation['entire_ordered_pairs_equal']==12
assert validation['budget_closed'] and execution['budget_closed'] and execution['completed']==24
assert execution['returncode']==0 and len(inventory['rows'])==24
spec=importlib.util.spec_from_file_location('bound_runner',PREP/'evaluate.py')
runner=importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
clean=lambda value:runner.supervisor.clean(value,runner.prior.EXCLUDED)
fragments={}
bases={}
contexts={}
source_files={}
for name in ('first-three-assessment','first-faf-assessment','first-faf-negatives-assessment'):
    folder=OUT/name
    inv=read(folder/'inventory.json')
    assessment=read(folder/'assessment.json')
    assert not assessment['complete_report_difference_assessment_pending']
    context_packet=read(folder/'source-context-assessment.json')
    assert context_packet['unassessed']==0
    for key,value in context_packet['contexts'].items():
        assert value['source']==inv['contexts'][key]
        if key in contexts:
            assert contexts[key]['source']==value['source']
        contexts[key]={**copy.deepcopy(value),'reused_source_assessment_sha256':sha(folder/'source-context-assessment.json')}
    for snapshot,files in inv['source_files'].items():
        if snapshot in source_files:
            assert source_files[snapshot]==files
        source_files[snapshot]=files
    fragment={'folder':folder,'inventory':inv,'assessment':assessment,
        'findings':read(folder/'finding-source-assessment.json')['rows'],
        'surfaces':read(folder/'surface-source-assessment.json')['rows'],
        'deltas':{reference:deltas(folder,reference) for reference in ('original','preceding')}}
    fragments[name]=fragment
    for row in inv['rows']:
        key=row['input_id'],row['batch']
        assert key not in bases
        bases[key]=(fragment,row)
assert len(bases)==21
assert {k:v['source'] for k,v in contexts.items()}==inventory['contexts']
assert source_files==inventory['source_files']
write('source-context-assessment.json',{'contexts':contexts,'count':len(contexts),'unassessed':0,
    'qualification':'All final contexts/source bytes exactly equal the previously assessed immutable contexts. Same-agent source review; no new target execution.'})

findings,diagnostics,surfaces,rows=[],[],[],[]
for row,v in zip(inventory['rows'],validation['observations'],strict=True):
    key=row['input_id'],row['batch']
    basis_key=key if key in bases else (row['input_id'],'first')
    fragment,before=bases[basis_key]
    assert row['input_id']==v['input_id'] and row['report_sha256']==v['report_sha256']
    assert row['snapshot']==before['snapshot'] and row['label']==before['label']
    for field in ('findings','diagnostics','surfaces','coverage'):
        assert clean(row[field])==clean(before[field]),(key,field)
    if key!=basis_key:
        assert row['case_id']=='faf-read-root' and row['batch']=='repeat' and v['ordered_repeat_equal']
    prior_findings=[f for f in fragment['findings'] if (f['input_id'],f['batch'])==basis_key]
    named=[]
    for item,basis in zip(row['findings'],prior_findings,strict=True):
        assert clean(item['finding'])==clean(basis['finding'])
        assert item['context']==basis['context'] and item['flow_contexts']==basis['flow_contexts']
        result={**copy.deepcopy(basis),**item,'input_id':key[0],'batch':key[1],
            'report_sha256':row['report_sha256'],
            'source_assessment_sha256':sha(fragment['folder']/'finding-source-assessment.json'),
            'basis_report_sha256':before['report_sha256']}
        findings.append(result)
        if result['named_sink']:
            named.append(result)
    for d in row['diagnostics']:
        assert d['context'] in contexts
        diagnostics.append({'input_id':key[0],'batch':key[1],'report_sha256':row['report_sha256'],
            **d,'assessment_context':d['context'],'disposition':'Exact source-assessed unresolved operation retained; no inferred safety or suppression.'})
    for s in row['surfaces']:
        candidates=[x for x in fragment['surfaces'] if x['index']==s['index']
            and (x.get('input_id',basis_key[0]),x.get('batch',basis_key[1]))==basis_key]
        basis,=candidates
        assert basis['surface']==s['surface'] and basis['context']==s['context']
        surfaces.append({**copy.deepcopy(basis),**s,'input_id':key[0],'batch':key[1],
            'report_sha256':row['report_sha256'],'source_assessment_sha256':sha(fragment['folder']/'surface-source-assessment.json')})
    if row['case_id']=='faf-read-root' and row['label']=='vulnerable':
        support=fragment['assessment']['named_sink_support_established']
    else:
        prior_row=next(r for r in fragment['assessment']['rows'] if (r['input_id'],r['batch'])==basis_key)
        support=prior_row['supported_qualified_negative'] if row['label']!='vulnerable' else bool(named)
    matching=[f['finding']['dedup_key'] for f in named if f['matches_condition']]
    rows.append({**v,'case_id':row['case_id'],'label':row['label'],'snapshot':row['snapshot'],
        'coverage':row['coverage'],'matching_keys':matching,'named_sink_support_established':support,
        'supported_qualified_negative':support if row['label']!='vulnerable' else False,
        'named_negative_false_alert':bool(matching) if row['label']!='vulnerable' else None,
        'narrow_condition_passed':bool(matching) and support if row['label']=='vulnerable' else support and not matching,
        'source_assessment_sha256':sha(fragment['folder']/'assessment.json'),'basis_report_sha256':before['report_sha256']})
assert len(rows)==24
assert len(findings)==sum(len(r['findings']) for r in inventory['rows'])
assert len(diagnostics)==sum(len(r['diagnostics']) for r in inventory['rows'])
assert len(surfaces)==sum(len(r['surfaces']) for r in inventory['rows'])
write('finding-source-assessment.json',{'rows':findings,'count':len(findings),'unassessed':0,
    'named_condition_matches':sum(bool(f['matches_condition']) for f in findings)})
write('diagnostic-source-assessment.json',{'rows':diagnostics,'count':len(diagnostics),
    'by_kind':dict(Counter(d['kind'] for d in diagnostics)),'unmapped':0})
write('surface-source-assessment.json',{'rows':surfaces,'count':len(surfaces),'unassessed':0,
    'total_possible_surfaces':'unknown; no percentage inferred'})

differences=[]
for reference in ('original','preceding'):
    current=deltas(DEST,reference)
    assert len(current)==24 and read(DEST/f'{reference}-report-difference-inventory.json')['complete_ordered_reconstruction_passed']
    for key,delta in current.items():
        basis_key=key if key in bases else (key[0],'first')
        fragment,_=bases[basis_key]
        assert delta['changes']==fragment['deltas'][reference][basis_key]['changes'],(reference,key)
        differences.append({'reference':reference,'input_id':key[0],'batch':key[1],
            'current_report_sha256':delta['current_report_sha256'],'old_report_sha256':delta['old_report_sha256'],
            'basis_input_id':basis_key[0],'basis_batch':basis_key[1],'entire_ordered_changes_exactly_equal':True,
            'source_assessment_sha256':sha(fragment['folder']/'report-difference-assessment.json'),
            'full_ordered_delta_sha256':sha(DEST/f'{reference}-complete-report-differences.jsonl.gz')})
write('report-difference-assessment.json',{'rows':differences,'completed_report_comparisons':48,
    'references':['2e0efb2','4145d35'],'unassessed_changes':0,'entire_ordered_reconstruction_verified':True,
    'qualification':'Every complete ordered delta equals its source-assessed counterpart, after only the11 approved volatile exclusions. No sorting, report subset or new source novelty claim.'})
cases=[]
for case_id in read(PREP/'evaluation-proposal.json')['groups']:
    selected=[r for r in rows if r['case_id']==case_id]
    assert len(selected)==6
    batches={}
    for batch in ('first','repeat'):
        batch_rows=[r for r in selected if r['batch']==batch]
        assert [r['label'] for r in batch_rows]==['vulnerable','fixed','safe']
        batches[batch]={'vulnerable_hits':sum(bool(r['matching_keys']) for r in batch_rows if r['label']=='vulnerable'),
            'matching_negative_alerts':sum(len(r['matching_keys']) for r in batch_rows if r['label']!='vulnerable'),
            'supported_qualified_negatives':sum(r['supported_qualified_negative'] for r in batch_rows),
            'narrow_batch_gate_passed':all(r['narrow_condition_passed'] for r in batch_rows)}
    cases.append({'case_id':case_id,'batches':batches,'completed':6,'ordered_report_pairs_equal':3,
        'timings_seconds':[r['timing']['elapsed_seconds'] for r in selected],
        'narrow_repository_gate_passed':all(b['narrow_batch_gate_passed'] for b in batches.values())})
passed=sum(c['narrow_repository_gate_passed'] for c in cases)
write('assessment.json',{'scanner':validation['scanner'],'proposal_sha256':sha(PREP/'evaluation-proposal.json'),
    'approval_sha256':sha(PREP/'evaluation-authorization.json'),'rubric_sha256':sha(PREP/'scoring-rubric.json'),
    'completed':24,'entire_ordered_pairs_equal':12,'cases':cases,'rows':rows,
    'repository_gates_passed':passed,'repository_gates_required':4,'all_four_narrow_gates_passed':passed==4,
    'source_assessment_complete':True,'complete_report_difference_assessment_pending':False,
    'four_repository_sequence_complete':True,'budget_closed':True,'remaining_observation_budget':0,
    'execution_gate_passed':True,'finding_count':len(findings),'diagnostic_count':len(diagnostics),
    'surface_count':len(surfaces),'source_context_count':len(contexts),
    'beyond1800':sum(r['timing']['elapsed_seconds']>1800 for r in rows),
    'max_whole_seconds':max(r['timing']['elapsed_seconds'] for r in rows),
    'current_earlier_language_compatibility_established':False,'earlier_language_observations_excluded':181,
    'paid_calls':0,'target_execution':False,'technical_acceptance_received':False,'phase22_complete':False,
    'qualification':'Complete exposed regression under the one approved uncapped experiment. Narrow source-supported conditions only; all original fresh/held-out failures, broad safety/support limits and normal1800-second policy remain. No speedup, earlier-language compatibility, accepted limitation or technical acceptance is inferred.',
    'evidence_sha256':{n:sha(DEST/n) for n in ['inventory.json','validation.json','source-context-assessment.json',
        'finding-source-assessment.json','diagnostic-source-assessment.json','surface-source-assessment.json','report-difference-assessment.json']},
    'execution_sha256':sha(OUT/'execution.json'),
    'source_supplements_sha256':{str(p.relative_to(OUT)):sha(p) for p in [
        OUT/'faf-fixed-named-source-review.json',OUT/'first-faf-assessment/source-binding-and-diagnostic-supplement.json']}})
print(f'All24 reports,12 ordered pairs and48 full reference comparisons source-assessed;{passed}/4 narrow repository gates pass. Earlier-language approval, human acceptance and closeout remain.')
