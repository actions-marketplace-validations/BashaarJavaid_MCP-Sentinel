"""Assess only the 18 immutable completed reports against both retained sources."""
import copy
import gzip
import hashlib
import importlib.util
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
DEST = OUT / 'first-three-assessment'
PREP = OUT.parent / 'v72-prototype-property-correction'
OLD = OUT.parent / 'v70-uncapped-four-results/first-three-assessment'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('bound_runner', PREP / 'evaluate.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
clean = lambda value: runner.supervisor.clean(value, runner.prior.EXCLUDED)

def write(name, value):
    with (DEST / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def deltas(path):
    with gzip.open(path, 'rt') as stream:
        return {(r['input_id'], r['batch']): r for r in map(json.loads, stream)}

inv = read(DEST / 'inventory.json')
validation = read(DEST / 'validation.json')
old_inv = read(OLD / 'inventory.json')
old = read(OLD / 'assessment-with-differences.json')
assert validation['passed'] and validation['completed'] == 18
assert validation['entire_ordered_pairs_equal'] == 9
assert inv['source_files'] == old_inv['source_files']
original_delta = deltas(DEST / 'original-complete-report-differences.jsonl.gz')
preceding_delta = deltas(DEST / 'preceding-complete-report-differences.jsonl.gz')
old_delta = deltas(OLD / 'complete-report-differences.jsonl.gz')
prior_contexts = read(OLD / 'source-context-assessment.json')['contexts']
prior_findings = read(OLD / 'finding-source-assessment.json')['rows']
prior_surfaces = read(OLD / 'surface-source-assessment.json')['rows']
sdk = read(OLD / 'sdk-validation-source.json')
assert sha(Path(sdk['source_path'])) == sdk['source_sha256']
write('sdk-validation-source.json', sdk)

guard_assessment = ('The fixed registered discover_api URL reaches _fetch_and_format_manifest:483, '
    'where validate_url_allowed parses that URL at _ssrf_guard:141, rejects missing hostname at147, '
    'and checks its actual ip_address(host) at160 against is_blocked_ip at164. The predicate explicitly '
    'includes is_link_local at114; SsrfError is caught by a terminal return at discover_api:484-488 '
    'before AsyncClient:490. The ordinary 169.254.169.254 literal therefore cannot reach client.get:132. '
    'The public literal control is admitted under the frozen prerequisites. The same guarded URL is '
    'trimmed by exact rstrip("/") at172 and passed directly at179 or with slash-leading path suffixes '
    'at187; the report retains its initial private-literal IPv4 qualifier and hostname evidence. '
    'This passes the preapproved narrow link-local condition, with DNS, redirect, rebinding and broader '
    'IPv6 safety unestablished. No target or network execution occurred.')
contexts = {}
for key, source in inv['contexts'].items():
    previous = prior_contexts.get(key)
    if previous:
        assert previous['source'] == source
        row = copy.deepcopy(previous)
        row['prior_assessment_sha256'] = sha(OLD / 'source-context-assessment.json')
        if source['case_id'] == 'lightning-discover-linklocal' and source['path'].endswith(('tools/discover_api.py', 'tools/_ssrf_guard.py')):
            row['assessment'] = guard_assessment + ' This context also retains its exact independent unresolved operation; the named guard proof does not certify other routes or remove remaining diagnostics.'
    else:
        assert source['case_id'] == 'lightning-discover-linklocal' and source['path'].endswith('tools/_ssrf_guard.py') and source['line'] == 147
        assert source['statement'].strip() == 'if not host:'
        row = {'source': source, 'assessment': guard_assessment, 'disposition': 'New exact hostname-presence flow context; narrow initial-literal qualification only.'}
    contexts[key] = row

findings, diagnostics, surfaces, rows, difference_rows = [], [], [], [], []
changed_findings = 0
for n, v, previous, old_row in zip(inv['rows'], validation['observations'], old_inv['rows'], old['rows'], strict=True):
    key = n['input_id'], n['batch']
    assert key == (v['input_id'], v['batch']) == (previous['input_id'], previous['batch'])
    assert n['report_sha256'] == v['report_sha256']
    changed_negative = n['case_id'] == 'lightning-discover-linklocal' and n['label'] != 'vulnerable'
    assert bool(preceding_delta[key]['changes']) == changed_negative
    assert n['surfaces'] == previous['surfaces']
    named = []
    for index, (fr, before) in enumerate(zip(n['findings'], previous['findings'], strict=True)):
        basis = next(r for r in prior_findings if r['input_id'] == key[0] and r['batch'] == key[1] and r['context'] == before['context'] and r['finding']['dedup_key'] == before['finding']['dedup_key'])
        row = {**copy.deepcopy(basis), **fr, 'report_sha256': n['report_sha256'], 'prior_assessment_sha256': sha(OLD / 'finding-source-assessment.json')}
        if clean(fr['finding']) != clean(before['finding']):
            assert changed_negative and basis['named_sink'] and index == 26
            f, b = clean(fr['finding']), clean(before['finding'])
            assert f['description'].startswith('The source rejects private literal IPv4 destinations for this caller URL before the request.')
            new_context = next(c for c in fr['flow_contexts'] if c not in before['flow_contexts'])
            assert inv['contexts'][new_context]['line'] == 147
            assert [c for c in fr['flow_contexts'] if c != new_context] == before['flow_contexts']
            f['description'] = b['description']
            f['evidence']['flow_locations'] = b['evidence']['flow_locations']
            assert len(f['provenance']) == len(b['provenance']) == 1
            f['provenance'][0]['evidence']['flow_locations'] = b['provenance'][0]['evidence']['flow_locations']
            assert f == b
            row.update(matches_condition=False, assessment=guard_assessment, disposition='supported qualified named negative')
            changed_findings += 1
        else:
            assert fr['context'] == before['context'] and fr['flow_contexts'] == before['flow_contexts']
        if row['named_sink']:
            named.append(row)
        findings.append(row)
    assert len(named) == 1
    # Indices can shift after removals; compare complete ordered diagnostic objects separately.
    for kind in ('warning', 'unresolved_flow'):
        before = [d for d in previous['diagnostics'] if d['kind'] == kind]
        after = [d for d in n['diagnostics'] if d['kind'] == kind]
        removed = [d for d in before if changed_negative and d['diagnostic']['message'] in {
            f'SENT-015 at src/lightning_enable_mcp/tools/discover_api.py:{line}: unresolved call to url.rstrip; protection is not established' for line in (106, 172)}]
        assert len(removed) == (2 if changed_negative else 0)
        kept = [d for d in before if d not in removed]
        assert [{k: v for k, v in d.items() if k != 'index'} for d in after] == [{k: v for k, v in d.items() if k != 'index'} for d in kept]
    for d in n['diagnostics']:
        assert d['context'] in contexts
        diagnostics.append({'input_id': key[0], 'batch': key[1], 'report_sha256': n['report_sha256'], **d, 'assessment_context': d['context'], 'disposition': 'Retained exact unresolved operation; source role assessed, no inferred safety or suppression.'})
    for s in n['surfaces']:
        basis = next(r for r in prior_surfaces if r['input_id'] == key[0] and r['batch'] == key[1] and r['index'] == s['index'])
        row = {**copy.deepcopy(basis), **s, 'report_sha256': n['report_sha256']}
        if n['case_id'] == 'lightning-discover-linklocal':
            row['assessment'] = 'Exact source-listed registration is recognized; ordered surface bytes are unchanged. The selected discover_api now has supported initial-literal fixed qualification. Other tools and unresolved downstream operations are not certified.'
        surfaces.append(row)
    row = {**copy.deepcopy(old_row), **v, 'coverage': n['coverage'], 'prior_assessment_sha256': sha(OLD / 'assessment-with-differences.json')}
    row.update(matching_keys=[f['finding']['dedup_key'] for f in named if f['matches_condition']], named_negative_false_alert=False if n['label'] != 'vulnerable' else None, supported_qualified_negative=n['label'] != 'vulnerable')
    if changed_negative:
        row['runner_condition_interpretation'] = 'The retained provisional helper recognizes only linklocal-ipv4 wording. The approved V72 rubric expressly permits private-literal IPv4 wording with actual link-local source proof; this source assessment applies that frozen rubric without changing the raw helper result.'
    rows.append(row)
    old_changes = {tuple(d['path']): d for d in old_delta[key]['changes']}
    new_changes = {tuple(d['path']): d for d in original_delta[key]['changes']}
    assert old_changes.keys() == new_changes.keys()
    for path, d in new_changes.items():
        assert d['before'] == old_changes[path]['before']
        if d != old_changes[path]:
            assert changed_negative and path in {('findings',), ('warnings',), ('static_analysis', 'coverage', 'unresolved_flows')}
    difference_rows.append({'input_id': key[0], 'batch': key[1], 'original_changes': len(new_changes), 'preceding_changes': len(preceding_delta[key]['changes']), 'original_source_assessment_sha256': sha(OLD / 'report-difference-assessment.json'), 'assessment': guard_assessment + ' The two removed rstrip diagnostics per list reflect newly supported exact trimming; no other operation is certified by their absence.' if changed_negative else 'Full ordered current report equals the immediately preceding source after only the approved exclusions; every original delta and its source judgment is unchanged.', 'unassessed_changes': 0})

assert len(findings) == 260 and changed_findings == 4
assert len(diagnostics) == 38372 and len(surfaces) == 270 and len(contexts) == 1971
write('source-context-assessment.json', {'contexts': contexts, 'count': len(contexts), 'unassessed': 0})
write('finding-source-assessment.json', {'rows': findings, 'count': len(findings), 'unassessed': 0})
write('diagnostic-source-assessment.json', {'rows': diagnostics, 'count': len(diagnostics), 'by_kind': dict(Counter(d['kind'] for d in diagnostics)), 'unmapped': 0})
write('surface-source-assessment.json', {'rows': surfaces, 'count': len(surfaces), 'unassessed': 0, 'total_possible_surfaces': 'unknown; no coverage percentage inferred'})
write('report-difference-assessment.json', {'rows': difference_rows, 'completed_report_comparisons': 36, 'references': ['2e0efb2', '4145d35'], 'entire_ordered_reconstruction_verified': all(read(DEST / f'{reference}-report-difference-inventory.json')['complete_ordered_reconstruction_passed'] for reference in ('original', 'preceding')), 'unassessed_changes': 0})
cases = []
for case in old['cases']:
    case = copy.deepcopy(case)
    selected = [r for r in rows if r['case_id'] == case['case_id']]
    case['timings_seconds'] = [r['timing']['elapsed_seconds'] for r in selected]
    for name, batch in case['batches'].items():
        batch_rows = [r for r in selected if r['batch'] == name]
        assert len(batch_rows) == 3
        batch.update(vulnerable_hits=sum(bool(r['matching_keys']) for r in batch_rows if r['label']=='vulnerable'), matching_negative_alerts=sum(len(r['matching_keys']) for r in batch_rows if r['label']!='vulnerable'), supported_qualified_negatives=sum(r['supported_qualified_negative'] for r in batch_rows))
        assert batch['vulnerable_hits'] == 1 and batch['matching_negative_alerts'] == 0 and batch['supported_qualified_negatives'] == 2
    case.update(fixed_guard_qualification_established=True, narrow_repository_gate_passed=True)
    cases.append(case)
write('assessment.json', {'recorded_at': datetime.now(timezone.utc).isoformat(), 'scanner': validation['scanner'], 'proposal_sha256': sha(PREP / 'evaluation-proposal.json'), 'approval_sha256': sha(PREP / 'evaluation-authorization.json'), 'rubric_sha256': sha(PREP / 'scoring-rubric.json'), 'completed': 18, 'entire_ordered_pairs_equal': 9, 'cases': cases, 'rows': rows, 'repository_gates_passed': 3, 'repository_gates_assessed': 3, 'repository_gates_required': 4, 'source_assessment_complete_for_completed18': True, 'complete_report_difference_assessment_pending': False, 'finding_count': 260, 'diagnostic_count': 38372, 'surface_count': 270, 'source_context_count': 1971, 'FAF_pending': True, 'budget_closed': False, 'paid_calls': 0, 'technical_acceptance_received': False, 'phase22_complete': False, 'evidence_sha256': {name: sha(DEST / name) for name in ('validation.json', 'inventory.json', 'source-context-assessment.json', 'finding-source-assessment.json', 'diagnostic-source-assessment.json', 'surface-source-assessment.json', 'report-difference-assessment.json')}, 'qualification': 'Partial source assessment of immutable completed outputs from the sole approved experiment. Three narrow exposed gates pass; FAF and all 181 earlier-language observations remain separate outstanding gates. Original failures, broad safety limits and every unmatched diagnostic remain preserved.'})
print('18 reports assessed: three narrow gates pass; 260 findings, 38372 diagnostics, 270 surfaces, 1971 contexts; both full ordered reference differences assessed. FAF remains pending.')
