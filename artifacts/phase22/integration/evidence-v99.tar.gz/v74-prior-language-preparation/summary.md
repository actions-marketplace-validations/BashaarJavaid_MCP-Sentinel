# V74: proposed current-source language compatibility

**Prepared, not approved or executed. Phase 22 remains incomplete.**

Proposal SHA-256: `d40bf9907c7a0d5a4b68b31afb50c0fe8b7c0400c56fab1179835b2f5e8a986e`.
Scanner: `cec0322e904bbf63c33cd95796e7289101a93e5d`, source
`8c8aeb9937930315b0c2ba38685d3e5ac71275cc05946cbae3c790697bdf4099`.
Exact inputs, configurations, order, source prerequisites, references and bounds are in
[evaluation-proposal.json](evaluation-proposal.json); preserved conditions and qualification
requirements are in [scoring-rubric.json](scoring-rubric.json).

The completed [V73 corrected four-repository result](../v73-corrected-four-results/summary.md)
passes all four narrow exposed gates: 24 complete observations and 12 equal entire ordered
pairs. Its budget is closed. All six FAF observations exceed the unchanged normal 1,800-second
policy; no speedup or normal-deadline completion is established. Those inputs are excluded here.

The new proposal uses 98 unchanged, previously exposed input records for 181 static observations:
94 TypeScript and 87 Python, 83 entire ordered pairs and 15 Python development inputs once.
The exact sequence is:

| Group | Input records | Observations |
| --- | ---: | ---: |
| memory-keeper | 3 | 6 |
| SearXNG | 5 | 10 |
| fetch-mcp | 5 | 10 |
| open-webSearch | 5 | 10 |
| Lighthouse | 5 | 10 |
| TypeScript development | 10 | 20 |
| TypeScript historical | 14 | 28 |
| DDG, actual Python member | 5 | 10 |
| Python development | 15 | 15 |
| Python historical | 31 | 62 |

Each repeated group runs its first batch in original manifest order, then its repeat, before
the next group. Python development runs once. Original labels, mutation records, source archives,
prerequisites, DDG language erratum and the two Meta operator nominal-fixed errata remain unchanged.
The latter two are not valid negatives. Whole 25-development and 45+45 Linux results retain their
original source bindings; this sequence cannot be relabeled as those whole Linux batches.

One serial local sequence uses the existing locked environment and maximum four flow workers.
Normal native/whole-input deadline: **1,800 seconds**; cleanup: **15 seconds**; normal Semgrep
rule timeout: **10 seconds**. No uncapped override. Outer cap: **5,555 minutes**, with internal
stop at 5,554 minutes. This is the worst-case 181 × 30 minutes plus the retained 125-minute
reserve, **not a duration estimate**. One input runs at a time and returns when complete.

Stop and close all unused budget on cancellation or identity, infrastructure, execution,
native/whole timeout, schema, cleanup or entire ordered-repeat failure. Named detection/support
failures remain measured outcomes for source assessment after collection. This proposed collection
policy supersedes the nested historical TypeScript first-condition stop only after new approval.
No sorting or added volatile exclusions; compare full reports after only the original 11 exclusions.

Every named condition requires source-supported caller/guard/value/sink handling. Quiet unsupported
negatives fail. DDG must retain actual-send initial CGNAT qualification and memory-keeper actual-read
canonical-root support. All findings, warnings, unresolved flows, surfaces, denominators and complete
reference differences require source assessment; stale assessment keys cannot be silently refreshed.

**Zero paid calls, retries, profiles, extra diagnostics, comparators, new repositories, target
execution, source changes, performance attempts, resource changes or hosted dispatches.** All earlier
budgets remain closed. Numerical approval does not provide Phase 22 technical acceptance.

Preparation validates all 98 immutable records using the current frozen scanner, all 303 engineering
inputs, original reference/configuration bindings, unchanged normal policy and actual imports.
Eight deadline controls and retained synthetic condition/process-cleanup controls pass. The launcher
rejects missing approval before any output, consumed token or corpus input access. Receipts are
`source-binding-validation.json`, `runner-boundaries.json` and adjacent wrapper receipts
`../v74-missing-approval-boundary.json` and `../v74-proposal-source-check.json`.
