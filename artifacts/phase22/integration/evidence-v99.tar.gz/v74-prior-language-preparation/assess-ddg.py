"""Assess DDG's added hostname evidence against the unchanged source and narrow gate."""
import hashlib,importlib.util,json,sys
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parents[3];BASE=PREP.parent;OUT=BASE/'v75-prior-language-results/ddg-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase20_scoring import candidate_identity,score
from scripts.phase22_corpus import frozen,input_files
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();v=read(OUT/'validation.json');inv=read(OUT/'difference-inventory.json');prior=read(BASE/'v38-guard-regression/condition-assessment.json')
assert v['completed']==10 and v['entire_ordered_pairs_equal']==5 and set(inv['changed_paths'])=={'findings'}
rows=[];changed=[];new_contexts=set();old_contexts=set();excluded=set(p['volatile_exclusions'])
for row in v['observations']:
 iid=row['input_id'];item=p['groups']['ddg']['inputs'][iid];label=item['input']['label'];path=BASE/'v75-prior-language-results/raw'/row['directory']/iid/'report.json';report=read(path);ref=read(ROOT/item['reference_report']);clean=r.supervisor.clean
 old=next(x for x in prior['rows'] if x['group']=='ddg' and x['input_id']==iid and x['batch']==row['batch']);assert old['report_sha256']==sha(ROOT/item['reference_report'])
 assert clean({k:x for k,x in report.items() if k!='findings'},excluded)==clean({k:x for k,x in ref.items() if k!='findings'},excluded)
 count=0
 for before,after in zip(clean(ref['findings'],excluded),clean(report['findings'],excluded),strict=True):
  if before==after:continue
  count+=1;assert before['rule_id']==after['rule_id']=='SENT-015'
  assert {k:x for k,x in before.items() if k not in {'evidence','provenance'}}=={k:x for k,x in after.items() if k not in {'evidence','provenance'}}
  assert len(before['provenance'])==len(after['provenance'])==1
  assert {k:x for k,x in before['provenance'][0].items() if k!='evidence'}=={k:x for k,x in after['provenance'][0].items() if k!='evidence'}
  extra=None
  for a,b in [(before['evidence'],after['evidence']),(before['provenance'][0]['evidence'],after['provenance'][0]['evidence'])]:
   assert {k:x for k,x in a.items() if k!='flow_locations'}=={k:x for k,x in b.items() if k!='flow_locations'}
   adds=[x for x in b['flow_locations'] if x not in a['flow_locations']]
   assert len(adds)==2 and [x for x in b['flow_locations'] if x not in adds]==a['flow_locations']
   if extra is not None:assert adds==extra
   extra=adds
  for loc in before['evidence']['flow_locations']:
   old_contexts.add(f"{item['input']['tree_sha256']}:{loc['path']}:{loc['range']['start_line']}")
  old_contexts.add(f"{item['input']['tree_sha256']}:{before['location']['path']}:{before['location']['range']['start_line']}")
  for loc in extra:
   key=f"{item['input']['tree_sha256']}:{loc['path']}:{loc['range']['start_line']}";c=inv['contexts'][key];new_contexts.add(key)
   assert c['statement'].strip() in {'if not parsed.hostname:', 'hostname = parsed.hostname.lower() if parsed.hostname else ""'}
  changed.append({'input_id':iid,'batch':row['batch'],'dedup_key':after['dedup_key'],'added_flow_locations':extra,'original_order_retained':True,'assessment':'Only two hostname-presence evidence locations were added, identically in finding/provenance. The direct URL guard rejects missing hostnames; the search redirect helper lowercases a parsed hostname with an empty fallback, which does not establish destination protection. All prior evidence and exact caller-route CGNAT wording remain; no new guard is credited to the deep-search route.'})
 assert count==1
 named=[f for f in report['findings'] if f['rule_id']=='SENT-015' and f['location']['path']=='src/mcp_ddg_research/fetch.py'];assert len(named)==1
 f=named[0]
 if label=='vulnerable':assert f['location']['range']['start_line']==76 and '100.64' not in f['description'] and len(old['source_assessment']['matches'])==1
 else:
  assert f['location']['range']['start_line']==135 and 'client.send(request, stream=True)' in f['evidence']['snippet']
  route='src/mcp_ddg_research/server.py:245:21 -> src/mcp_ddg_research/fetch.py:261:29 -> src/mcp_ddg_research/fetch.py:135:25'
  assert 'Only the analyzed caller route '+route+' has recognized initial shared-space IPv4 (100.64.0.0/10) rejection' in f['description'] and not old['source_assessment']['matches']
  assert not any('SENT-015 at src/mcp_ddg_research/fetch.py:'+str(n)+':' in w['message'] for w in report['warnings'] for n in [129,135])
 outcome=next(x for x in report['static_analysis']['rule_outcomes'] if x['rule_id']=='SENT-015');assert outcome['status']=='evaluated' and outcome['skip_reason'] is None
 assessment={**old['source_assessment'],'candidate_identity':candidate_identity(report['findings']),'rationale':'Exact V38 named-condition match and route-specific qualification retained after individually reviewing the two added hostname evidence locations. All other ordered report fields and finding fields equal. Current identity explicitly refreshed after observation, no source/label change.'}
 scored=score(label=label,state='completed',findings=report['findings'],assessment=assessment);assert scored['retained_detected'] if label=='vulnerable' else scored['false_alarm'] is False
 rows.append({'group':'ddg','input_id':iid,'batch':row['batch'],'label':label,'report_sha256':sha(path),'source_assessment':assessment,'score':scored,'whole_seconds':row['timing']['elapsed_seconds']})
contexts={}
for key,c in inv['contexts'].items():
 assert key in old_contexts|new_contexts
 meaning='Exact original evidence context retained in the same ordered finding and source tree; reuse original DDG source judgment after proving only the two explicit added evidence locations. Cache, search, domain controls and separate deep-search routes establish no initial CGNAT guard beyond the explicitly named web_fetch route.'
 if key in new_contexts:meaning='Actual hostname presence test added to flow evidence: missing-host rejection in validate_url_shape, or lowercased parsed hostname with empty fallback in search redirect extraction. These additions do not change the exact existing CGNAT qualification or prove DNS/redirect/IPv6 safety.'
 contexts[key]={'path':c['path'],'line':c['line'],'source_sha256':c['source_sha256'],'assessment':meaning,'prior_context_retained':key in old_contexts,'new_hostname_context':key in new_contexts}
refs=['v33-fresh-v6/assessment.json','v35-ddg-regression/finding-source-assessment.json','v35-ddg-regression/diagnostic-source-assessment.json','v35-ddg-regression/other-source-assessment.json','v38-guard-regression/condition-assessment.json','v38-guard-regression/finding-source-assessment.json']
result={'scanner':p['scanner'],'source_assessment_complete':True,'narrow_gates_passed':{'ddg':True},'completed':10,'entire_ordered_pairs_equal':5,'rows':rows,'context_assessments':contexts,'finding_changes':changed,'changed_occurrence_assessments':[{**x,'assessment_contexts':x['contexts'],'assessment':'Before/after occurrence of the same finding; only the individually assessed hostname evidence additions differ.'} for x in inv['changed_occurrences']],'changed_occurrences':len(inv['changed_occurrences']),'source_contexts':len(contexts),'all_other_ordered_fields_equal':True,'diagnostic_changes':0,'surface_changes':0,'ddg_negative_guard_coverage':{'required':6,'qualified':6,'actual_send_supported':6},'unchanged_reference_assessment_bindings':{name:sha(BASE/name) for name in refs},'difference_inventory_sha256':sha(OUT/'difference-inventory.json'),'retained_read_error':{'error':'Exploratory proposal read attempted assessment[matches] on DDG assessment=None; TypeError before mutation.','correction':'Read None explicitly; use bound V38 condition assessment for actual previous adjudication.'},'budget_closed':False,'whole181_sequence_gate_passed':None,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'10 exposed DDG observations only. Actual package is Python despite retained original manifest language erratum. Initial CGNAT route only; original fresh/correction failures, broader candidate and unresolved paths remain. No target/network execution.'}
with (OUT/'assessment.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('DDG10/10 narrow gates and5ordered pairs pass;20before/after finding occurrences and328contexts assessed; all diagnostics/surfaces unchanged.')
