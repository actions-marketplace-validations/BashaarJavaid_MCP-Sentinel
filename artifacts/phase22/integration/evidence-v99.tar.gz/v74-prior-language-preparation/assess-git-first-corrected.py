"""Assess added Git repository-copy qualification without changing historical labels."""
import copy,hashlib,importlib.util,json,sys
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parents[3];BASE=PREP.parent;OUT=BASE/'v75-prior-language-results/git-first-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase20_scoring import candidate_identity,score
from scripts.phase20_corpus import validate,input_files
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();v=read(OUT/'validation.json');inv=read(OUT/'difference-inventory.json');prior=read(BASE/'v38-guard-regression/condition-assessment.json');excluded=set(p['volatile_exclusions']);clean=lambda x:r.supervisor.clean(x,excluded)
assert v['completed']==12 and v['entire_ordered_pairs_equal']==0
assert set(inv['changed_paths'])=={'findings','review_activity/static/candidate_count','review_activity/static/unreviewed_count','static_analysis/rule_outcomes','static_analysis/total_matches','summary/by_severity/Medium','summary/by_status/needs_review','summary/total'}
expected_keys={'git-staging-vulnerable':'af2d829692f8c552c8c7ce00e3723fad9673905ed2b9a14a076ce3c852c1ae53','git-staging-fixed':'d073170065ee663c7a2b185ea3562c58e98b2490943b531a6a1c712cc000fcd6','git-repository-fixed':'56eca861aac72933d03a3b847e6300be855c37d421a4375b4f7ecdf452be6573'}
rows=[];findings=[]
for x in v['observations']:
 iid=x['input_id'];item=p['groups']['py-historical']['inputs'][iid];path=BASE/'v75-prior-language-results/raw'/x['directory']/iid/'report.json';report=read(path);reference=read(ROOT/item['reference_report']);current=clean(report);before=clean(reference);baseid=iid.removesuffix('-mutation');key=expected_keys.get(baseid);added=[f for f in current['findings'] if f['dedup_key']==key]
 old=next(z for z in prior['rows'] if z['group']=='historical' and z['batch']=='first' and z['input_id']==iid);assert old['report_sha256']==sha(ROOT/item['reference_report'])
 if key:
  assert len(added)==1;f=added[0];assert f['rule_id']=='SENT-012' and f['evidence']['snippet'].strip()=='repo = git.Repo(repo_path)' and f['status']=='needs_review' and f['review'] is None
  assert f['description']=='A resolved copy of the originating caller path passed a directory containment check. This operation uses a reconstructed or derived path; equivalence and containment at filesystem use are not established.'
  assert [f for f in current['findings'] if f['dedup_key']!=key]==before['findings']
  expected=copy.deepcopy(before);expected['findings']=current['findings']
  for parts in [('review_activity','static','candidate_count'),('review_activity','static','unreviewed_count'),('static_analysis','total_matches'),('summary','by_severity','Medium'),('summary','by_status','needs_review'),('summary','total')]:
   target=expected
   for k in parts[:-1]:target=target[k]
   target[parts[-1]]+=1
  for outcome in expected['static_analysis']['rule_outcomes']:
   if outcome['rule_id']=='SENT-012':outcome['match_count']+=1
  assert expected==current
  findings.append({'input_id':iid,'batch':x['batch'],'finding':f,'matches_named_condition':False,'assessment':'Actual call_tool constructs the caller Path, invokes validate_repo_path with the captured operator repository, then passes the original Path to git.Repo. The guard resolves a copy, requires component-relative containment and propagates rejection before repository construction. With explicit --repository and the frozen separate outside repository, initial selection is rejected. The report explicitly acknowledges that checked copy while retaining uncertainty about original-path equivalence and later filesystem use; physical/race safety is not proved. This is outside git_add staging-boundary labels and does not allege the fixed initial repository-selection bypass. Keep the broader candidate needs_review; no independent exploit/false-positive verdict.'})
 else:assert current==before
 assessment={**old['source_assessment'],'candidate_identity':candidate_identity(report['findings']),'rationale':'Original exact ordered findings and named matching keys retained. The added repository-copy qualification was individually source-assessed as a broader unmatched candidate: initial configured outside-repository selection rejects before git.Repo, while original-vs-resolved path use and physical/race uncertainty remain. Explicitly refresh current identity after observation; no source, label or previous judgment changed.'}
 s=score(label=item['input']['label'],state='completed',findings=report['findings'],assessment=assessment);assert s['retained_detected'] if item['input']['label']=='vulnerable' else s['false_alarm'] is False
 if iid.startswith('git-repository-fixed'):
  sink=added[0]['location']['range']['start_line'];assert not any(w['message'].startswith('SENT-012 at src/mcp_server_git/server.py:'+str(n)+':') for w in report['warnings'] for n in [227,228,234,384,sink])
 outcome=next(z for z in report['static_analysis']['rule_outcomes'] if z['rule_id']==('SENT-002' if iid.startswith('git-arguments-') else 'SENT-012'));assert outcome['status']=='evaluated' and outcome['skip_reason'] is None
 rows.append({'group':'py-historical','input_id':iid,'batch':x['batch'],'label':item['input']['label'],'report_sha256':sha(path),'source_assessment':assessment,'score':s,'whole_seconds':x['timing']['elapsed_seconds'],'added_unmatched_keys':[key] if key else []})
assert len(findings)==6
contexts={}
for key,c in inv['contexts'].items():
 assert c['path']=='src/mcp_server_git/server.py';statement=c['statement'].strip()
 if statement=='resolved_repo = repo_path.resolve()':meaning='Guard resolves a separate caller-path copy; the incoming Path object is not replaced or mutated by this assignment.'
 elif statement=='resolved_repo.relative_to(resolved_allowed)':meaning='Component-aware relative_to rejects the outside resolved repository. The surrounding except raises ValueError, which is not swallowed before git.Repo; operator --repository must be configured as frozen.'
 elif statement in {'repo_path = Path(arguments["repo_path"])','repo_path = RepositoryPath(arguments["repo_path"])'}:meaning='Actual low-level caller argument is converted to pathlib.Path. The mutation is the verified pathlib.Path import alias RepositoryPath, not an unproved custom constructor.'
 elif statement=='async def call_tool(name: str, arguments: dict) -> list[TextContent]:':meaning='Official low-level server.call_tool callback supplies caller name/arguments; captured repository is operator-selected through CLI main->serve.'
 elif statement=='repo = git.Repo(repo_path)':meaning='Repository constructor receives the original Path only after the terminal resolved-copy guard; initial separate outside selection is rejected, while use of the original path retains physical/identity/race uncertainty. No Git or target execution occurred.'
 elif statement=='case GitTools.STATUS:':meaning='First dispatch case follows the shared guarded repository construction. The case marker is traversal context, not proof that the path candidate affects only status or that Git commands are safe.'
 else:raise AssertionError(statement)
 contexts[key]={'path':c['path'],'line':c['line'],'source_sha256':c['source_sha256'],'assessment':meaning,'runtime_proof':False}
occurrences=[]
for x in inv['changed_occurrences']:
 assert x['kind']=='finding' and x['direction']=='added' and all(k in contexts for k in x['contexts'])
 occurrences.append({**x,'assessment_contexts':x['contexts'],'assessment':'Added source-qualified repository-copy candidate remains unmatched to the frozen initial/staging condition. Preserve exact ordered finding and all associated source contexts; broader filesystem uncertainty remains needs_review.'})
m=validate();anchors=[]
for iid in ['git-staging-vulnerable','git-staging-fixed','git-repository-fixed','git-repository-fixed-mutation']:
 item=next(i for i in m.inputs if i.id==iid);snapshot=next(s for s in m.snapshots if s.revision==item.snapshot);files=input_files(item,snapshot,ROOT);prefix=item.scan_root+'/';path=prefix+'src/mcp_server_git/server.py';data=files[path];ls=data.decode().splitlines()
 if iid.endswith('-mutation'):assert 'from pathlib import Path as RepositoryPath' in data.decode()
 spans=[(1,12)];spans.extend((max(1,n-1),min(len(ls),n+24)) for n,l in enumerate(ls,1) if l.startswith('def validate_repo_path(') or l.startswith('async def serve('));spans.extend((n-1,n+14) for n,l in enumerate(ls,1) if 'async def call_tool(' in l)
 for start,end in spans:
  assert 1<=start<=end<=len(ls);anchors.append({'input_id':iid,'tree_sha256':item.tree_sha256,'path':path,'source_sha256':hashlib.sha256(data).hexdigest(),'start_line':start,'end_line':end,'text':'\n'.join(f'{n}: {ls[n-1]}' for n in range(start,end+1))})
 cli=prefix+'src/mcp_server_git/__init__.py';anchors.append({'input_id':iid,'tree_sha256':item.tree_sha256,'path':cli,'source_sha256':hashlib.sha256(files[cli]).hexdigest(),'full_source':files[cli].decode()})
refs=['v38-guard-regression/condition-assessment.json','v38-guard-regression/finding-source-assessment.json','v22-refresh-v1/condition-assessment.json']
result={'scanner':p['scanner'],'source_assessment_complete':True,'narrow_gates_passed':{'git-staging':True,'git-arguments':True,'git-repository':True},'completed':12,'entire_ordered_pairs_equal':0,'rows':rows,'added_finding_assessments':findings,'context_assessments':contexts,'source_guard_anchors':anchors,'changed_occurrence_assessments':occurrences,'changed_occurrences':6,'source_contexts':36,'diagnostic_changes':0,'surface_changes':0,'all_existing_ordered_findings_equal':True,'count_deltas_exactly_one_per_added_finding':True,'unchanged_reference_assessment_bindings':{name:sha(BASE/name) for name in refs},'difference_inventory_sha256':sha(OUT/'difference-inventory.json'),'retained_read_only_errors':['Exploratory zip assumed equal finding counts, raised ValueError after detecting13vs14; corrected keyed inventory shows one actual addition, no raw change.','Exploratory full-source lookup omitted historical scan_root src/git; corrected source key includes the unchanged scan_root.'],'helper_failure_retention':{'initial_helper':'assess-git-first.py','wrapper':'v75-git-first-source-assessment','failure':'KeyError: matches; helper used wrong rule-outcome counter name.','correction':'Use actual schema match_count, as existing TypeScript assessment does; full before/after report equality required with exactly the one added finding and corresponding counts. Raw reports and scanner unchanged.'},'budget_closed':False,'whole181_sequence_gate_passed':None,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Only12historicalGitfirst inputs; status safe and all repeats remain separate. Actual source qualifiers support the frozen narrow initial conditions, not complete physical/runtime safety or independent candidate confirmation.'}
with (OUT/'assessment.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('First12Git narrow conditions pass;6new qualified unmatched candidates/36contexts assessed; all old ordered findings and diagnostics unchanged.')
