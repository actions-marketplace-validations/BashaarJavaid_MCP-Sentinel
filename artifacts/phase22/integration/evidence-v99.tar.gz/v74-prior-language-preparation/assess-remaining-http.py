"""Assess completed openwebsearch/Lighthouse outputs without executing target source."""
import hashlib,importlib.util,json,sys
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parents[3];BASE=PREP.parent;OUT=BASE/'v75-prior-language-results/remaining-http-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase20_scoring import candidate_identity,score
from scripts.phase22_corpus import frozen,input_files
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();v=read(OUT/'validation.json');inventory=read(OUT/'difference-inventory.json')
assert v['completed']==20 and v['entire_ordered_pairs_equal']==10
assert inventory['comparisons']==20 and set(inventory['changed_paths'])=={'warnings','static_analysis/coverage/unresolved_flows'}
contexts={}
for key,c in inventory['contexts'].items():
 path=c['path']
 if path=='src/config.ts':
  assert c['line'] in {None,114}
  meaning='Configuration selects the first allowed search engine when the original default is outside the operator list, then logs selected engine/search/browser/CORS settings. Indexed-array and field uncertainty remains visible; it does not enforce the caller mapped-loopback URL condition.'
 elif path=='src/engines/web/fetchWebContent.ts':
  assert c['line'] in {None,113,114,253,254,439,440}
  meaning='browserHtmlFetcher and readabilityParser aliases are traversed more deeply. The reader dynamically imports Mozilla Readability, constructs its parser and calls parse; unresolved external/dynamic call and error bindings remain. Removed alias-call diagnostics occur in browser fallback and optional readability extraction after initial request handling. Their disappearance proves neither browser/redirect safety nor full parser coverage. The named condition covers only the earlier initial literal request.'
 elif path=='src/test/test-web-content.ts':
  assert c['line'] is None
  meaning='The upstream web-content test uses a Map to coordinate mocked/test state. Added binding uncertainty is preserved; no test, browser or network request ran and no production guard follows from the test.'
 elif path=='src/index.ts' and c['line'] in {345,444}:
  assert c['statement'].strip()=='const resultData = JSON.parse(result.content[0].text);'
  meaning='The Lighthouse performance wrapper reads the first result-content element and parses its text after handleRunAudit returns. Conservative indexed-array uncertainty concerns result extraction, after the separately guarded request; it is no new initial link-local bypass or general result-safety claim.'
 elif path=='src/index.ts' and c['line']==61:
  assert "prefix: '172.'" in c['statement'] and "ip.split('.')[1]" in c['statement']
  meaning='This range mask parses the second octet only for a 172.* address, to check16..31. Added indexed-array uncertainty remains for that broader RFC1918 path. The frozen169.254.169.254 witness does not enter the172-prefix mask: isBlockedIP separately matches169.254. with a null mask and returns true. The8.8.8.8 safe literal matches no blocked prefix. Retain only the existing initial link-local qualifier; no general private-range, DNS, redirect or IPv6 assurance is inferred.'
 else:raise AssertionError((path,c['line']))
 contexts[key]={'path':path,'source_sha256':c['source_sha256'],'line':c['line'],'assessment':meaning,'runtime_proof':False}
anchors=[]
for group,iid,spans in [
 ('openwebsearch','openwebsearch-mapped-loopback-fixed',[('src/utils/urlSafety.ts',1,68),('src/core/validation/targetValidation.ts',43,45),('src/core/fetch/fetchServices.ts',39,59),('src/engines/web/fetchWebContent.ts',312,351)]),
 ('lighthouse','lighthouse-linklocal-fixed',[('src/index.ts',58,79),('src/index.ts',87,143),('src/index.ts',294,319),('src/index.ts',343,344),('src/index.ts',435,444)])]:
 g=p['groups'][group];m=frozen(approval_path=ROOT/g['source_freeze_approval']);item=next(i for i in m.inputs if i.id==iid);snapshot=next(s for s in m.snapshots if s.revision==item.snapshot);files=input_files(item,snapshot,ROOT)
 for path,start,end in spans:
  data=files[path];lines=data.decode().splitlines();assert 1<=start<=end<=len(lines)
  anchors.append({'group':group,'input_id':iid,'tree_sha256':item.tree_sha256,'path':path,'source_sha256':hashlib.sha256(data).hexdigest(),'start_line':start,'end_line':end,'text':'\n'.join(f'{n}: {lines[n-1]}' for n in range(start,end+1))})
occurrences=[]
for row in inventory['changed_occurrences']:
 assert row['kind'] in {'warning','unresolved_flow'} and all(key in contexts for key in row['contexts'])
 occurrences.append({**row,'assessment_contexts':row['contexts'],'assessment':'Preserve the exact diagnostic, added/removed direction and ordered index; apply the separately bound source-specific context judgment. No missing warning becomes independent proof of safety.'})
rows=[]
for row in v['observations']:
 group=row['group'];item=p['groups'][group]['inputs'][row['input_id']];label=item['input']['label'];path=BASE/'v75-prior-language-results/raw'/row['directory']/row['input_id']/'report.json';report=read(path);reference=read(ROOT/item['reference_report'])
 assert r.supervisor.clean(report['findings'],set(p['volatile_exclusions']))==r.supervisor.clean(reference['findings'],set(p['volatile_exclusions']))
 assert r.supervisor.clean(report['static_analysis']['coverage']['surfaces'],set(p['volatile_exclusions']))==r.supervisor.clean(reference['static_analysis']['coverage']['surfaces'],set(p['volatile_exclusions']))
 if group=='lighthouse':
  witness=p['witnesses'][group][row['input_id']];named=[f for f in report['findings'] if f['rule_id']=='SENT-015' and f['location']['path']==witness['path'] and f['location']['range']['start_line']==witness['sink_line']]
  assert len(named)==1 and 'lighthouse' in named[0]['evidence']['snippet']
  qualified=named[0]['description'].startswith('The source rejects literal link-local IPv4 destinations for this caller URL before the request.')
  assert qualified==(label!='vulnerable');matches=[f['dedup_key'] for f in named] if label=='vulnerable' else []
  meaning='Actual run_audit caller/validateUrl/throw-before-Chrome/Lighthouse sink and original literal witnesses retain the source-supported narrow initial link-local qualification. Newly visible172-range array uncertainty remains explicitly outside that precise qualifier. All unrelated findings and surfaces retain original judgments.'
 else:
  matches=item['assessment']['matches'];named=[f for f in report['findings'] if f['dedup_key'] in matches]
  if label=='vulnerable':assert named and all(f['rule_id']=='SENT-015' and f['location']['path']=='src/engines/web/fetchWebContent.ts' for f in named)
  else:assert not matches and not any(f['rule_id']=='SENT-015' and f['location']['path']=='src/engines/web/fetchWebContent.ts' for f in report['findings'])
  meaning='Original default official registration/service/caller binding is unchanged. The fixed service rejects !validatePublicWebUrl(url); the shared actual hostname guard strips IPv6 brackets and rejects non-unicast literal ranges. fetchWebContent also awaits assertPublicHttpUrlResolved before initial HEAD/GET; literal IPs return before DNS after the address check. Actual current evaluated rule and unchanged supported findings/flow/surfaces, plus complete review of changed downstream diagnostics, support the frozen mapped-loopback rejection and public-literal control. Quiet output alone is not used as support. Browser/cookie fallback, DNS and redirects remain outside this condition.'
 outcome=next(x for x in report['static_analysis']['rule_outcomes'] if x['rule_id']=='SENT-015');assert outcome['status']=='evaluated' and outcome['skip_reason'] is None
 assessment={'candidate_identity':candidate_identity(report['findings']),'matches':matches,'rationale':meaning}
 scored=score(label=label,state='completed',findings=report['findings'],assessment=assessment);assert scored['retained_detected'] if label=='vulnerable' else scored['false_alarm'] is False
 rows.append({'group':group,'input_id':row['input_id'],'batch':row['batch'],'label':label,'report_sha256':sha(path),'reference_report_sha256':sha(ROOT/item['reference_report']),'source_assessment':assessment,'score':scored,'whole_seconds':row['timing']['elapsed_seconds']})
refs=['v13-exposed-assessment/packet.json','v31-compatibility/source-assessment.json','v30-lighthouse-regression/assessment.json','v30-lighthouse-regression/source-assessment.json','v42-path-guard-regression/condition-assessment.json','v42-path-guard-regression/coverage-source-assessment.json']
result={'scanner':p['scanner'],'source_assessment_complete':True,'narrow_gates_passed':{'openwebsearch':True,'lighthouse':True},'completed':20,'entire_ordered_pairs_equal':10,'rows':rows,'context_assessments':contexts,'source_guard_anchors':anchors,'changed_occurrence_assessments':occurrences,'changed_occurrences':len(occurrences),'source_contexts':len(contexts),'finding_changes':0,'surface_changes':0,'all_other_ordered_fields_equal':True,'unchanged_reference_assessment_bindings':{name:sha(BASE/name) for name in refs},'difference_inventory_sha256':sha(OUT/'difference-inventory.json'),'budget_closed':False,'whole181_sequence_gate_passed':None,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Completed20 current-source exposed openwebsearch/Lighthouse observations only. Original Lighthouse first-frozen and correction failures remain failed. Narrow literal qualifications, default source prerequisites and unrelated uncertainties remain; no target, browser, DNS or test execution occurred.'}
with (OUT/'assessment.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Openwebsearch/Lighthouse narrow gates pass20/20;10whole pairs;562changed diagnostic occurrences and34contexts assessed. Whole181sequence remains separate.')
