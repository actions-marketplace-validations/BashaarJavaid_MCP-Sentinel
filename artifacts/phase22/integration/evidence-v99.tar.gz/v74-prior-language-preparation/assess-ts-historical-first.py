"""Source-assess the completed historical first batch; no target execution."""
import hashlib,importlib.util,json,sys
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parents[3];BASE=PREP.parent;OUT=BASE/'v75-prior-language-results/ts-historical-first-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase20_scoring import candidate_identity,score
from scripts.phase20_corpus import validate,input_files
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();v=read(OUT/'validation.json');inv=read(OUT/'difference-inventory.json')
assert v['completed']==14 and v['entire_ordered_pairs_equal']==0
assert inv['comparisons']==14 and set(inv['changed_paths'])=={'warnings','static_analysis/coverage/unresolved_flows'}
contexts={}
for key,c in inv['contexts'].items():
 path=c['path'];line=c['line']
 if path=='index.ts':
  assert line in {386,392,298,302,413,419,313,317}
  meaning='Filesystem text chunking and edit indentation read array elements. Added indexed-array uncertainty concerns file contents after path handling; the named sibling-prefix boundary and its actual validatePath/returned-path/sink chain are unchanged. Unrelated temporary-file/path findings remain.'
 elif path in {'src/android.ts','src/ios.ts','src/mobile-device.ts'}:
  meaning='AndroidRobot, IosRobot and MobileDevice bind the private constructor deviceId; removed class barriers permit deeper device operations. Android tab-separated device listing still has indexed-array uncertainty, and its rest args binding remains unknown. No device, ADB, mobilecli, socket or installed toolchain was exercised; these data/execution uncertainties do not change the destination output-path guard.'
 elif path=='src/server.ts':
  meaning='Mobile dispatch now traverses listApps, screen/elements/orientation/button operations and screenshot/image formatting more deeply. The save-screenshot data acquisition is in the same tool as the named write, but does not replace or modify saveTo: fixed validateOutputPath(saveTo) precedes getScreenshot and writeFileSync(saveTo,screenshot). Removed data-call warnings establish neither runtime device success nor image correctness. Actual output findings retain the lexical boundary and physical-containment gap under the original Linux/non-symlink prerequisites.'
 elif path=='src/image-utils.ts':
  meaning='Image constructor private buffer is now supported; its factories expose ImageTransformer, whose initialized instance fields plus parameter property remain unsupported. Preserve that deeper barrier, external image processing and format uncertainty. No full image pipeline or output physical containment is established.'
 elif path=='src/robot.ts':
  assert line==6 and 'interface ScreenSize extends Dimensions' in c['statement']
  meaning='The new generic unsupported-class diagnostic points to a TypeScript ScreenSize interface extending Dimensions, not an executable class or output guard. Preserve the raw diagnostic and its precision limitation; it proves no runtime behavior.'
 elif path=='src/webdriver-agent.ts':
  assert line==25
  meaning='Deeper traversal exposes WebDriverAgent with private readonly host/port constructor properties. The current generic unsupported-class diagnostic remains; URL interpolation, external fetch/session/image operations and device reachability are not established. It is not evidence of an output-path bypass or complete device support.'
 elif path=='src/tools/kubectl-context.ts':
  meaning='Context output parsing indexes split header/column arrays and cluster/name parts. Added conservative array uncertainty remains in the context tool; it is not the named kubectl_get shell construction. All existing context execution findings remain unchanged.'
 elif path=='src/tools/kubectl-logs.ts':
  meaning='Job/pod list empty checks and first content-result JSON parsing retain indexed-array uncertainty. These are log-tool data processing, not the kubectl_get caller-to-command path; existing log-tool execution findings remain.'
 elif path=='src/tools/helm-operations.ts':
  meaning='Helm repo-name extraction indexes params.chart.split at element0. This is a separate Helm tool; array uncertainty and all Helm file/execution candidates remain outside the named kubectl_get shell condition.'
 elif path=='src/index.ts':
  assert line in {None,484}
  meaning='Kubernetes server transport connection and operator environment/unsafe-SSE/non-destructive switches retain uncertainty. This does not alter the unchanged official kubectl_get dispatch and shell-versus-execFile argument handling. No transport or cluster was executed.'
 elif path in {'tests/kubectl-rollout.test.ts','tests/kubectl-unified.test.ts','tests/unit.test.ts'}:
  assert line is None
  meaning='Unresolved Error binding in upstream test source remains visible; no test execution or production guard is inferred.'
 elif path=='src/utils/kubernetes-manager.ts':
  assert line is None
  meaning='Dynamic Kubernetes tool-description binding remains unresolved. It is not named kubectl_get command construction or a new metadata safety proof.'
 else:raise AssertionError((path,line))
 contexts[key]={'path':path,'line':line,'source_sha256':c['source_sha256'],'assessment':meaning,'runtime_proof':False}
m=validate();anchors=[]
for iid,spans in [
 ('filesystem-prefix-fixed',[('src/filesystem/path-validation.ts',11,77),('src/filesystem/index.ts',71,113),('src/filesystem/index.ts',592,625)]),
 ('mobile-output-fixed',[('src/utils.ts',18,88),('src/server.ts',582,600),('src/server.ts',701,725),('src/android.ts',75,84),('src/ios.ts',43,46),('src/mobile-device.ts',62,73),('src/image-utils.ts',9,25),('src/image-utils.ts',117,129),('src/webdriver-agent.ts',25,38)]),
 ('kubernetes-shell-fixed',[('src/tools/kubectl-get.ts',58,87),('src/tools/kubectl-get.ts',139,155)])]:
 item=next(i for i in m.inputs if i.id==iid);snapshot=next(s for s in m.snapshots if s.revision==item.snapshot);files=input_files(item,snapshot,ROOT)
 for path,start,end in spans:
  data=files[path];ls=data.decode().splitlines();assert 1<=start<=end<=len(ls)
  anchors.append({'input_id':iid,'tree_sha256':item.tree_sha256,'path':path,'source_sha256':hashlib.sha256(data).hexdigest(),'start_line':start,'end_line':end,'text':'\n'.join(f'{n}: {ls[n-1]}' for n in range(start,end+1))})
occurrences=[]
for row in inv['changed_occurrences']:
 assert row['kind'] in {'warning','unresolved_flow'} and all(k in contexts for k in row['contexts'])
 occurrences.append({**row,'assessment_contexts':row['contexts'],'assessment':'Retain actual direction, rule, ordered occurrence and exact source judgment; disappearance of a warning alone establishes no protection.'})
rows=[]
for row in v['observations']:
 item=p['groups']['ts-historical']['inputs'][row['input_id']];label=item['input']['label'];path=BASE/'v75-prior-language-results/raw'/row['directory']/row['input_id']/'report.json';report=read(path);ref=read(ROOT/item['reference_report'])
 assert r.supervisor.clean(report['findings'],set(p['volatile_exclusions']))==r.supervisor.clean(ref['findings'],set(p['volatile_exclusions']))
 assert r.supervisor.clean(report['static_analysis']['coverage']['surfaces'],set(p['volatile_exclusions']))==r.supervisor.clean(ref['static_analysis']['coverage']['surfaces'],set(p['volatile_exclusions']))
 family=item['input']['family'];rule='SENT-002' if family=='kubernetes-shell' else 'SENT-012';outcome=next(x for x in report['static_analysis']['rule_outcomes'] if x['rule_id']==rule);assert outcome['status']=='evaluated' and outcome['skip_reason'] is None
 meaning={'filesystem-prefix':'Exact source-assessed normalized string-prefix vulnerable candidates remain. Fixed path helper requires equality or normalizedDir+separator, before read paths returned by validatePath; ordinary sibling-prefix condition is supported. Other write/temp candidates and physical/race limitations remain.', 'mobile-output':'Actual screenshot write and source-selected mobilecli recording preserve vulnerable detection versus fixed lexical-directory qualification. Fixed output guard rejects outside cwd/tmp roots before the sink under original Linux, valid extension, existing ordinary parent and functioning-toolchain prerequisites. No physical or executable-override assurance.', 'kubernetes-shell':'Named vulnerable kubectl_get string command reaches shell execution; fixed uses literal kubectl plus argument array and execFileSync without shell option. Shell metacharacter condition is supported; other Helm paths, cluster permissions, CLI option behavior and actual runtime are outside this label.'}[family]
 assessment={**item['assessment'],'candidate_identity':candidate_identity(report['findings']),'rationale':meaning};scored=score(label=label,state='completed',findings=report['findings'],assessment=assessment)
 assert scored['retained_detected'] if label=='vulnerable' else scored['false_alarm'] is False
 rows.append({'group':row['group'],'input_id':row['input_id'],'batch':row['batch'],'label':label,'report_sha256':sha(path),'source_assessment':assessment,'score':scored,'whole_seconds':row['timing']['elapsed_seconds']})
refs=['v22-refresh-v1/condition-assessment.json','v31-compatibility/source-assessment.json','v42-path-guard-regression/condition-assessment.json','v42-path-guard-regression/coverage-source-assessment.json']
result={'scanner':p['scanner'],'source_assessment_complete':True,'narrow_gates_passed':{'filesystem-prefix':True,'mobile-output':True,'kubernetes-shell':True},'completed':14,'entire_ordered_pairs_equal':0,'rows':rows,'context_assessments':contexts,'source_guard_anchors':anchors,'changed_occurrence_assessments':occurrences,'changed_occurrences':len(occurrences),'source_contexts':len(contexts),'finding_changes':0,'surface_changes':0,'all_other_ordered_fields_equal':True,'unchanged_reference_assessment_bindings':{name:sha(BASE/name) for name in refs},'difference_inventory_sha256':sha(OUT/'difference-inventory.json'),'budget_closed':False,'whole181_sequence_gate_passed':None,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'14 historical first-batch observations only; repeat equality must be checked separately before reusing these judgments. Original mutation overlays, conditions, unrelated candidates and historical failures remain. Same-agent source review, no target execution.'}
with (OUT/'assessment.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Historical first14 narrow conditions pass;2295changed diagnostic occurrences and184contexts source-assessed. Repeats and whole181 gate remain separate.')
