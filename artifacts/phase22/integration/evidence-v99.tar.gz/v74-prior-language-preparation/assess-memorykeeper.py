"""Assess all six completed memorykeeper reports at actual source; no scanner execution."""
import hashlib,importlib.util,json,re,sys
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parents[3];BASE=PREP.parent;OUT=BASE/'v75-prior-language-results/memorykeeper-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase22_corpus import frozen,input_files
from scripts.phase20_scoring import candidate_identity,score
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();v=read(OUT/'validation.json');inventory=read(OUT/'difference-inventory.json');old_proof=read(BASE/'v42-path-guard-regression/guard-source-proof.json')
assert v['completed']==6 and v['entire_ordered_pairs_equal']==3
assert inventory['comparisons']==6 and set(inventory['changed_paths'])=={'warnings','static_analysis/coverage/unresolved_flows'}
g=p['groups']['memorykeeper'];manifest=frozen(approval_path=ROOT/g['source_freeze_approval']);sources={}
for item in manifest.inputs:
 if item.id in g['input_ids']:
  snapshot=next(s for s in manifest.snapshots if s.revision==item.snapshot);sources[item.id]=input_files(item,snapshot,ROOT)
proof_rows=[]
for row in old_proof['inputs']:
 expected=g['inputs'][row['input_id']]['input'];data=sources[row['input_id']]['src/index.ts'];lines=data.decode().splitlines()
 assert row['snapshot']==expected['snapshot'] and row['tree_sha256']==expected['tree_sha256']
 assert hashlib.sha256(data).hexdigest()==row['source_sha256']
 for span in row['source_spans']:
  assert span['text']=='\n'.join(f'{n}: {lines[n-1]}' for n in range(span['start_line'],span['end_line']+1))
 proof_rows.append(row)
# Additional source anchors for the exact class-boundary diagnostic changes.
anchors=[];files=sources['memory-import-path-vulnerable']
for path,start,end in [('src/repositories/WatcherRepository.ts',42,58),('src/utils/knowledge-graph.ts',50,66),('src/repositories/BaseRepository.ts',4,11),('src/repositories/RepositoryManager.ts',8,26),('src/utils/agents.ts',30,57),('src/utils/agents.ts',573,580)]:
 data=files[path];lines=data.decode().splitlines();anchors.append({'path':path,'source_sha256':hashlib.sha256(data).hexdigest(),'start_line':start,'end_line':end,'text':'\n'.join(f'{n}: {lines[n-1]}' for n in range(start,end+1))})
purposes={
 'src/utils/tool-profiles.ts':'The module declares known tool names and operator-selected full/standard/custom profiles, including context_import. Removal of its generic dynamic-description warning does not resolve the retained unnamed dispatch or prove complete metadata coverage.',
 'src/utils/migrationHealthCheck.ts':'Migration health checking parses SQL/table and column definitions, skips irrelevant/missing tables, reports schema issues and formats suggested fixes. Its loops, maps, operator test-mode/environment reads and logging remain conservatively unresolved; none is the context_import path boundary.',
 'src/utils/database.ts':'DatabaseManager configures SQLite, checks size/health and reports database errors. Its unknown logging/error bindings do not establish a path guard or target startup success.',
 'src/utils/agents.ts':'Agent, AnalyzerAgent and SynthesizerAgent retain abstract/inheritance uncertainty. AgentCoordinator selects capable agents, gathers Promise results, stores them by task ID and chains outputs. These agent/analysis operations do not guard the selected import read; no target agent ran.',
 'src/utils/feature-flags.ts':'Feature flags read stored JSON and time/environment/user/percentage criteria; the counted hash loop computes deterministic rollout selection. Unknown fields, dates and arithmetic do not establish filesystem containment.',
 'src/utils/vector-store.ts':'VectorStore normalizes text, builds n-gram/hash embeddings, updates numeric arrays, serializes SQLite rows/buffers and computes similarity/search results. Added conservative string/loop/index/call diagnostics concern these operations, distinct from the selected context_import read.',
 'src/utils/knowledge-graph.ts':'KnowledgeGraphManager stores a constructor parameter property at line51. Its former generic class barrier disappears; source traversal exposes regex extraction, deduplication sets, SQLite entity/relation operations, bounded graph queue/depth traversal and JSON formatting. Added uncertainty is retained and removal does not prove complete graph safety or target runtime success.',
 'src/repositories/WatcherRepository.ts':'WatcherRepository stores the actual DatabaseManager argument in its private parameter property at line43. The former unsupported-class warning disappears on supported constructor modeling. Watcher expiry/SQL/change handling is separate from the selected context_import read; complete watcher behavior is not established.',
 'src/repositories/BaseRepository.ts':'The abstract base holds database references and shared repository utilities. Conservative abstract/class uncertainty remains; it supplies no named import containment proof.',
 'src/repositories/SessionRepository.ts':'SessionRepository extends the abstract database repository and handles session records. Its retained conservative class/inheritance warning is outside the selected import byte-read boundary.',
 'src/repositories/ContextRepository.ts':'ContextRepository extends the abstract database repository and stores context records. Retained class/inheritance uncertainty does not make the named fixed import read unsupported or establish general database correctness.',
 'src/repositories/FileRepository.ts':'FileRepository extends the abstract database repository for stored file metadata. Conservative class/inheritance uncertainty remains; no broad filesystem safety is inferred.',
 'src/repositories/CheckpointRepository.ts':'CheckpointRepository extends the abstract database repository for checkpoints. Its class/inheritance uncertainty remains separate from import byte-read confinement.',
 'src/repositories/RepositoryManager.ts':'RepositoryManager constructs session/context/file/checkpoint/watcher repositories and assigns public readonly fields. Conservative member/class uncertainty remains visible; its database orchestration is not the selected path guard.',
}
context_assessment={}
for key,c in inventory['contexts'].items():
 path=c['path']
 if path=='src/index.ts':
  assert c['line'] not in {1724,1849}
  if 'gitSubdirs[0]' in c['statement']:
   meaning='The status message suggests a context_session_start command using a discovered Git subdirectory. The retained indexed-array uncertainty concerns instructional text, not the context_import sink.'
  elif 'analysis.entities[0]' in c['statement']:
   meaning='The context_find_related path picks the first extracted entity for graph lookup. Indexed-array uncertainty remains; this graph selection is outside the import byte-read condition.'
  else:
   meaning='The bound statement handles vector storage/search, graph analysis/relations/visualization, result formatting or agent delegation in other dispatch paths. Removal of its unresolved-call warning is consistent with deeper source traversal; it alone establishes neither complete callee behavior nor path protection. The actual context_import read and guard are separately proved.'
 elif path.startswith('src/__tests__/'):
  assert c['line'] is None
  meaning='This upstream test source uses test/framework or standard-library bindings (for example Date, Error, Set, Map, Promise, RegExp or jest). Their newly reported binding uncertainty stays visible. Tests were only read; their assertions or passing behavior supply no production guard, startup or runtime evidence.'
 else:
  assert path in purposes,path;meaning=purposes[path]
 context_assessment[key]={'source_sha256':c['source_sha256'],'path':path,'line':c['line'],'assessment':meaning,'runtime_proof':False}
occurrences=[]
for row in inventory['changed_occurrences']:
 assert row['kind'] in {'warning','unresolved_flow'}
 for key in row['contexts']:assert key in context_assessment
 occurrences.append({**row,'assessment_contexts':row['contexts'],'assessment':'Source-specific judgments are bound above to every context and original diagnostic/index. Preserve the exact uncertainty and its direction. Neither warning removal nor increased traversal is a new named detection or safety claim.'})
rows=[]
for item in v['observations']:
 current_path=BASE/'v75-prior-language-results/raw'/item['directory']/item['input_id']/'report.json';report=read(current_path);expected=g['inputs'][item['input_id']];reference=read(ROOT/expected['reference_report']);label=expected['input']['label']
 assert r.supervisor.clean(report['findings'],set(p['volatile_exclusions']))==r.supervisor.clean(reference['findings'],set(p['volatile_exclusions']))
 assert r.supervisor.clean(report['static_analysis']['coverage']['surfaces'],set(p['volatile_exclusions']))==r.supervisor.clean(reference['static_analysis']['coverage']['surfaces'],set(p['volatile_exclusions']))
 line=1724 if label=='vulnerable' else 1849
 matches=[f for f in report['findings'] if f['rule_id']=='SENT-012' and f['location']['path']=='src/index.ts' and f['location']['range']['start_line']==line]
 if label=='vulnerable':assert len(matches)==1 and 'readFileSync' in matches[0]['evidence']['snippet']
 else:
  assert not matches
  diagnostics=report['warnings']+report['static_analysis']['coverage']['unresolved_flows']
  assert not any('SENT-012 at src/index.ts:1849:' in x['message'] or ('SENT-012' in x['message'] and 'resolveConfinedImportPath' in x['message']) for x in diagnostics)
 outcome=next(x for x in report['static_analysis']['rule_outcomes'] if x['rule_id']=='SENT-012');assert outcome['status']=='evaluated' and outcome['skip_reason'] is None
 coverage=report['static_analysis']['coverage'];assert len(coverage['surfaces'])==1 and coverage['surfaces'][0]['status']=='unresolved' and coverage['surfaces'][0]['name'] is None
 assessment={'candidate_identity':candidate_identity(report['findings']),'matches':[f['dedup_key'] for f in matches],'rationale':'Same immutable context_import dispatch and ordinary root/file prerequisites. Vulnerable reads caller filePath. Fixed/safe canonicalize operator exports root and caller path, reject outside separator boundary through terminal catch, and pass returned safePath to actual read1849. Current evaluated rule, unchanged findings/surfaces and absence of named unresolved barriers support this narrow source gate; unrelated and unnamed-dispatch uncertainty remains. No runtime proof.'}
 scored=score(label=label,state='completed',findings=report['findings'],assessment=assessment)
 assert scored['retained_detected'] if label=='vulnerable' else scored['false_alarm'] is False
 rows.append({'input_id':item['input_id'],'batch':item['batch'],'label':label,'report_sha256':sha(current_path),'reference_report_sha256':sha(ROOT/expected['reference_report']),'source_assessment':assessment,'score':scored,'whole_seconds':item['timing']['elapsed_seconds']})
refs=['v42-path-guard-regression/condition-assessment.json','v42-path-guard-regression/coverage-source-assessment.json','v42-path-guard-regression/guard-source-proof.json','v40-fresh-v7/finding-source-assessment.json','v40-fresh-v7/diagnostic-source-assessment.json','v40-fresh-v7/source-context-assessment.json','v40-fresh-v7/surface-source-assessment.json','v72-prototype-property-correction/local-checks.json']
result={'scanner':p['scanner'],'source_assessment_complete':True,'memorykeeper_narrow_gate_passed':True,'completed':6,'entire_ordered_pairs_equal':3,'rows':rows,'source_proof':{'original_target_spans_verified':proof_rows,'current_class_anchors':anchors,'old_scanner_ast_reused_as_current':False,'current_engineering':p['scanner'],'qualification':'Target-source spans remain identical; old scanner proof is historical. Current source engineering plus actual evaluated rule/report/diagnostic evidence is bound separately.'},'context_assessments':context_assessment,'changed_occurrence_assessments':occurrences,'changed_occurrences':len(occurrences),'source_contexts':len(context_assessment),'finding_changes':0,'surface_changes':0,'all_other_ordered_fields_equal':True,'unchanged_reference_assessment_bindings':{name:sha(BASE/name) for name in refs},'difference_inventory_sha256':sha(OUT/'difference-inventory.json'),'budget_closed':False,'whole181_sequence_gate_passed':None,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Six completed current-source exposed memorykeeper observations only. Original fresh negatives at8c62567 remain failed; unnamed dispatch remains unresolved. Other175 observations and the complete compatibility gate are separate.'}
with (OUT/'assessment.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Memorykeeper narrow source gate passes6/6;3whole pairs;6376changed diagnostic occurrences and213contexts assessed. Whole181sequence remains separate.')
