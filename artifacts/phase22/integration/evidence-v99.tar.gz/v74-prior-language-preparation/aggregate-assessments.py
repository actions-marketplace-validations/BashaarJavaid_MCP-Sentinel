"""Assemble current source judgments only after full approved execution and comparison."""
import collections,hashlib,importlib.util,json,sys
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parents[3];BASE=PREP.parent;OUT=BASE/'v75-prior-language-results';DEST=OUT/'final-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();v=read(DEST/'validation.json');inv=read(DEST/'difference-inventory.json')
assert v['completed']==181 and v['entire_ordered_pairs_equal']==83 and v['execution_gate_passed'] and v['budget_closed']
folders=['memorykeeper-assessment','initial-http-assessment','remaining-http-assessment','ts-development-assessment','ts-historical-first-assessment','ddg-assessment','python-development-assessment','python-historical-first-assessment']
packets={name:read(OUT/name/'assessment.json') for name in folders};source_rows={};judgments=collections.defaultdict(list);occurrence_reviews={};bindings={}
for name,a in packets.items():
 assert a['source_assessment_complete']
 if name=='memorykeeper-assessment':assert a['memorykeeper_narrow_gate_passed']
 elif name=='ts-development-assessment':assert a['typescript_development_narrow_gate_passed']
 else:assert a['narrow_gates_passed'] and all(a['narrow_gates_passed'].values())
 bindings[name]=sha(OUT/name/'assessment.json')
 for row in a['rows']:
  if 'group' not in row:row={**row,'group':{'memorykeeper-assessment':'memorykeeper','ts-development-assessment':'ts-development'}[name]}
  key=(row['group'],row['input_id'],row['batch']);assert key not in source_rows;source_rows[key]=(name,row)
 for key,review in a['context_assessments'].items():
  assert key in inv['contexts'],(name,key)
  c=inv['contexts'][key];assert all(review[k]==c[k] for k in ['path','line','source_sha256'])
  judgments[key].append({'source_assessment':name,**review})
 for row in a['changed_occurrence_assessments']:
  key=(row['group'],row['input_id'],row['batch'],row['kind'],row['direction'],row['original_index'])
  assert key not in occurrence_reviews;occurrence_reviews[key]=(name,row)
rows=[];reuse=[]
for x in v['observations']:
 key=(x['group'],x['input_id'],x['batch']);original_key=key
 if key not in source_rows:
  assert x['group'] in {'ts-historical','py-historical'} and x['batch']=='repeat' and x['ordered_repeat_equal']
  key=(x['group'],x['input_id'],'first')
 name,review=source_rows[key];actual_path=OUT/'raw'/x['directory']/x['input_id']/'report.json';actual=read(actual_path)
 if key==original_key:assert review['report_sha256']==sha(actual_path)
 else:
  first=next(z for z in v['observations'] if (z['group'],z['input_id'],z['batch'])==key);first_path=OUT/'raw'/first['directory']/first['input_id']/'report.json';assert sha(first_path)==review['report_sha256']
  assert r.supervisor.clean(read(first_path),set(p['volatile_exclusions']))==r.supervisor.clean(actual,set(p['volatile_exclusions']))
  reuse.append({'input_id':x['input_id'],'first_sha256':sha(first_path),'repeat_sha256':sha(actual_path),'complete_ordered_pair_equal':True,'source_assessment':name,'basis':'Same input tree/config, entire ordered canonical report, findings/diagnostics/surfaces and every changed occurrence verified before reusing first-batch source judgments.'})
 s=review['score'];erratum=review.get('approved_meta_operator_erratum',False)
 assert s['retained_detected'] if review['label']=='vulnerable' else (erratum or s['false_alarm'] is False)
 rows.append({**review,'batch':x['batch'],'report_sha256':sha(actual_path),'assessment_source':name,'assessment_source_sha256':bindings[name],'source_assessment_reused_from_first':key!=original_key,'whole_seconds':x['timing']['elapsed_seconds'],'findings':x['finding_count'],'warnings':x['warning_count'],'unresolved_flows':x['unresolved_flow_count'],'surfaces':x['surface_count']})
occurrences=[]
for x in inv['changed_occurrences']:
 key=(x['group'],x['input_id'],x['batch'],x['kind'],x['direction'],x['original_index']);original=key
 if key not in occurrence_reviews:
  assert x['group'] in {'ts-historical','py-historical'} and x['batch']=='repeat';key=(*key[:2],'first',*key[3:])
 name,review=occurrence_reviews[key]
 assert x['entry']==review['entry'] and x['contexts']==review['contexts']
 assert all(k in judgments for k in x['contexts'])
 occurrences.append({**x,'assessment_source':name,'assessment_source_sha256':bindings[name],'assessment':review['assessment'],'source_assessment_reused_from_first':key!=original})
assert set(judgments)==set(inv['contexts']) and len(reuse)==45
counts={'vulnerable':0,'valid_negative':0,'meta_operator_errata':0}
for row in rows:
 if row.get('approved_meta_operator_erratum',False):counts['meta_operator_errata']+=1;assert len(row['source_assessment']['matches'])==2 and row['score']['false_alarm']
 elif row['label']=='vulnerable':counts['vulnerable']+=1
 else:counts['valid_negative']+=1
assert counts=={'vulnerable':76,'valid_negative':103,'meta_operator_errata':2},counts
result={'scanner':p['scanner'],'execution_gate_passed':True,'all_narrow_conditions_passed':True,'source_assessment_complete':True,'completed':181,'entire_ordered_pairs_equal':83,'unique_inputs':98,'typescript_observations':94,'python_observations':87,'condition_counts':counts,'rows':rows,'assessment_bindings':bindings,'first_batch_reuse':reuse,'changed_occurrence_assessments':occurrences,'context_assessments':dict(judgments),'source_contexts':len(judgments),'changed_occurrences':len(occurrences),'finding_occurrences':sum(x['findings'] for x in rows),'diagnostic_occurrences':sum(x['warnings']+x['unresolved_flows'] for x in rows),'surface_occurrences':sum(x['surfaces'] for x in rows),'maximum_whole_seconds':max(x['whole_seconds'] for x in rows),'normal_static_deadline_seconds':1800,'semgrep_rule_timeout_seconds':10,'cleanup_seconds':15,'maximum_existing_flow_workers_per_input':4,'budget_closed':True,'remaining':0,'unstarted_closed':0,'paid_calls':0,'target_execution':False,'technical_acceptance_received':False,'phase22_complete':False,'validation_sha256':sha(DEST/'validation.json'),'difference_inventory_sha256':sha(DEST/'difference-inventory.json'),'qualification':'Current-source exposed compatibility, not a fresh evaluation or new whole25/45Linux batch. Exactly11volatile exclusions, no sorting for equivalence. All changed occurrences source-assessed; unchanged source-bound judgments reused only after full report/delta/source proof. Calculator2added outside-metadata candidates perreport and14qualified Git repository-copy occurrences remain needs_review;2nominalfixedMetaoperator errata retain2matches each. Narrow route/path qualifications and unrelated unresolved surfaces remain. Same-agent static review, no independent/runtime validation or speedup.'}
with (DEST/'assessment.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('All181 current-source narrow conditions pass with2retainedMetaoperator errata;83wholeordered pairs; source assessment complete.')
