"""Assess all20 development observations, preserving added out-of-condition candidates."""
import hashlib,importlib.util,json,sys
from collections import Counter
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parents[3];BASE=PREP.parent;OUT=BASE/'v75-prior-language-results/ts-development-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase20_scoring import candidate_identity,score
from scripts.phase22_corpus import frozen,input_files
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();v=read(OUT/'validation.json');inventory=read(OUT/'difference-inventory.json');assert v['completed']==20 and v['entire_ordered_pairs_equal']==10
assert Counter(x['kind']+'/'+x['direction'] for x in inventory['changed_occurrences'])=={'finding/added':20,'warning/added':1882,'unresolved_flow/added':2110,'surface/added':10}
allowed_paths={'findings','review_activity/static/candidate_count','review_activity/static/unreviewed_count','static_analysis/coverage/surfaces','static_analysis/coverage/unresolved_flows','static_analysis/rule_outcomes','static_analysis/total_matches','summary/by_severity/High','summary/by_severity/Medium','summary/by_status/needs_review','summary/total','warnings'}
assert set(inventory['changed_paths'])==allowed_paths
purposes={
 'src/index.ts':'The application entry selects stdio/HTTP/WebSocket transports from arguments (default stdio), creates VulnerableMCPServer and catches startup failures. New argv/index/switch and environment/logging uncertainty remains. The startup319 surface stays unnamed/unresolved; source review establishes selected calls without claiming complete transport or metadata coverage.',
 'src/server.ts':'VulnerableMCPServer creates the official SDK Server, registers metadata/request/resource/prompt handlers, and switches request.params.name to imported tool handlers using request.params.arguments. New SDK-escape/logging/history/error uncertainty remains. The selected execute_system_command/read_file arms are visible in source, while complete named dispatch/schema coverage remains unresolved.',
 'src/tools/command-executor.ts':'handleExecuteCommand takes args.command directly to child_process.execSync at37. The call explicitly sets timeout60000 and inherits process.env; the adjacent no-timeout comment is not accurate. There is no command allowlist on this source path. Retain the new theoretical execution candidate as outside the calculator metadata-poisoning label; no target command or independent exploit ran.',
 'src/tools/file-reader.ts':'handleReadFile copies args.path to filePath, checks existsSync, then reads that same value at48. The existence check is not an allowed-root boundary. Retain the new theoretical filesystem candidate outside the calculator metadata-poisoning condition; no host file was read through the target.',
 'src/tools/database-query.ts':'The search-users helper logs SQL, prepares/executes it and formats rows using environment configuration. Newly reported database/logging uncertainty is retained and not promoted into a new SQL detection or a calculator metadata finding.',
 'src/tools/template-renderer.ts':'The template tool compiles caller-provided template text through Handlebars. The external compile call remains unresolved; no template execution, complete validation or new named-condition judgment is inferred.',
 'src/tools/calculator-shadow.ts':'This separate calculator dispatches arithmetic operations through a switch and logs its result. Conservative break/logging diagnostics remain; it is distinct from helpful_calculator metadata poisoning.',
 'src/tools/rug-pull.ts':'The data-processor tool switches between Buffer/base64/hash/JSON operations and a separate flag-reading branch, including indexing the third line of a literal-path file. Added call/control/index uncertainty is retained. No target branch, file access or exfiltration occurred; these operations are not the named calculator-description condition.',
 'src/tools/ansi-tool.ts':'The format-output tool switches output/control-code formatting modes. Added unsupported-break diagnostics remain; no terminal output was executed and no extra poisoning match is assigned from these diagnostics.',
 'src/tools/safe-calculator.ts':'The separate safe-calculator implementation checks expression patterns and strips whitespace. Those regex/string calls remain unresolved in the relevant paths; this review does not infer complete expression-execution safety from the tool name or absence of additional findings.',
 'src/transports/http-sse.ts':'HTTP transport setup registers CORS, JSON and URL-encoded middleware with50MB limits. The middleware/mount path remains unresolved. This alternate transport was never launched and supplies no broader authentication, schema or security guarantee.',
 'src/transports/websocket.ts':'The WebSocket transport reads optional operator port configuration. Added environment binding uncertainty is retained; no socket or target startup ran.',
 'src/tools/poisoned-tool.ts':'The fixed helpful_calculator description is plain arithmetic-help text even though historical comments still discuss poisoning. Its body still evaluates the expression and formats errors; those are separate code-execution concerns, not instructions in the actual fixed tool description. New error/expression binding uncertainty does not justify relabeling the metadata condition.',
 'src/tools/course.ts':'Mastra selects the first valid lesson when building course state, or resets to the first merged lesson if the prior selection disappeared. Both indexes follow nonempty checks; conservative array-alias uncertainty remains. These course-state choices are separate from the original directory-permission fallback condition.',
 'src/tools/__tests__/blog.test.ts':'The upstream blog test uses RegExp assertions. Binding uncertainty remains a test-source diagnostic; no upstream test ran and no production permission result is inferred.',
 'src/tools/__tests__/test-setup.ts':'The upstream test setup constructs mocked Response objects. Added binding uncertainty is retained; no mock fetch or target runtime was executed.',
}
contexts={}
for key,c in inventory['contexts'].items():
 assert c['path'] in purposes,c['path']
 contexts[key]={'path':c['path'],'source_sha256':c['source_sha256'],'line':c['line'],'assessment':purposes[c['path']],'runtime_proof':False}
g=p['groups']['ts-development'];manifest=frozen(approval_path=ROOT/g['source_freeze_approval']);anchors=[]
for iid,spans in [('integsec-calculator-poisoning-vulnerable',[('src/index.ts',147,195),('src/server.ts',43,139),('src/tools/command-executor.ts',13,43),('src/tools/file-reader.ts',15,48)]),('integsec-calculator-poisoning-fixed',[('src/tools/poisoned-tool.ts',11,48)]),('mastra-directory-fallback-vulnerable',[('src/tools/course.ts',382,388),('src/tools/course.ts',437,443)])]:
 item=next(i for i in manifest.inputs if i.id==iid);snapshot=next(s for s in manifest.snapshots if s.revision==item.snapshot);files=input_files(item,snapshot,ROOT)
 for path,start,end in spans:
  full_path=(Path(item.scan_root)/path).as_posix();data=files[full_path];lines=data.decode().splitlines();assert 1<=start<=end<=len(lines)
  anchors.append({'input_id':iid,'tree_sha256':item.tree_sha256,'scan_root':item.scan_root,'path':path,'archive_path':full_path,'source_sha256':hashlib.sha256(data).hexdigest(),'start_line':start,'end_line':end,'text':'\n'.join(f'{n}: {lines[n-1]}' for n in range(start,end+1))})
occurrences=[]
for row in inventory['changed_occurrences']:
 assert row['direction']=='added' and all(k in contexts for k in row['contexts'])
 if row['kind']=='finding':
  f=row['entry'];assert (f['rule_id'],f['location']['path'],f['location']['range']['start_line']) in {('SENT-002','src/tools/command-executor.ts',37),('SENT-012','src/tools/file-reader.ts',48)}
  meaning='Source-grounded additional theoretical candidate on a separate registered command/file tool. Not a match to the calculator metadata-poisoning label, and not silently counted as a false positive or an independent validated exploit. Full raw finding remains needs_review.'
 elif row['kind']=='surface':
  surface=row['entry'];assert surface['name'] is None and surface['status']=='unresolved' and surface['handler']['path']=='src/server.ts' and surface['handler']['range']['start_line']==92
  assert surface['examined_rule_ids']==['SENT-002','SENT-012','SENT-014','SENT-015','SENT-016']
  meaning='An additional startup-bound tool surface reaches the official request handler but retains ambiguous_dispatch and no tool name. All five flow rules examined it; this is no newly resolved named registration, complete schema or coverage claim.'
 else:meaning='Retain the exact added diagnostic and ordered index with its source-specific context judgment. Partial traversal and unresolved calls remain explicit; no warning becomes a new condition match.'
 occurrences.append({**row,'assessment_contexts':row['contexts'],'assessment':meaning})
rows=[]
for row in v['observations']:
 item=g['inputs'][row['input_id']];label=item['input']['label'];path=BASE/'v75-prior-language-results/raw'/row['directory']/row['input_id']/'report.json';report=read(path);reference=read(ROOT/item['reference_report']);excluded=set(p['volatile_exclusions'])
 old=r.supervisor.clean(reference,excluded);current=r.supervisor.clean(report,excluded)
 known={f['dedup_key'] for f in old['findings']};added=[f for f in current['findings'] if f['dedup_key'] not in known]
 assert [f for f in current['findings'] if f['dedup_key'] in known]==old['findings']
 if row['input_id'].startswith('integsec-'):
  assert len(added)==2
  assert {(f['rule_id'],f['location']['path'],f['location']['range']['start_line']) for f in added}=={('SENT-002','src/tools/command-executor.ts',37),('SENT-012','src/tools/file-reader.ts',48)}
  assert len(current['static_analysis']['coverage']['surfaces'])==len(old['static_analysis']['coverage']['surfaces'])+1
  expected=json.loads(json.dumps(old))
  for parts in [('review_activity','static','candidate_count'),('review_activity','static','unreviewed_count'),('static_analysis','total_matches'),('summary','by_status','needs_review'),('summary','total')]:
   node=expected
   for k in parts[:-1]:node=node[k]
   node[parts[-1]]+=2
  expected['summary']['by_severity']['High']+=1;expected['summary']['by_severity']['Medium']+=1
  for outcome in expected['static_analysis']['rule_outcomes']:
   if outcome['rule_id'] in {'SENT-002','SENT-012'}:outcome['match_count']+=1
  for key in ['review_activity','summary']:
   assert expected[key]==current[key]
  assert expected['static_analysis']['rule_outcomes']==current['static_analysis']['rule_outcomes']
 else:
  assert not added and current['static_analysis']['coverage']['surfaces']==old['static_analysis']['coverage']['surfaces']
 matches=item['assessment']['matches'];assert set(matches)<=known and not set(matches)&{f['dedup_key'] for f in added}
 assessment={'candidate_identity':candidate_identity(report['findings']),'matches':matches,'rationale':'All pre-existing ordered findings and original matching keys are unchanged at identical source/configuration/prerequisites. The only additions are separately source-assessed command/file candidates outside the calculator metadata condition. Mastra named permission findings remain identical. Refresh current candidate identity only to include the actual added raw findings; do not alter source labels, original matching keys or upstream code.'}
 scored=score(label=label,state='completed',findings=report['findings'],assessment=assessment);assert scored['retained_detected'] if label=='vulnerable' else scored['false_alarm'] is False
 rows.append({'input_id':row['input_id'],'batch':row['batch'],'label':label,'report_sha256':sha(path),'reference_report_sha256':sha(ROOT/item['reference_report']),'source_assessment':assessment,'candidate_identity_refreshed':bool(added),'added_unmatched_keys':[f['dedup_key'] for f in added],'original_matching_keys_unchanged':True,'score':scored,'whole_seconds':row['timing']['elapsed_seconds']})
refs=[g['assessment_path'],'artifacts/phase22/integration/v31-compatibility/source-assessment.json','artifacts/phase22/integration/v42-path-guard-regression/condition-assessment.json','artifacts/phase22/integration/v42-path-guard-regression/coverage-source-assessment.json']
result={'scanner':p['scanner'],'source_assessment_complete':True,'typescript_development_narrow_gate_passed':True,'completed':20,'entire_ordered_pairs_equal':10,'rows':rows,'context_assessments':contexts,'source_anchors':anchors,'changed_occurrence_assessments':occurrences,'changed_occurrences':len(occurrences),'source_contexts':len(contexts),'added_finding_occurrences':20,'added_unresolved_surface_occurrences':10,'removed_findings':0,'changed_existing_findings':0,'unchanged_reference_assessment_bindings':{name:sha(ROOT/name) for name in refs},'difference_inventory_sha256':sha(OUT/'difference-inventory.json'),'retained_read_only_error':'Exploratory Mastra course read first omitted packages/mcp-docs-server scan_root and raised KeyError. Corrected archive-path lookup used exact input.scan_root; no mutation or observation occurred.','budget_closed':False,'whole181_sequence_gate_passed':None,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'20 current-source exposed TypeScript development observations only. Added command/file findings remain separately reviewed candidates outside the named metadata condition; no independent exploit or target execution. New startup surface remains unnamed/unresolved. This is not a new whole25development or Linux historical run.'}
with (OUT/'assessment.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('TSdevelopment narrow conditions pass20/20;10whole pairs;4022changed occurrences/238contexts assessed, with20added unmatched candidates and10unresolved surfaces retained.')
