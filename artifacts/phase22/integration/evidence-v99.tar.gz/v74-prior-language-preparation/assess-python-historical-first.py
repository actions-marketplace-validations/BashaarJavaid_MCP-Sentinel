"""Assess all historical Python first reports; repeats require later complete equality."""
import copy,hashlib,importlib.util,json,sys
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parents[3];BASE=PREP.parent;OUT=BASE/'v75-prior-language-results/python-historical-first-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase20_scoring import candidate_identity,score
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();v=read(OUT/'validation.json');inv=read(OUT/'difference-inventory.json');git=read(OUT.parent/'git-first-assessment/assessment.json');gi=read(OUT.parent/'git-first-assessment/difference-inventory.json');prior=read(BASE/'v38-guard-regression/condition-assessment.json');clean=lambda x:r.supervisor.clean(x,set(p['volatile_exclusions']))
assert v['completed']==31 and v['entire_ordered_pairs_equal']==0 and git['source_assessment_complete']
rows=[];added=[];unchanged=0
for row in v['observations']:
 iid=row['input_id'];item=p['groups']['py-historical']['inputs'][iid];path=OUT.parent/'raw'/row['directory']/iid/'report.json';report=read(path);reference=read(ROOT/item['reference_report']);a=clean(reference);b=clean(report)
 old=next(x for x in prior['rows'] if x['group']=='historical' and x['batch']=='first' and x['input_id']==iid);assert old['report_sha256']==sha(ROOT/item['reference_report'])
 if iid.startswith('git-'):
  sourceid='git-staging-fixed' if iid=='git-status-safe' else iid
  previous=next(x for x in git['rows'] if x['input_id']==sourceid)
  if iid=='git-status-safe':
   sourceitem=p['groups']['py-historical']['inputs'][sourceid]
   assert item['input']['tree_sha256']==sourceitem['input']['tree_sha256'] and item['input']['scan_root']==sourceitem['input']['scan_root']
   priorrow=next(x for x in v['observations'] if x['input_id']==sourceid)
   assert b==clean(read(OUT.parent/'raw'/priorrow['directory']/sourceid/'report.json'))
   assert a==clean(read(ROOT/sourceitem['reference_report']))
  else:assert previous['report_sha256']==sha(path)
  keys=previous['added_unmatched_keys'];assert [f for f in b['findings'] if f['dedup_key'] not in keys]==a['findings']
  for f in b['findings']:
   if f['dedup_key'] in keys:
    judgment=next(x for x in git['added_finding_assessments'] if x['input_id']==sourceid);assert f==judgment['finding']
    added.append({**judgment,'input_id':iid,'batch':row['batch'],'safe_control_addendum':'For git-status-safe, actual full before/after reports and complete frozen source tree equal staging-fixed. Its status-options condition has no caller shell command; the broader repository original-path candidate is unrelated and remains needs_review.' if iid=='git-status-safe' else None})
 else:
  assert a['findings']==b['findings'] and a['static_analysis']['coverage']['surfaces']==b['static_analysis']['coverage']['surfaces']
  expected=copy.deepcopy(a);expected['warnings']=b['warnings'];expected['static_analysis']['coverage']['unresolved_flows']=b['static_analysis']['coverage']['unresolved_flows'];assert expected==b
  if iid.startswith('excel-') or iid.startswith('atlassian-ssrf-vulnerable'):assert a==b;unchanged+=1
 assessment={**old['source_assessment'],'candidate_identity':candidate_identity(report['findings']),'rationale':'Retain exact source-bound V38 named-condition keys and original labels after complete ordered report comparison. Seven Git resolved-copy candidates individually assessed as broader unmatched physical/identity uncertainty; all original findings unchanged. Atlassian removals concern explicitly assessed trim/URL parse operations only, not new authentication, URL, or path enforcement. Exact current identity refreshed after actual output review.'}
 s=score(label=item['input']['label'],state='completed',findings=report['findings'],assessment=assessment);assert s['retained_detected'] if item['input']['label']=='vulnerable' else s['false_alarm'] is False
 rows.append({'group':'py-historical','input_id':iid,'batch':row['batch'],'label':item['input']['label'],'report_sha256':sha(path),'source_assessment':assessment,'score':s,'whole_seconds':row['timing']['elapsed_seconds']})
assert len(added)==7 and unchanged==7
contexts={}
for key,c in inv['contexts'].items():
 if key in git['context_assessments']:
  assert c==gi['contexts'][key];contexts[key]=git['context_assessments'][key];continue
 path=c['path'];line=c['line'];statement=c['statement'].strip();assert path.startswith('src/mcp_atlassian/')
 if path.endswith('preprocessing/base.py') and line in {36,92}:
  assert statement=='self.base_url = base_url.rstrip("/") if base_url else ""';meaning='Processor stores a trailing-slash-trimmed base URL for HTML/content links. This assignment preserves source provenance; it neither validates authority nor authenticates the caller.'
 elif path.endswith('preprocessing/base.py') and line==425:
  assert statement=='path = urllib.parse.urlparse(src).path';meaning='The image URL path is parsed to derive alt-text filename immediately below. This is formatting, not an HTTP request or URL destination guard.'
 elif path.endswith('models/confluence/page.py') and line in {210,226}:
  assert statement=='base_url = base_url.rstrip("/")';meaning='Page model trims the supplied base URL before constructing cloud/server content links. No source qualification is broadened by removing this call uncertainty.'
 elif path.endswith('utils/urls.py') and line in {24,44}:
  assert statement=='return base_url.rstrip("/") + url';meaning='Only the slash-leading relative branch appends url to a trimmed base; the other branch returns url unchanged. This is source URL reconstruction, not an authority or private-network rejection. Existing actual request/credential findings and qualifications are unchanged.'
 elif path.endswith('confluence/attachments.py') and line in {94,95}:
  assert statement=='parsed = urllib.parse.urlsplit(download_url)';meaning='Legacy attachment resolution parses the path after use_v1/attachment_id/download_url preconditions, then extracts a content id from download/attachments. Parsing is not authorization or SSRF protection; no new initial or redirect safety is inferred.'
 elif path.endswith('confluence/attachments.py') and line in {48,49,438,511}:
  assert statement=='base_url = self.config.url.rstrip("/")';meaning={48:'Configured REST base is trimmed, then optionally gains /wiki for cloud use.',49:'Configured REST base is trimmed, then optionally gains /wiki for cloud use.',438:'Configured REST base is trimmed before the content-child-attachment upload endpoint.',511:'Configured REST base is trimmed before the attachment deletion endpoint.'}[line]+' Operator configuration and request-path provenance remain distinct from caller credentials and local upload path containment. All old findings and remaining unsupported operations stay visible.'
 elif path.endswith('confluence/permissions.py') and line==31:
  assert statement=='base_url = self.config.url.rstrip("/")';meaning='Non-OAuth REST base uses configured URL plus optional /wiki. The separate OAuth branch returns str(self.confluence.url).rstrip and is not this removed diagnostic. This formatting operation is not permission enforcement.'
 elif path.endswith('servers/confluence.py') and line in {1309,1332,1518,2166,2172}:
  assert statement=='base_url = confluence_fetcher.config.url.rstrip("/")';meaning=('Relative attachment download URL is appended to configured base before later request; no general authority/redirect safety follows.' if line in {1332,1518} else 'Configured base is trimmed before an attachment metadata URL and actual session.get two lines below. This operation is not itself the URL/authentication guard.')+' Original caller/guard/sink findings, source qualification and remaining diagnostics are unchanged.'
 else:raise AssertionError((path,line,statement))
 contexts[key]={'path':path,'line':line,'source_sha256':c['source_sha256'],'assessment':meaning,'runtime_proof':False}
occurrences=[]
for x in inv['changed_occurrences']:
 assert all(k in contexts for k in x['contexts'])
 if x['kind']=='finding':
  assert x['direction']=='added' and any(a['input_id']==x['input_id'] and a['finding']==x['entry'] for a in added)
  meaning='Individually assessed qualified Git repository-copy candidate is outside the named condition; retain needs_review and physical/identity uncertainty.'
 else:
  assert x['kind'] in {'warning','unresolved_flow'} and x['direction']=='removed' and x['entry']['message'].startswith('SENT-015 at ')
  meaning='Removed unsupported trim/URL parse occurrence is bound to actual source context; recognize only that supported operation. Removal alone is not a safety or authentication proof.'
 occurrences.append({**x,'assessment_contexts':x['contexts'],'assessment':meaning})
assert len(contexts)==98 and len(occurrences)==179
refs=['v38-guard-regression/condition-assessment.json','v38-guard-regression/finding-source-assessment.json','v38-guard-regression/diagnostic-source-assessment.json','v22-refresh-v1/condition-assessment.json','v75-prior-language-results/git-first-assessment/assessment.json']
result={'scanner':p['scanner'],'source_assessment_complete':True,'narrow_gates_passed':{'python-historical-first':True},'completed':31,'entire_ordered_pairs_equal':0,'rows':rows,'added_finding_assessments':added,'context_assessments':contexts,'changed_occurrence_assessments':occurrences,'changed_occurrences':179,'source_contexts':98,'finding_occurrences_added':7,'diagnostic_occurrences_removed':172,'surface_changes':0,'all_existing_ordered_findings_equal':True,'unchanged_reference_assessment_bindings':{name:sha(BASE/name) for name in refs},'difference_inventory_sha256':sha(OUT/'difference-inventory.json'),'helper_failure_retention':'Initial comparison started before dependent validation completed, failed on missing validation.json. Rerun with new wrapper label only after validation exit0; original failure retained, no input retried.','budget_closed':False,'whole181_sequence_gate_passed':None,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'31 first observations only; all31 repeats require final whole ordered equality before reuse. Original source-specific guard support and operator/caller prerequisites retained; no complete runtime safety, target execution or independent validation claim.'}
with (OUT/'assessment.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Historical Python31 first conditions pass:7 qualified Git additions and172 removed diagnostics;98 source contexts assessed.')
