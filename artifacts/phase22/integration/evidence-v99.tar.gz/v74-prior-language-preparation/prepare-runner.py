"""Prepare an unapproved normal-policy earlier-language runner from the retained evaluator."""
import difflib
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path('/private/tmp/mcp-phase22-options')
BASE=ROOT/'artifacts/phase22/integration'
OUT=BASE/'v74-prior-language-preparation'
OLD=BASE/'v66-invalidation-contract'
CURRENT=BASE/'v72-prototype-property-correction'
RESULT=BASE/'v73-corrected-four-results'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(RESULT/'completion-verification.json')['passed']
assert read(RESULT/'final-assessment/assessment.json')['all_four_narrow_gates_passed']
assert not (BASE/'v75-prior-language-results').exists()
OUT.mkdir(exist_ok=False)
(OUT/'prepare-runner.py').write_bytes(Path(__file__).read_bytes())
original=(OLD/'evaluate.py').read_text()
runner=original.replace('205','181').replace('== 110','== 98')
runner=runner.replace('receipt["source_recovery_authorization_sha256"] == sha(ASSETS / "authorization.json")',
    'receipt["intake_sha256"] == sha(ASSETS / "intake.json")')
runner=runner.replace('from sentinel.static.engine import STATIC_TIMEOUT_SECONDS',
    'from sentinel.static.engine import STATIC_TIMEOUT_SECONDS\n    from sentinel.static.semgrep_adapter import SEMGREP_TIMEOUT_SECONDS')
runner=runner.replace('assert STATIC_TIMEOUT_SECONDS == 1800',
    'assert STATIC_TIMEOUT_SECONDS == 1800 and SEMGREP_TIMEOUT_SECONDS == 10')
needle='    with patch.object(harness, "load_configuration", checked):'
assert runner.count(needle)==1
runtime='''    from sentinel.static import engine, workers, path_flow, typescript_path_flow, semgrep_adapter
    modules = (engine, workers, path_flow, typescript_path_flow, semgrep_adapter)
    imports = {module.__name__: str(module.__file__) for module in modules}
    assert all(Path(path).is_relative_to(Path(proposal["frozen_checkout"]) / "src") for path in imports.values())
    assert engine.STATIC_TIMEOUT_SECONDS == 1800 and semgrep_adapter.SEMGREP_TIMEOUT_SECONDS == 10
    write(out.with_name(out.name + "-runtime-binding.json"), {
        "scanner": proposal["scanner"], "imports": imports,
        "configuration_sha256": expected["configuration_sha256"],
        "normal_static_deadline_seconds": 1800, "semgrep_rule_timeout_seconds": 10,
        "maximum_existing_flow_workers_per_input": 4, "runtime_policy_override": False,
        "verified_before_target_access": True,
    })
'''
runner=runner.replace(needle,runtime+'\n'+needle)
assert 'uncapped' not in runner
compile(runner,'evaluate.py','exec')
(OUT/'evaluate.py').write_text(runner)
launch=(OLD/'launch.py').read_text().replace('v67-invalidation-regression','v75-prior-language-results').replace('205','181')
compile(launch,'launch.py','exec')
(OUT/'launch.py').write_text(launch)
(OUT/'runner-delta.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),runner.splitlines(True),fromfile='v66/evaluate.py',tofile='v74/evaluate.py')))
intake={'recorded_at':datetime.now(timezone.utc).isoformat(),'status':'prepared; numerical approval absent',
    'scanner':read(CURRENT/'freeze.json')['scanner'],'frozen_checkout':read(CURRENT/'freeze.json')['frozen_checkout'],
    'four_repository_assessment_sha256':sha(RESULT/'final-assessment/assessment.json'),
    'four_repository_completion_verification_sha256':sha(RESULT/'completion-verification.json'),
    'engineering_sha256':sha(CURRENT/'local-checks.json'),'freeze_sha256':sha(CURRENT/'freeze.json'),
    'prior_full_scope_proposal_sha256':sha(OLD/'evaluation-proposal.json'),
    'authority':{'path':'docs/phase22-corrected-regression-acceptance-closeout-agent-prompt.md',
        'sha256':sha(ROOT/'docs/phase22-corrected-regression-acceptance-closeout-agent-prompt.md'),
        'scope':'Sections1/8 authorize reversible preparation and require separate exact numerical approval for the excluded181 earlier-language observations after four repositories first.'},
    'source_change':False,'resource_change':False,'normal_policy_override':False,
    'normal_static_deadline_seconds':1800,'normal_semgrep_rule_timeout_seconds':10,
    'earlier_language_observations_executed':0,'new_paid_calls':0,
    'technical_acceptance_received':False,'phase22_complete':False,
    'retained':'V73 completed24/24 and12ordered pairs with four narrow exposed passes. All original failures, six historical closure proposals, strict/stale-root/singleton failures and timeout limits remain. No old budget is reopened.'}
with (OUT/'intake.json').open('x') as stream:json.dump(intake,stream,indent=2);stream.write('\n')
with (OUT/'runner-preparation.json').open('x') as stream:
    json.dump({'passed':True,'original_runner_sha256':sha(OLD/'evaluate.py'),'original_launcher_sha256':sha(OLD/'launch.py'),
        'runner_sha256':sha(OUT/'evaluate.py'),'launcher_sha256':sha(OUT/'launch.py'),
        'delta':'Counts become181observations/98inputs; approval binds this intake; actual Python/TypeScript/engine/worker/adapter imports and normal1800/10policy are recorded before target access. All measurement, stopping, cleanup, ordering and zero-call behavior remains the retained normal evaluator.',
        'compiled':True,'proposal_created':False,'approval_created':False,'token_created':False,'new_observations':0,'paid_calls':0},stream,indent=2);stream.write('\n')
print('Prepared normal-policy181-observation runner and source intake; no proposal approval, token or observation created.')
