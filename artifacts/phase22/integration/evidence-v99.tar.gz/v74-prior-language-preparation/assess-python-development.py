"""Assess complete Python development outputs; retain the two operator-label errata."""
import hashlib,importlib.util,json,sys
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parents[3];BASE=PREP.parent;OUT=BASE/'v75-prior-language-results/python-development-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase20_scoring import candidate_identity,score
from scripts.phase22_corpus import frozen,input_files
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();v=read(OUT/'validation.json');inv=read(OUT/'difference-inventory.json');prior=read(BASE/'v38-guard-regression/condition-assessment.json');excluded=set(p['volatile_exclusions']);clean=lambda x:r.supervisor.clean(x,excluded)
assert v['completed']==15 and v['entire_ordered_pairs_equal']==0 and set(inv['changed_paths'])=={'findings','warnings','static_analysis/coverage/unresolved_flows'}
rows=[];finding_changes=[];old_contexts=set();new_contexts=set();errata=0
for row in v['observations']:
 iid=row['input_id'];item=p['groups']['py-development']['inputs'][iid];label=item['input']['label'];path=BASE/'v75-prior-language-results/raw'/row['directory']/iid/'report.json';report=read(path);reference=read(ROOT/item['reference_report']);old=next(x for x in prior['rows'] if x['group']=='development' and x['input_id']==iid)
 assert old['report_sha256']==sha(ROOT/item['reference_report'])
 for before,after in zip(clean(reference['findings']),clean(report['findings']),strict=True):
  if before==after:continue
  assert iid.startswith('meta-image-ssrf-') and label!='vulnerable' and before['rule_id']==after['rule_id']=='SENT-015'
  assert {k:x for k,x in before.items() if k not in {'evidence','provenance'}}=={k:x for k,x in after.items() if k not in {'evidence','provenance'}}
  assert len(before['provenance'])==len(after['provenance'])==1
  assert {k:x for k,x in before['provenance'][0].items() if k!='evidence'}=={k:x for k,x in after['provenance'][0].items() if k!='evidence'}
  added=None
  for a,b in [(before['evidence'],after['evidence']),(before['provenance'][0]['evidence'],after['provenance'][0]['evidence'])]:
   assert {k:x for k,x in a.items() if k!='flow_locations'}=={k:x for k,x in b.items() if k!='flow_locations'}
   extra=[x for x in b['flow_locations'] if x not in a['flow_locations']]
   assert len(extra)==1 and extra[0]['path']=='meta_ads_mcp/core/utils.py' and extra[0]['range']['start_line']==210
   assert [x for x in b['flow_locations'] if x not in extra]==a['flow_locations']
   if added is not None:assert extra==added
   added=extra
  tree=item['input']['tree_sha256']
  for loc in [before['location'],*before['evidence']['flow_locations']]:old_contexts.add(f"{tree}:{loc['path']}:{loc['range']['start_line']}")
  new_contexts.add(f'{tree}:meta_ads_mcp/core/utils.py:210')
  finding_changes.append({'input_id':iid,'batch':row['batch'],'dedup_key':after['dedup_key'],'added_flow_locations':added,'assessment':'Only actual parsed-hostname presence evidence was added, identically in finding and provenance; all previous fields, caller/guard/sink locations and narrow private-literal wording remain exactly unchanged.'})
 if iid.startswith('dbt-'):assert clean(report)==clean(reference)
 if iid.startswith('meta-image-ssrf-') and label!='vulnerable':
  candidates=[f for f in report['findings'] if f['rule_id']=='SENT-015' and f['location']['path']=='meta_ads_mcp/core/utils.py' and f['location']['range']['start_line'] in {282,346,362}]
  assert len(candidates)==3 and all(f['description'].startswith('The source rejects private literal IPv4 destinations for this caller URL before the request.') for f in candidates)
  assert not old['source_assessment']['matches']
 assessment={**old['source_assessment'],'candidate_identity':candidate_identity(report['findings']),'rationale':'Retain exact V38 source-bound named-condition judgments after proving every unchanged field and individually assessing the one hostname evidence addition at each of3negative image request sinks. Cache-directory diagnostic removals are separate from URL and caller-credential guards. Current identity explicitly refreshed only after observation; original labels and matches unchanged.'}
 s=score(label=label,state='completed',findings=report['findings'],assessment=assessment);erratum=iid in {'meta-operator-fallback-fixed','meta-operator-fallback-fixed-mutation'}
 if erratum:assert len(assessment['matches'])==2 and s['false_alarm'];errata+=1
 else:assert s['retained_detected'] if label=='vulnerable' else s['false_alarm'] is False
 rule='SENT-002' if iid.startswith('dbt-') else ('SENT-015' if iid.startswith('meta-image-') else 'SENT-016');outcome=next(x for x in report['static_analysis']['rule_outcomes'] if x['rule_id']==rule);assert outcome['status']=='evaluated' and outcome['skip_reason'] is None
 rows.append({'group':'py-development','input_id':iid,'batch':row['batch'],'label':label,'report_sha256':sha(path),'source_assessment':assessment,'score':s,'approved_meta_operator_erratum':erratum,'whole_seconds':row['timing']['elapsed_seconds']})
assert len(finding_changes)==9 and errata==2
contexts={}
for key,c in inv['contexts'].items():
 if key in new_contexts:
  assert c['statement'].strip()=='if not host:'
  meaning='Actual parsed hostname is required before IP classification and the terminal BlockedURLError guard. This added evidence does not broaden the preserved initial private-literal IPv4 qualification to DNS, redirects or IPv6; source hook/resolution code is not runtime proof.'
 elif c['path'] in {'meta_ads_mcp/core/auth.py','meta_ads_mcp/core/pipeboard_auth.py'} and c['line'] in {148,136}:
  assert c['statement'].strip()=='cache_dir.mkdir(parents=True, exist_ok=True)'
  meaning='These helpers construct operator/platform cache directories from APPDATA or Path.home plus fixed Library/Application Support or .config/meta-ads-mcp components. Removed SENT-016 unresolved mkdir calls concern cache directory creation, not credential identity or enforcement. Operator token fallback findings remain unchanged; no filesystem call or token caching was executed.'
 else:
  assert key in old_contexts,(key,c['statement'])
  meaning='Exact original caller/authentication/transport/guard/request evidence context remains in the same ordered finding and frozen tree. Reuse V38 and its prior source judgments only after proving the sole hostname evidence addition; source launch alternatives, operator fallback, broader URL candidates and uncertainties remain unchanged.'
 contexts[key]={'path':c['path'],'line':c['line'],'source_sha256':c['source_sha256'],'assessment':meaning,'runtime_proof':False}
occurrences=[]
for x in inv['changed_occurrences']:
 if x['kind'] in {'warning','unresolved_flow'}:
  assert x['direction']=='removed' and x['entry']['message'] in {'SENT-016 at meta_ads_mcp/core/auth.py:148: unresolved call to cache_dir.mkdir; protection is not established','SENT-016 at meta_ads_mcp/core/pipeboard_auth.py:136: unresolved call to cache_dir.mkdir; protection is not established'}
 else:assert x['kind']=='finding'
 assert all(k in contexts for k in x['contexts'])
 occurrences.append({**x,'assessment_contexts':x['contexts'],'assessment':'Retain exact ordered before/after occurrence; apply explicit hostname-evidence or operator-cache context judgment. No missing diagnostic is used alone as a safety proof.'})
assert len(occurrences)==58 and len(contexts)==94
m=frozen(approval_path=ROOT/p['groups']['py-development']['source_freeze_approval']);item=next(i for i in m.inputs if i.id=='meta-image-ssrf-fixed');snapshot=next(s for s in m.snapshots if s.revision==item.snapshot);files=input_files(item,snapshot,ROOT);anchors=[]
for path,start,end in [('meta_ads_mcp/core/utils.py',191,237),('meta_ads_mcp/core/utils.py',259,282),('meta_ads_mcp/core/utils.py',310,328),('meta_ads_mcp/core/utils.py',334,364),('meta_ads_mcp/core/auth.py',137,150),('meta_ads_mcp/core/pipeboard_auth.py',125,140),('meta_ads_mcp/core/ads.py',1316,1324)]:
 data=files[path];ls=data.decode().splitlines();assert 1<=start<=end<=len(ls);anchors.append({'input_id':item.id,'tree_sha256':item.tree_sha256,'path':path,'source_sha256':hashlib.sha256(data).hexdigest(),'start_line':start,'end_line':end,'text':'\n'.join(f'{n}: {ls[n-1]}' for n in range(start,end+1))})
refs=['v38-guard-regression/condition-assessment.json','v38-guard-regression/finding-source-assessment.json','v38-guard-regression/diagnostic-source-assessment.json','v35-ddg-regression/finding-source-assessment.json','v21-full-linux-v1/development-condition-assessment.json']
result={'scanner':p['scanner'],'source_assessment_complete':True,'narrow_gates_passed':{'python-development':True},'completed':15,'entire_ordered_pairs_equal':0,'rows':rows,'finding_changes':finding_changes,'context_assessments':contexts,'source_guard_anchors':anchors,'changed_occurrence_assessments':occurrences,'changed_occurrences':len(occurrences),'source_contexts':len(contexts),'finding_occurrences_changed':18,'diagnostic_occurrences_removed':40,'surface_changes':0,'dbt_entire_reports_equal':5,'valid_negative_conditions':7,'vulnerable_conditions_detected':6,'approved_meta_operator_errata':2,'unchanged_reference_assessment_bindings':{name:sha(BASE/name) for name in refs},'difference_inventory_sha256':sha(OUT/'difference-inventory.json'),'budget_closed':False,'whole181_sequence_gate_passed':None,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'All15current-source development conditions assessed with2explicitly retained nominal-fixed operator errata. Their2matched keys each stay visible; no relabeling or valid-negative credit. Unrelated candidates/source launch alternatives and initial URL guard limits remain. Same-agent static source review; no target, network or token-cache execution.'}
with (OUT/'assessment.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Python development15complete:6vulnerable detections,7validnegatives,2retainedoperatorerrata;58changed occurrences/94contexts assessed.')
