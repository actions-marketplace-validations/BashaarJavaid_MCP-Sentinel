"""Validate the sole completed or stopped V75 sequence; never launch an input."""
import hashlib,importlib.util,json,sys
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parents[3];OUT=PREP.parent/'v75-prior-language-results';RAW=OUT/'raw';DEST=OUT/'ddg-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from sentinel.report.validate_json import validate_report_data
from sentinel.report.validate_sarif import validate_sarif_data
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();packet=read(RAW/'packet.json');approval=read(PREP/'evaluation-authorization.json')
assert packet['scanner']==p['scanner'] and packet['model_calls']==0 and not packet['target_execution']
assert packet['proposal_sha256']==sha(PREP/'evaluation-proposal.json')==approval['proposal_sha256']
assert packet['approval_sha256']==sha(PREP/'evaluation-authorization.json') and approval['approved']
selected=packet['attempts'][94:104]
assert len(selected)==10 and all(row['group'] in {'ddg'} and row['state']=='completed' for row in selected)
first={};checked=[];pairs=0
for row,expected in zip(selected,p['order'][94:104],strict=True):
 assert all(row[k]==v for k,v in expected.items())
 folder=RAW/row['directory'];path=folder/row['input_id']/'report.json';g=p['groups'][row['group']];item=g['inputs'][row['input_id']]
 if row['state']!='completed':
  checked.append({**row,'partial_report_present':path.exists(),'source_assessment_pending':True});continue
 r.completed(row['timing']);report=read(path);result=read(folder/'results.json')
 assert result['scanner']==p['scanner'] and result['manifest_sha256']==g['manifest_sha256'] and result['model_calls']==0 and not result['requests']
 if g['source_freeze_approval']:assert result['authorization_sha256']==sha(ROOT/g['source_freeze_approval'])
 assert len(result['outcomes'])==1 and result['outcomes'][0]['state']=='completed' and result['outcomes'][0]['report_sha256']==sha(path)
 assert sha(path.parent/'configuration.json')==item['configuration_sha256']
 runtime=read(folder.with_name(folder.name+'-runtime-binding.json'))
 assert runtime['scanner']==p['scanner'] and runtime['configuration_sha256']==item['configuration_sha256']
 assert runtime['normal_static_deadline_seconds']==1800 and runtime['semgrep_rule_timeout_seconds']==10
 assert runtime['maximum_existing_flow_workers_per_input']==4 and not runtime['runtime_policy_override'] and runtime['verified_before_target_access']
 assert runtime['imports']=={'sentinel.static.'+name:str(Path(p['frozen_checkout'])/'src/sentinel/static'/(name+'.py')) for name in ['engine','workers','path_flow','typescript_path_flow','semgrep_adapter']}
 validate_report_data(report);validate_sarif_data(read(path.with_suffix('.sarif')))
 assert report['analysisComplete'] and report['executionSuccessful'] and report['static_analysis']['duration_ms']<=1800000
 condition=r.condition(report,read(ROOT/item['reference_report']),item['assessment'],item['input']['label'],set(p['volatile_exclusions']),p['witnesses'].get(row['group'],{}).get(row['input_id']))
 assert condition==read(folder/'condition.json')
 if 'condition' in row:assert condition==row['condition']
 canonical=r.supervisor.clean(report,set(p['volatile_exclusions']))
 if row['batch']=='repeat':
  equal=canonical==first[row['input_id']];assert row['ordered_repeat_equal']==equal
  pairs+=int(equal)
  if packet['passed']:assert equal
 else:first[row['input_id']]=canonical
 checked.append({**row,'report_sha256':sha(path),'sarif_sha256':sha(path.with_suffix('.sarif')),'reference_sha256':sha(ROOT/item['reference_report']),'finding_count':len(report['findings']),'warning_count':len(report['warnings']),'unresolved_flow_count':len(report['static_analysis']['coverage']['unresolved_flows']),'surface_count':len(report['static_analysis']['coverage']['surfaces'])})
completed=sum(x['state']=='completed' for x in checked)
assert len(checked)==completed==10 and pairs==5
DEST.mkdir(exist_ok=False)
with (DEST/'validation.json').open('x') as f:json.dump({'validation_passed':True,'partial_group_only':'ddg','execution_gate_passed':None,'scanner':p['scanner'],'proposal_sha256':sha(PREP/'evaluation-proposal.json'),'approval_sha256':sha(PREP/'evaluation-authorization.json'),'observations':checked,'attempted':10,'completed':10,'entire_ordered_pairs_equal':5,'source_assessment_pending':True,'budget_closed':False,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Only the completed10 DDG observations are validated while the approved181 sequence continues. This is no complete sequence pass or budget closure.'},f,indent=2);f.write('\n')
print('Validated10 DDG reports and5entire ordered pairs; whole181 sequence remains separate.')
