"""Bind the unchanged earlier-language schedule to current scanner; no measurement."""
import collections, copy, hashlib, json, os, sys
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path('/private/tmp/mcp-phase22-options')
BASE=ROOT/'artifacts/phase22/integration'
OUT=BASE/'v74-prior-language-preparation'
OLD=BASE/'v66-invalidation-contract'
CURRENT=BASE/'v72-prototype-property-correction'
RESULT=BASE/'v73-corrected-four-results'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2);f.write('\n')
assert not (OUT/'evaluation-proposal.json').exists()
assert not (OUT/'evaluation-authorization.json').exists()
assert not (BASE/'v75-prior-language-results').exists()
(OUT/'prepare-proposal.py').write_bytes(Path(__file__).read_bytes())
old=read(OLD/'evaluation-proposal.json');p=copy.deepcopy(old)
freeze=read(CURRENT/'freeze.json');frozen=Path(freeze['frozen_checkout'])
assert read(OUT/'runner-boundaries.json')['passed']
# Historical immutable bindings remain evidence only; none reopen old budgets.
for name,digest in old['files_sha256'].items():assert sha(ROOT/name)==digest,name
excluded={'faf-read-root','no-bash-write-prefix','lightning-discover-linklocal','engram-export-home'}
p['groups']={k:v for k,v in p['groups'].items() if k not in excluded}
p['order']=[x for x in p['order'] if x['group'] not in excluded]
counts=collections.Counter((x['group'],x['input_id']) for x in p['order'])
assert len(p['order'])==181 and len(counts)==98
assert collections.Counter(counts.values())=={2:83,1:15}
assert all(group=='py-development' for (group,_),count in counts.items() if count==1)
langs=collections.Counter(p['groups'][x['group']]['actual_language'] for x in p['order'])
assert langs=={'typescript':94,'python':87},langs
p['scanner']=freeze['scanner'];p['frozen_checkout']=str(frozen)
p['prepared_command_cwd']=str(frozen)
p['runner']=str((OUT/'evaluate.py').relative_to(ROOT))
p['prepared_command']=[sys.executable,'-I',str(OUT/'evaluate.py'),'run',str(BASE/'v75-prior-language-results/raw')]
p['purpose']='Establish current-source compatibility after the corrected four-repository V73 narrow gates passed. Reuse the exact98 previously exposed earlier-language input records and original source prerequisites. This is a separate new181-observation approval; no four-repository rerun, source change or performance experiment.'
p['launch_precondition']='New explicit approval of this181-observation proposal at cec0322, bound to scanner/order/bounds/rubric/intake/launcher; one-use token absent and output absent before launch. Normal1800-second input,15-second cleanup and5555-minute outer worst-case cap; actual locked imports/configurations before target access. No paid calls.'
p['bounds'].update(native_observations=181,sequence_maximum_minutes=5555,internal_stop_minutes=5554,nominal_input_minutes=5430,semgrep_rule_timeout_seconds=10,maximum_existing_flow_workers_per_input=4,simultaneous_inputs=1)
p['retained_timeout_policy']['sequence_bound_basis']='181 x30 minutes =5430 nominal input-minutes plus retained125-minute reserve =5555 minutes (92h35m). Internal stop5554 minutes. Worst-case cap only, not a duration estimate. Inputs return immediately on completion; failures close all unused budget.'
p['gate']='Every original vulnerable condition and valid fixed/safe condition must retain actual source-supported caller/guard/value/sink handling and its precise narrow qualifier. Quiet unsupported negatives fail. Retain DDG actual-send CGNAT support and memorykeeper canonical-root support. Meta operator two nominal fixed errata retain their original matched keys and are not valid negatives. Source-assess every report, finding, warning, unresolved flow, surface, denominator and full ordered reference difference; no stale-key automatic refresh. All83 entire ordered repeats must agree after only11 original volatile exclusions.'
p['stop']='Stop and close all unused observations on user cancellation or identity, infrastructure, execution, whole/native timeout, schema, process-cleanup or entire ordered-repeat failure. Named condition/support failures remain outcomes for source assessment after collection. No retry, profile, tuning, extra diagnostic, comparator or replacement. This top-level policy supersedes the older nested TypeScript first-condition stop only for this proposed sequence, subject to explicit approval.'
p['scope_justification']='94 TypeScript plus87 Python observations;98 unchanged exposed records,83 entire ordered pairs and15 Python development single observations. All four-repository inputs are excluded after V73 completed24/24 and12/12 pairs with four narrow passes. Earlier shared worker/flow/credential/correctness changes require actual current-source compatibility. Old205 budgets remain closed. Preserve whole25 development and whole45+45 Linux bindings; do not relabel these language subsets as whole Linux batches.'
p['original_source_bindings']['four_fresh']='Excluded from this proposal. V44 original2e0efb2 all4failed and V70 preceding4145d35 twofailed remain. V73 currentcec0322 completed24/24,12equal ordered pairs and all4 narrow exposed gates pass; all6FAF durations exceed normal1800 seconds.'
p['not_authorized']+=['four-repository rerun','uncapped timeout policy','source-only performance attempt','runtime or resource change']
p['schedule_summary']={'observations':181,'distinct_input_records':98,'entire_ordered_pairs':83,'single_python_development_inputs':15,'languages':dict(langs),'group_order_and_counts':[{ 'group':k,'input_records':len(v['inputs']),'observations':sum(x['group']==k for x in p['order'])} for k,v in p['groups'].items()]}
r72=read(CURRENT/'scoring-rubric.json')
rubric={'status':'proposed_not_approved_not_executed','prior_typescript':r72['prior_typescript'],'prior_python':r72['prior_python'],
 'scope_interpretation':'Only181 earlier-language observations at currentcec0322. Nested old source IDs and spent scope clauses remain historical. This proposal order/bounds/collection_stop govern after explicit approval; original condition/support criteria and11 exclusions are unchanged.',
 'collection_stop':p['stop'],'repeat':'83 entire ordered report pairs after only11 named volatile exclusions;15Python development inputs once. No sorting or new exclusions.',
 'assessment':p['gate'],'technical_acceptance':False,'paid_calls':0,'target_execution':False}
write(OUT/'scoring-rubric.json',rubric)
# Validate original source archive, metadata and selected records using the frozen scanner's existing validators.
os.chdir(frozen);sys.path[:0]=[str(frozen/'src'),str(frozen)]
from scripts.phase20_measurements import scanner_identity
from scripts.phase20_corpus import validate
from scripts.phase22_corpus import frozen as validate_frozen
from sentinel.static import engine, workers, path_flow, typescript_path_flow, semgrep_adapter
assert scanner_identity()==p['scanner']
assert engine.STATIC_TIMEOUT_SECONDS==1800 and semgrep_adapter.SEMGREP_TIMEOUT_SECONDS==10
assert sha(frozen/'uv.lock')==p['lock_sha256']
imports={m.__name__:str(m.__file__) for m in (engine,workers,path_flow,typescript_path_flow,semgrep_adapter)}
assert all(Path(v).is_relative_to(frozen/'src') for v in imports.values())
validated=[]
for name,g in p['groups'].items():
 assert sha(frozen/g['manifest'])==g['manifest_sha256']
 manifest=validate() if name.endswith('historical') else validate_frozen(approval_path=frozen/g['source_freeze_approval'])
 selected=[i for i in manifest.inputs if i.id in g['input_ids']]
 assert [i.id for i in selected]==g['input_ids']
 assert all(i.model_dump(mode='json')==g['inputs'][i.id]['input'] for i in selected)
 for item in g['inputs'].values():
  assert sha(ROOT/item['configuration'])==item['configuration_sha256']
  assert read(ROOT/item['configuration'])['static_only'] is True
 validated.append({'group':name,'manifest_sha256':g['manifest_sha256'],'selected':len(selected),'labels':dict(collections.Counter(i.label for i in selected))})
 print(name,len(selected),'immutable records validated',flush=True)
write(OUT/'source-binding-validation.json',{'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),'scanner':p['scanner'],'imports':imports,'groups':validated,'original_bound_files_verified':len(old['files_sha256']),'original_groups_and_order_exact_subset':True,'observations':0,'paid_calls':0,'target_execution':False,'read_only_error_retained':'Exploratory group listing treated mapping keys as objects and raised AttributeError; corrected to .items(). No mutation or observation occurred.'})
# Bind the concrete prepared artifacts and all unchanged engineering inputs.
files=dict(old['files_sha256'])
for name,digest in read(CURRENT/'local-checks.json')['candidate_engineering_files_sha256'].items():
 assert sha(ROOT/name)==sha(frozen/name)==digest,name
 files[name]=digest
for file in [*OUT.glob('*.py'),OUT/'intake.json',OUT/'runner-preparation.json',OUT/'runner-delta.patch',OUT/'runner-boundaries.json',OUT/'scoring-rubric.json',OUT/'source-binding-validation.json',CURRENT/'freeze.json',CURRENT/'local-checks.json',RESULT/'completion-verification.json',RESULT/'final-assessment/assessment.json',OLD/'evaluation-proposal.json']:
 files[str(file.relative_to(ROOT))]=sha(file)
p['files_sha256']=files
write(OUT/'evaluation-proposal.json',p)
write(OUT/'launcher-binding.json',{'proposal_sha256':sha(OUT/'evaluation-proposal.json'),'launcher_sha256':sha(OUT/'launch.py'),'runner_sha256':sha(OUT/'evaluate.py'),'command':[sys.executable,'-I',str(OUT/'launch.py')],'scope':'Separate181-observation current-source normal-policy approval required; no output/token/input access without exact receipt.','approved':False,'executed':False,'paid_calls':0})
print('Proposal',sha(OUT/'evaluation-proposal.json'),'181observations/98inputs/83pairs; NOTAPPROVED, zeroexecuted.')
