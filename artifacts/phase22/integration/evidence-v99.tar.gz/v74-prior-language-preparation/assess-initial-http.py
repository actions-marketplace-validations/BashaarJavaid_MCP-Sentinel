"""Assess SearXNG/fetchmcp complete outputs and all changed source diagnostics."""
import hashlib,importlib.util,json,sys
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parents[3];BASE=PREP.parent;OUT=BASE/'v75-prior-language-results/initial-http-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase20_scoring import candidate_identity,score
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();v=read(OUT/'validation.json');inventory=read(OUT/'difference-inventory.json')
assert v['completed']==20 and v['entire_ordered_pairs_equal']==10
assert inventory['comparisons']==20 and set(inventory['changed_paths'])=={'warnings','static_analysis/coverage/unresolved_flows'}
contexts={}
for key,c in inventory['contexts'].items():
 path=c['path']
 if path=='src/url-reader.ts':
  assert c['line'] in {101,116,146,118,133,163}
  assert c['statement'].strip() in {'const line = lines[i];','return paragraphs[start] || "";'}
  meaning='extractSection indexes already fetched Markdown lines to find heading boundaries; extractParagraphRange returns a selected paragraph after range checks. Conservative array-alias uncertainty remains. These post-response text operations are separate from the named initial loopback request policy; no broader parser or response safety is inferred.'
 elif path=='__tests__/helpers/env-utils.ts':
  assert c['line'] in {None,69,74,80,82}
  meaning='The upstream EnvManager test helper saves, sets, deletes and restores process.env entries, with a Map of snapshots. Computed assignments/deletions correctly retain receiver uncertainty. These upstream tests were not executed and did not mutate the frozen production opt-in configuration.'
 elif path=='src/resources.ts':
  assert c['line'] is None
  meaning='The resource module formats status/configuration information from operator authentication-presence, proxy, runtime-version and HTTP-port settings and serializes JSON. Added environment/JSON binding uncertainty concerns resource reporting, not the registered web_url_read initial destination check. No endpoint, target environment or authentication behavior was executed.'
 elif path=='__tests__/helpers/mock-fetch.ts':
  assert c['line'] is None
  meaning='The upstream test helper replaces/restores global.fetch for mocked responses. Unknown global/fetch binding remains a test-source diagnostic, not evidence of a production request or destination guard. No mock or target test was executed.'
 elif path.startswith('__tests__/') or path=='src/Fetcher.test.ts':
  assert c['line'] is None
  meaning='The upstream test source uses module-entry arguments, environment setup, standard Error/JSON bindings, result assertions or console logging. Added binding uncertainty is retained; neither test expectations nor hypothetical success establish production protection. The target tests were only read.'
 else:raise AssertionError(path)
 contexts[key]={'path':path,'source_sha256':c['source_sha256'],'line':c['line'],'assessment':meaning,'runtime_proof':False}
occurrences=[]
for row in inventory['changed_occurrences']:
 assert row['kind'] in {'warning','unresolved_flow'} and row['direction']=='added'
 assert all(key in contexts for key in row['contexts'])
 occurrences.append({**row,'assessment_contexts':row['contexts'],'assessment':'Retain this exact added diagnostic and original ordered index. The bound source-specific interpretation neither changes the named condition nor supplies general runtime safety.'})
rows=[]
for row in v['observations']:
 group=row['group'];item=p['groups'][group]['inputs'][row['input_id']];label=item['input']['label']
 path=BASE/'v75-prior-language-results/raw'/row['directory']/row['input_id']/'report.json';report=read(path);reference=read(ROOT/item['reference_report'])
 assert r.supervisor.clean(report['findings'],set(p['volatile_exclusions']))==r.supervisor.clean(reference['findings'],set(p['volatile_exclusions']))
 assert r.supervisor.clean(report['static_analysis']['coverage']['surfaces'],set(p['volatile_exclusions']))==r.supervisor.clean(reference['static_analysis']['coverage']['surfaces'],set(p['volatile_exclusions']))
 source_path='src/url-reader.ts' if group=='searxng' else 'src/Fetcher.ts';line=(262 if label=='vulnerable' else 287) if group=='searxng' else (25 if label=='vulnerable' else 27)
 named=[f for f in report['findings'] if f['rule_id']=='SENT-015' and f['location']['path']==source_path and f['location']['range']['start_line']==line]
 assert len(named)==1
 if label=='vulnerable':assert named[0]['dedup_key'] in item['assessment']['matches'] and named[0]['description'].startswith('A caller URL reaches an outbound request')
 else:
  assert named[0]['dedup_key'] not in item['assessment']['matches']
  prefix='The source rejects literal loopback IPv4 destinations for this caller URL unless an environment option is explicitly set to true.' if group=='searxng' else 'The source rejects private literal IPv4 destinations for this caller URL before the request.'
  assert named[0]['description'].startswith(prefix)
 outcome=next(x for x in report['static_analysis']['rule_outcomes'] if x['rule_id']=='SENT-015');assert outcome['status']=='evaluated' and outcome['skip_reason'] is None
 assessment={'candidate_identity':candidate_identity(report['findings']),'matches':item['assessment']['matches'],'rationale':'Every ordered finding, source/flow location and narrow qualifier equals the exact previously source-assessed reference on unchanged source/configuration/prerequisites. All changed diagnostics are separately source-assessed as response text, reporting or unexecuted test operations. Preserve SearXNG opt-ins-unset initial loopback qualification or fetchmcp initial private-literal IPv4 qualification only; no DNS/redirect/fullIPv6 safety claim.'}
 scored=score(label=label,state='completed',findings=report['findings'],assessment=assessment)
 assert scored['retained_detected'] if label=='vulnerable' else scored['false_alarm'] is False
 rows.append({'group':group,'input_id':row['input_id'],'batch':row['batch'],'label':label,'report_sha256':sha(path),'reference_report_sha256':sha(ROOT/item['reference_report']),'named_candidate':named[0],'source_assessment':assessment,'score':scored,'whole_seconds':row['timing']['elapsed_seconds']})
refs={p['groups'][group]['assessment_path'] for group in ['searxng','fetchmcp']}
refs.update('artifacts/phase22/integration/'+name for name in ['v31-compatibility/source-assessment.json','v42-path-guard-regression/condition-assessment.json','v42-path-guard-regression/coverage-source-assessment.json'])
result={'scanner':p['scanner'],'source_assessment_complete':True,'narrow_gates_passed':{'searxng':True,'fetchmcp':True},'completed':20,'entire_ordered_pairs_equal':10,'rows':rows,'context_assessments':contexts,'changed_occurrence_assessments':occurrences,'changed_occurrences':len(occurrences),'source_contexts':len(contexts),'finding_changes':0,'surface_changes':0,'all_other_ordered_fields_equal':True,'unchanged_reference_assessment_bindings':{name:sha(ROOT/name) for name in sorted(refs)},'difference_inventory_sha256':sha(OUT/'difference-inventory.json'),'budget_closed':False,'whole181_sequence_gate_passed':None,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Completed20 current-source exposed SearXNG/fetchmcp observations only; original failures, exact narrow initial-request qualifiers and every unrelated candidate/diagnostic/support limit remain. These are not a new whole Linux batch or a general accuracy/safety claim.'}
with (OUT/'assessment.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('SearXNG/fetchmcp narrow gates pass20/20;10whole pairs;1390changed diagnostic occurrences and76contexts assessed. Whole181sequence remains separate.')
