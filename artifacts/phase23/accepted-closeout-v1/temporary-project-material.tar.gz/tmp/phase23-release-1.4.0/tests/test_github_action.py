"""Composite GitHub Action adapter and metadata tests."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any, cast

import pytest
import yaml

from scripts.run_github_action import (
    ActionInputs,
    ActionResult,
    SarifMetrics,
    analyze_sarif,
    emit_action_state,
    execute_action,
    render_step_summary,
    resolve_baseline,
    resolve_target,
    sarif_category,
)
from sentinel.config import LlmConfig
from sentinel.finding import Finding, FindingStatus, TokenUsage
from sentinel.llm.semantic_reviewer import MODEL, empty_review_outcome
from sentinel.report.model import (
    GptBatchRecord,
    ScanReport,
    ScanTarget,
    StageName,
    StageRecord,
    StageStatus,
    StaticAnalysisSummary,
    StaticRuleOutcome,
    StaticRuleStatus,
    summarize,
)
from sentinel.report.sarif import render_sarif
from tests.conftest import NOW, SCAN_ID


def _sarif_payload(finding: Finding | None = None) -> dict[str, object]:
    findings = (finding,) if finding is not None else ()
    selected = (finding.rule_id,) if finding is not None else ("SENT-002",)
    llm = LlmConfig()
    batch = GptBatchRecord(
        batch_id="batch-1",
        request_fingerprint="a" * 64,
        mode="live",
        requested_model=MODEL,
        returned_model=MODEL,
        endpoint_mode=llm.endpoint_mode,
        endpoint_url_hash=llm.endpoint_url_hash,
        reasoning_effort=llm.reasoning_effort,
        finding_count=len(findings),
        retry_count=0,
        status="accepted",
        schema_valid=True,
        current_usage=TokenUsage(
            input_tokens=100,
            output_tokens=20,
            reasoning_tokens=10,
            cached_tokens=5,
            total_tokens=130,
        ),
        origin_usage=TokenUsage(total_tokens=130),
        current_latency_ms=25,
        origin_latency_ms=25,
        confirmed_count=len(findings),
    )
    review = empty_review_outcome(LlmConfig(), mode="live").summary.model_copy(
        update={
            "candidate_count": len(findings),
            "selected_count": len(findings),
            "reviewed_count": len(findings),
            "confirmed_count": len(findings),
            "cache_misses": len(findings),
            "current_usage": batch.current_usage,
            "origin_usage": batch.origin_usage,
            "current_latency_ms": batch.current_latency_ms,
            "origin_latency_ms": batch.origin_latency_ms,
            "batches": (batch,) if findings else (),
        }
    )
    report = ScanReport(
        scan_id=SCAN_ID,
        sentinel_version="0.1.0",
        started_at=NOW,
        completed_at=NOW,
        target=ScanTarget(display_name="action-fixture"),
        analysis_complete=True,
        execution_successful=True,
        stages=tuple(
            StageRecord(name=name, status=StageStatus.SUCCEEDED) for name in StageName
        ),
        summary=summarize(findings),
        warnings=(),
        findings=findings,
        static_analysis=StaticAnalysisSummary(
            selected_rule_ids=selected,
            scanned_file_count=1,
            ignored_file_count=0,
            total_matches=len(findings),
            duration_ms=1,
            rule_outcomes=tuple(
                StaticRuleOutcome(
                    rule_id=rule_id,
                    status=StaticRuleStatus.EVALUATED,
                    match_count=len(findings),
                    exemptions_by_reason={},
                )
                for rule_id in selected
            ),
        ),
        gpt_review=review,
    )
    return cast(dict[str, Any], json.loads(render_sarif(report)))


def _environment(workspace: Path, runner_temp: Path) -> dict[str, str]:
    return {
        "GITHUB_WORKSPACE": str(workspace),
        "RUNNER_TEMP": str(runner_temp),
        "GITHUB_RUN_ID": "42",
        "GITHUB_RUN_ATTEMPT": "1",
        "GITHUB_ACTION": "sentinel",
        "GITHUB_EVENT_NAME": "push",
        "GITHUB_REPOSITORY": "BashaarJavaid/demo",
        "SENTINEL_ACTION_OPENAI_API_KEY": "secret-value",
    }


def test_analyze_sarif_counts_all_results_but_excludes_suppressed_severity(
    sample_finding: Finding,
) -> None:
    payload = _sarif_payload(sample_finding)
    metrics = analyze_sarif(payload)
    assert metrics.findings_count == 1
    assert metrics.highest_severity == "high"

    suppressed = sample_finding.model_copy(update={"status": FindingStatus.SUPPRESSED})
    suppressed_metrics = analyze_sarif(_sarif_payload(suppressed))
    assert suppressed_metrics.findings_count == 1
    assert suppressed_metrics.highest_severity == "none"

    runs = cast(list[dict[str, Any]], payload["runs"])
    result = cast(list[dict[str, Any]], runs[0]["results"])[0]
    cast(dict[str, Any], result["properties"])["baselineMatched"] = True
    baseline_metrics = analyze_sarif(payload)
    assert baseline_metrics.findings_count == 1
    assert baseline_metrics.highest_severity == "none"


@pytest.mark.parametrize("scan_exit", [0, 1, 3])
def test_execute_action_validates_and_preserves_report_bearing_exits(
    tmp_path: Path,
    sample_finding: Finding,
    scan_exit: int,
) -> None:
    workspace = tmp_path / "workspace"
    target = workspace / "server"
    target.mkdir(parents=True)
    runner_temp = tmp_path / "runner"
    runner_temp.mkdir()
    environment = _environment(workspace, runner_temp)

    def fake_run(
        command: list[str], *, env: dict[str, str], check: bool
    ) -> subprocess.CompletedProcess[str]:
        assert check is False
        assert env["OPENAI_API_KEY"] == "secret-value"
        assert "--allow-degraded" not in command
        output = Path(command[command.index("--output") + 1])
        output.write_text(json.dumps(_sarif_payload(sample_finding)), encoding="utf-8")
        return subprocess.CompletedProcess(command, scan_exit)

    result = execute_action(
        ActionInputs("server", "high", "false"),
        environment,
        command_runner=fake_run,
    )
    assert result.effective_exit_code == scan_exit
    assert result.upload_ready is True
    assert result.category == "mcp-sentinel/server"
    assert result.metrics.findings_count == 1
    assert result.metrics.highest_severity == "high"


def test_fork_pull_request_withholds_secret_degrades_and_skips_upload(
    tmp_path: Path, sample_finding: Finding
) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    runner_temp = tmp_path / "runner"
    runner_temp.mkdir()
    event_path = tmp_path / "event.json"
    event_path.write_text(
        json.dumps(
            {"pull_request": {"head": {"repo": {"full_name": "contributor/demo"}}}}
        ),
        encoding="utf-8",
    )
    environment = {
        **_environment(workspace, runner_temp),
        "GITHUB_EVENT_NAME": "pull_request",
        "GITHUB_EVENT_PATH": str(event_path),
    }

    def fake_run(
        command: list[str], *, env: dict[str, str], check: bool
    ) -> subprocess.CompletedProcess[str]:
        assert check is False
        assert "OPENAI_API_KEY" not in env
        assert "--allow-degraded" in command
        output = Path(command[command.index("--output") + 1])
        output.write_text(json.dumps(_sarif_payload(sample_finding)), encoding="utf-8")
        return subprocess.CompletedProcess(command, 1)

    result = execute_action(
        ActionInputs(".", "high", "false"),
        environment,
        command_runner=fake_run,
    )
    assert result.fork_pull_request is True
    assert result.upload_ready is False
    assert result.effective_exit_code == 1
    assert result.category == "mcp-sentinel/root"
    assert "credentials were withheld" in render_step_summary(result)


def test_invalid_or_missing_sarif_blocks_upload(tmp_path: Path) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    runner_temp = tmp_path / "runner"
    runner_temp.mkdir()
    environment = _environment(workspace, runner_temp)

    def invalid_run(
        command: list[str], *, env: dict[str, str], check: bool
    ) -> subprocess.CompletedProcess[str]:
        del env, check
        output = Path(command[command.index("--output") + 1])
        output.write_text("{}", encoding="utf-8")
        return subprocess.CompletedProcess(command, 0)

    invalid = execute_action(
        ActionInputs(".", "high", "true"),
        environment,
        command_runner=invalid_run,
    )
    assert invalid.effective_exit_code == 3
    assert invalid.upload_ready is False
    assert "validation failed" in (invalid.message or "")

    missing = execute_action(
        ActionInputs(".", "high", "true"),
        environment,
        command_runner=lambda command, **kwargs: subprocess.CompletedProcess(
            command, 2
        ),
    )
    assert missing.effective_exit_code == 2
    assert missing.upload_ready is False


def test_target_must_remain_inside_workspace(tmp_path: Path) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    outside = tmp_path / "outside"
    outside.mkdir()
    (workspace / "escape").symlink_to(outside, target_is_directory=True)
    with pytest.raises(ValueError, match="escapes"):
        resolve_target(workspace.resolve(), "escape")
    assert sarif_category(Path("services/payments")) == (
        "mcp-sentinel/services/payments"
    )


def test_baseline_must_be_regular_and_inside_workspace(tmp_path: Path) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    baseline = workspace / "baseline.json"
    baseline.write_text("{}", encoding="utf-8")
    assert resolve_baseline(workspace.resolve(), "baseline.json") == baseline
    assert resolve_baseline(workspace.resolve(), "") is None

    link = workspace / "link.json"
    link.symlink_to(baseline)
    with pytest.raises(ValueError, match="symlink"):
        resolve_baseline(workspace.resolve(), "link.json")
    with pytest.raises(ValueError, match="in GITHUB_WORKSPACE"):
        resolve_baseline(workspace.resolve(), "../outside.json")


def test_outputs_and_summary_are_aggregate_only(tmp_path: Path) -> None:
    output = tmp_path / "output"
    summary = tmp_path / "summary"
    result = ActionResult(
        effective_exit_code=0,
        sarif_path=tmp_path / "report.sarif",
        checkout_path=tmp_path,
        category="mcp-sentinel/root",
        fork_pull_request=False,
        upload_ready=True,
        metrics=SarifMetrics(
            findings_count=2,
            highest_severity="critical",
            analysis_complete=True,
            review={
                "mode": "replay",
                "requested_model": MODEL,
                "candidate_count": 2,
                "reviewed_count": 1,
                "overflow_count": 1,
                "cache_hits": 1,
                "batches": [{"returned_model": MODEL}],
                "current_usage": {"total_tokens": 50},
            },
        ),
    )
    emit_action_state(
        result,
        {"GITHUB_OUTPUT": str(output), "GITHUB_STEP_SUMMARY": str(summary)},
    )
    output_text = output.read_text(encoding="utf-8")
    summary_text = summary.read_text(encoding="utf-8")
    assert "findings-count=2" in output_text
    assert "highest-severity=critical" in output_text
    assert summary_text.startswith("## PortunusMCP Sentinel\n")
    assert "Mode | replay" in summary_text
    assert "Reviewed / skipped | 1 / 1" in summary_text
    assert "Truncated | yes (1 overflow)" in summary_text
    assert "snippet" not in summary_text


def test_action_metadata_exposes_only_approved_interface() -> None:
    root = Path(__file__).resolve().parents[1]
    metadata = yaml.safe_load((root / "action.yml").read_text(encoding="utf-8"))
    assert metadata["name"] == "PortunusMCP Sentinel"
    assert set(metadata["inputs"]) == {
        "target-path",
        "fail-on",
        "openai-api-key",
        "static-only",
        "rules-only",
        "baseline",
    }
    assert metadata["inputs"]["target-path"]["default"] == "."
    assert metadata["inputs"]["fail-on"]["default"] == "high"
    assert metadata["inputs"]["baseline"]["default"] == ""
    assert set(metadata["outputs"]) == {
        "sarif-path",
        "findings-count",
        "highest-severity",
    }
    assert metadata["runs"]["steps"][0]["with"]["python-version"] == "3.12"
    assert metadata["runs"]["steps"][1]["run"] == (
        "python -m pip install --disable-pip-version-check "
        "--index-url https://pypi.org/simple portunusmcp-sentinel==1.4.0"
    )
    uses = [step.get("uses", "") for step in metadata["runs"]["steps"]]
    assert any(value.startswith("actions/setup-python@ece7cb06") for value in uses)
    assert any(
        value.startswith("github/codeql-action/upload-sarif@7188fc36") for value in uses
    )

    release_text = (root / ".github/workflows/release.yml").read_text(encoding="utf-8")
    release = yaml.load(release_text, Loader=yaml.BaseLoader)
    assert release["on"]["push"]["tags"] == ["v*.*.*"]
    ci_text = (root / ".github/workflows/ci.yml").read_text(encoding="utf-8")
    assert "python -m pip install pipx\n" not in release_text + ci_text
    assert "python -m pip install pipx==1.16.0" in release_text + ci_text


@pytest.mark.parametrize("fork", (False, True))
@pytest.mark.parametrize("selection", ("", "true", "false"))
def test_rules_only_action_inheritance_override_and_summary(
    tmp_path: Path, fork: bool, selection: str
) -> None:
    import shutil

    from typer.testing import CliRunner

    from sentinel.cli import app

    workspace = tmp_path / "workspace"
    target = workspace / "server"
    shutil.copytree(Path(__file__).parent / "fixtures/vulnerable_server", target)
    (target / "sentinel.toml").write_text(
        "[scanner]\nrules_only = true\n", encoding="utf-8"
    )
    temporary = tmp_path / "runner"
    temporary.mkdir()
    environment = _environment(workspace, temporary)
    environment.pop("SENTINEL_ACTION_OPENAI_API_KEY")
    event = tmp_path / "event.json"
    event.write_text(
        json.dumps(
            {
                "pull_request": {
                    "head": {
                        "repo": {
                            "full_name": "fork/repo"
                            if fork
                            else environment["GITHUB_REPOSITORY"]
                        }
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    environment.update(GITHUB_EVENT_NAME="pull_request", GITHUB_EVENT_PATH=str(event))

    def run(
        command: list[str], *, env: dict[str, str], check: bool
    ) -> subprocess.CompletedProcess[str]:
        assert "OPENAI_API_KEY" not in env
        if selection:
            assert (
                "--rules-only" if selection == "true" else "--no-rules-only"
            ) in command
        else:
            assert "--rules-only" not in command and "--no-rules-only" not in command
        result = CliRunner().invoke(app, command[3:], env=env)
        return subprocess.CompletedProcess(command, result.exit_code)

    result = execute_action(
        ActionInputs("server", "high", "true", rules_only=selection),
        environment,
        command_runner=run,
    )
    assert result.effective_exit_code == (3 if selection == "false" and not fork else 1)
    assert result.upload_ready is not fork
    summary = render_step_summary(result)
    if selection != "false":
        assert result.metrics.rules_only
        assert "RULES-ONLY" in summary
        assert "degraded" not in summary.lower()
        assert result.metrics.review is None


def test_legacy_sarif_without_stages_remains_readable() -> None:
    payload = _sarif_payload()
    runs = cast(list[dict[str, Any]], payload["runs"])
    runs[0]["invocations"][0]["properties"].pop("stages")
    metrics = analyze_sarif(payload)
    assert metrics.analysis_complete
    assert metrics.rules_only is False


def test_action_consumes_repository_campaign_settings(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from typer.testing import CliRunner

    from sentinel.cli import app
    from sentinel.config import LoadedConfiguration
    from sentinel.orchestrator import ScanOutcome
    from tests.conftest import make_target
    from tests.test_baseline import _report

    workspace = tmp_path / "workspace"
    make_target(
        workspace / "server",
        scanner_toml="[sandbox]\nmax_probe_attempts=7\ncampaign_timeout_seconds=31\n",
    )
    temporary = tmp_path / "runner"
    temporary.mkdir()
    captured = []

    def scan(
        configuration: LoadedConfiguration, *args: Any, **kwargs: Any
    ) -> ScanOutcome:
        captured.append(configuration.scanner.sandbox)
        return ScanOutcome(report=_report(()), exit_code=0)

    monkeypatch.setattr("sentinel.cli.run_scan", scan)

    def command_runner(
        command: list[str], *, env: dict[str, str], check: bool
    ) -> subprocess.CompletedProcess[str]:
        result = CliRunner().invoke(app, command[3:], env=env)
        assert result.exit_code == 0, result.output
        return subprocess.CompletedProcess(command, result.exit_code)

    result = execute_action(
        ActionInputs("server", "high", "false"),
        _environment(workspace, temporary),
        command_runner=command_runner,
    )
    assert result.effective_exit_code == 0
    assert [
        (item.max_probe_attempts, item.campaign_timeout_seconds) for item in captured
    ] == [(7, 31)]
