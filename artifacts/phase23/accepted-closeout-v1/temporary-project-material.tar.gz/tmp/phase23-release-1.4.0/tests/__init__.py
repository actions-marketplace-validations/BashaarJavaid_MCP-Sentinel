"""MCP Sentinel test suite."""
