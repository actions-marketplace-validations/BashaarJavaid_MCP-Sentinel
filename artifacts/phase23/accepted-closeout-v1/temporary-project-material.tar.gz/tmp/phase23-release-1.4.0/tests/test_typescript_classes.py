"""Included class methods must retain the actual receiver and caller value."""

import time
from pathlib import Path
from typing import Any

import pytest

from sentinel.static.model import RuleRunState, TypeScriptSourceFile
from sentinel.static.path_flow import Value
from sentinel.static.rules.sent014 import TypeScriptOptionFlow
from sentinel.static.rules.sent015 import TypeScriptURLFlow
from sentinel.static.rules.sent016 import TypeScriptCredentialFlow
from sentinel.static.typescript_discovery import TypeScriptProgram, name_of
from sentinel.static.typescript_path_flow import TypeScriptPathFlow, analyze


@pytest.mark.parametrize(
    ("body", "call", "expected"),
    [
        (
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "writer.write(args.path)",
            1,
        ),
        (
            "output = ''; constructor() {} "
            "write(p) { this.output = p; return this.save(); } "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "writer.write(args.path)",
            1,
        ),
        (
            "static write(p) { return fs.writeFileSync(p, 'data'); }",
            "Writer.write(args.path)",
            1,
        ),
        (
            "private static async save({path}: {path: string}) { "
            "return fs.writeFileSync(path, 'data'); } "
            "static async write(p) { return this.save({path: p}); }",
            "Writer.write(args.path)",
            1,
        ),
        (
            "write(p) { return fs.writeFileSync('/srv/fixed', 'data'); }",
            "writer.write(args.path)",
            0,
        ),
        (
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "(writer.write = unknown, writer.write(args.path))",
            0,
        ),
        (
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "(unknown(writer), writer.write(args.path))",
            0,
        ),
        (
            "constructor(p) { this.output = p; } "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "new Writer(args.path).save()",
            1,
        ),
        (
            "constructor(private output: string) {} "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "new Writer(args.path).save()",
            1,
        ),
        (
            "constructor(public readonly output: string = '/fixed') {} "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "new Writer().save()",
            0,
        ),
        (
            "constructor(protected output: string = '/fixed') {} "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "new Writer(args.path).save()",
            1,
        ),
        (
            "constructor(p: string, private output: string = p) {} "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "new Writer(args.path).save()",
            1,
        ),
        (
            "constructor(private output: string, p = (output = '/fixed')) {} "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "new Writer(args.path).save()",
            0,
        ),
        (
            "constructor(private output: string = '/fixed') {} "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "(new Writer(args.path), new Writer().save())",
            0,
        ),
        (
            "constructor(@unknown private output: string) {} "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "new Writer(args.path).save()",
            0,
        ),
        (
            "constructor(private __proto__: any) {} "
            "save(p) { return fs.writeFileSync(p, 'data'); }",
            "new Writer({save: unknown}).save(args.path)",
            0,
        ),
        (
            "constructor(readonly output: string) { this.output = '/fixed'; } "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "new Writer(args.path).save()",
            0,
        ),
        (
            "constructor(private output: string) { unknown(this); } "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "new Writer(args.path).save()",
            0,
        ),
        (
            "constructor(private save: unknown) {} "
            "save() { return fs.writeFileSync(args.path, 'data'); }",
            "new Writer(args.path).save()",
            0,
        ),
        (
            "snapshot = this.output; constructor(private output: string) {} "
            "save() { return fs.writeFileSync(this.snapshot, 'data'); }",
            "new Writer(args.path).save()",
            0,
        ),
        (
            "set(p) { this.output = p; } "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "(writer.set(args.path), writer.save())",
            1,
        ),
        (
            "output = '/fixed'; set(p) { this.output = p; } "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "(writer.set(args.path), new Writer().save())",
            0,
        ),
        (
            "output = '/fixed'; write(p) { "
            "if (unknown()) this.output = p; return this.save(); } "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "writer.write(args.path)",
            1,
        ),
        (
            "static write(p) { return this.save(p); } "
            "static save(p) { return fs.writeFileSync(p, 'data'); }",
            "Writer.write(args.path)",
            1,
        ),
        (
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "(unknown(Writer), new Writer().write(args.path))",
            0,
        ),
        (
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "(writer['write'] = unknown, writer.write(args.path))",
            0,
        ),
        (
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "(delete writer.write, writer.write(args.path))",
            0,
        ),
        (
            "constructor() { return unknown(); } "
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "writer.write(args.path)",
            0,
        ),
        (
            "constructor() { this.onerror = error => console.error(error); } "
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "writer.write(args.path)",
            1,
        ),
        (
            "constructor() { this.onerror = () => { return 'logged'; }; } "
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "writer.write(args.path)",
            1,
        ),
        (
            "constructor() { function callback() { return 'logged'; } } "
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "writer.write(args.path)",
            1,
        ),
        (
            "constructor() { class Other { value() { return 'value'; } } } "
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "writer.write(args.path)",
            1,
        ),
        (
            "constructor() { const callback = () => { return {}; }; "
            "if (unknown()) return callback(); } "
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "writer.write(args.path)",
            0,
        ),
        (
            "constructor() { unknown(this); } "
            "write(p) { return fs.writeFileSync(p, 'data'); }",
            "writer.write(args.path)",
            0,
        ),
        (
            "output = ''; write(p) { this.output += p; return this.save(); } "
            "save() { return fs.writeFileSync(this.output, 'data'); }",
            "writer.write(args.path)",
            1,
        ),
        (
            "write(p) { const f = () => this.save(p); return f(); } "
            "save(p) { return fs.writeFileSync(p, 'data'); }",
            "writer.write(args.path)",
            1,
        ),
        (
            "write(p) { const f = function() { return this.save(p); }; return f(); } "
            "save(p) { return fs.writeFileSync(p, 'data'); }",
            "writer.write(args.path)",
            0,
        ),
        (
            "write(p) { return [p].map(p => this.save(p)); } "
            "save(p) { return fs.writeFileSync(p, 'data'); }",
            "writer.write(args.path)",
            1,
        ),
        (
            "write(p) { return [p].map(function(p) { return this.save(p); }); } "
            "save(p) { return fs.writeFileSync(p, 'data'); }",
            "writer.write(args.path)",
            0,
        ),
        (
            "constructor(p) { fs.writeFileSync(p, 'data'); } save() { return 'done'; }",
            "new Writer(args.path).save()",
            1,
        ),
    ],
)
def test_imported_class_receiver_and_replacement(
    tmp_path: Path, body: str, call: str, expected: int
) -> None:
    sources = {
        "writer.ts": 'import fs from "node:fs";\nexport class Writer { '
        + body
        + " }\n",
        "server.ts": "import {McpServer} from "
        '"@modelcontextprotocol/sdk/server/mcp.js";\n'
        'import {Writer} from "./writer";\nconst writer = new Writer();\n'
        'const mcp = new McpServer({name:"test",version:"1"});\n'
        'mcp.registerTool("write", {inputSchema:{path:z.string()}}, '
        + "args => "
        + call
        + ");\n",
    }
    files = []
    for name, source in sources.items():
        path = tmp_path / name
        path.write_text(source, encoding="utf-8")
        files.append(TypeScriptSourceFile(path, name, source))
    program = TypeScriptProgram(tuple(files), deadline=time.monotonic() + 20)
    state = RuleRunState()
    analyze(program, state)
    assert len(state.matches) == expected
    if expected:
        assert state.matches[0].path == "writer.ts"
        assert "server.ts" in state.matches[0].captures["flow_locations"]


@pytest.mark.parametrize(
    "flow_type",
    [
        TypeScriptPathFlow,
        TypeScriptOptionFlow,
        TypeScriptURLFlow,
        TypeScriptCredentialFlow,
    ],
)
@pytest.mark.parametrize(
    ("expression", "count"),
    [
        ("new Writer().write(args.value)", 1),
        ("['http:', 'https:'].includes(new Writer().write(args.value))", 1),
        ("false && new Writer().write(args.value)", 0),
        ("true || new Writer().write(args.value)", 0),
    ],
)
def test_rule_delegation_does_not_repeat_callee_or_argument_effects(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    flow_type: type[TypeScriptPathFlow],
    expression: str,
    count: int,
) -> None:
    source = (
        'import {McpServer} from "@modelcontextprotocol/sdk/server/mcp.js";\n'
        "class Writer { constructor() { observe(); } write(value) { return value; } }\n"
        'const mcp = new McpServer({name:"test",version:"1"});\n'
        'mcp.registerTool("test", {inputSchema:{value:z.string()}}, '
        f"args => {expression});\n"
    )
    path = tmp_path / "server.ts"
    path.write_text(source, encoding="utf-8")
    program = TypeScriptProgram(
        (TypeScriptSourceFile(path, "server.ts", source),),
        deadline=time.monotonic() + 20,
    )
    state = RuleRunState()
    flow = flow_type(program, state)
    observed = []
    original = flow.call

    def call(
        file: TypeScriptSourceFile, node: dict[str, Any], env: dict[str, Value]
    ) -> Value:
        if name_of(node["Call"][0]) == "observe":
            observed.append(node)
        return original(file, node, env)

    monkeypatch.setattr(flow, "call", call)
    analyze(program, state, flow=flow)
    assert len(observed) == count


@pytest.mark.parametrize("mutual", [False, True])
def test_sdk_handler_recursion_remains_unresolved(tmp_path: Path, mutual: bool) -> None:
    source = (
        'import {McpServer} from "@modelcontextprotocol/sdk/server/mcp.js";\n'
        'const server = new McpServer({name:"test",version:"1"});\n'
        + ("function second(input) { return first(input); }\n" if mutual else "")
        + "function first(input) { return "
        + ("second(input); }\n" if mutual else "first(input); }\n")
        + 'server.tool("recursive", {}, first);\n'
    )
    file = TypeScriptSourceFile(tmp_path / "server.ts", "server.ts", source)
    program = TypeScriptProgram((file,), deadline=time.monotonic() + 15)
    state = RuleRunState()
    flow = TypeScriptPathFlow(program, state)
    analyze(program, state, flow=flow)
    assert not state.matches
    assert any("recursive or unsupported handler" in w.message for w in state.warnings)
    assert not flow.active and not flow.normal_exits


@pytest.mark.parametrize("depth", [0, 63, 64])
def test_nested_sdk_callback_total_bound(tmp_path: Path, depth: int) -> None:
    from sentinel.static.typescript_discovery import TypeScriptSymbol

    source = (
        'import {McpServer} from "@modelcontextprotocol/sdk/server/mcp.js";\n'
        'import fs from "node:fs";\n'
        'const server = new McpServer({name:"test",version:"1"});\n'
        "function handler(input) {\n"
        'server.tool("nested", {}, async () => fs.readFileSync(input.path));\n'
        "}\n"
    )
    file = TypeScriptSourceFile(tmp_path / "server.ts", "server.ts", source)
    program = TypeScriptProgram((file,), deadline=time.monotonic() + 15)
    state = RuleRunState()
    flow = TypeScriptPathFlow(program, state)
    flow.initialize(TypeScriptSymbol(file, program.trees["server.ts"]))
    handler = program.resolve(file, "handler")
    assert handler is not None
    flow.callables["callback"] = handler
    original = {("registration.ts", 1, 1)}
    flow.active = original
    flow.normal_exits = [[] for _ in range(depth)]
    flow.registered(
        file, handler.node, [Value(key="tool"), Value(), Value(key="callback")], {}
    )
    assert flow.active is original and original == {("registration.ts", 1, 1)}
    assert len(flow.normal_exits) == depth
    assert len(state.matches) == (1 if depth == 0 else 0)
    assert any("nesting limit" in w.message for w in state.warnings) == (depth != 0)


@pytest.mark.parametrize("failure", ["exception", "deadline"])
def test_sdk_callback_restores_registration_stack(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, failure: str
) -> None:
    from sentinel.errors import InfrastructureError

    file = TypeScriptSourceFile(
        tmp_path / "handler.ts",
        "handler.ts",
        "export function handler(input) { return input; }",
    )
    program = TypeScriptProgram((file,), deadline=time.monotonic() + 15)
    flow = TypeScriptPathFlow(program, RuleRunState())
    handler = program.resolve(file, "handler")
    assert handler is not None
    flow.callables["callback"] = handler
    original = {("registration.ts", 1, 1)}
    flow.active = original
    invoke = flow.function

    def interrupted(*args: Any, **kwargs: Any) -> Value:
        assert flow.active == set() and flow.active is not original
        if failure == "exception":
            raise RuntimeError("synthetic callback interruption")
        program.deadline = 0
        return invoke(*args, **kwargs)

    monkeypatch.setattr(flow, "function", interrupted)
    with pytest.raises(RuntimeError if failure == "exception" else InfrastructureError):
        flow.registered(
            file, handler.node, [Value(key="tool"), Value(), Value(key="callback")], {}
        )
    assert flow.active is original and original == {("registration.ts", 1, 1)}
    assert not flow.normal_exits
