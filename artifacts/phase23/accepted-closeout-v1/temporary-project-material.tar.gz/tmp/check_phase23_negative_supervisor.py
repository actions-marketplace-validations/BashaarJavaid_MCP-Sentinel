import importlib.util,json,tempfile,sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path.cwd();path=ROOT/'artifacts/phase23/regression-rejection-review-v1/run.py'
spec=importlib.util.spec_from_file_location('negative_review',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
p=json.loads(module.PROPOSAL.read_text());manifest=json.loads((ROOT/p['manifest']['path']).read_text());item=next(x for x in manifest['inputs'] if x['id']=='minimized-vulnerable');reference=json.loads((ROOT/'artifacts/phase23/ci-review-v1/reports/minimized-vulnerable.json').read_text());report=json.loads((ROOT/'artifacts/phase23/baseline-v2/observations/03-minimized-vulnerable/report.json').read_text())
with tempfile.TemporaryDirectory(prefix='phase23-negative-synthetic-') as temporary:
 d=Path(temporary).resolve();p['output']=str(d/'output');p['disposable_checkout']=str(d/'checkout')
 def no_scanner(*args,**kwargs):return {'state':'completed','cleanup':'verified','synthetic_retained_report':True},report
 with patch.object(module,'preflight',lambda:(p,item,reference)),patch.object(module,'APPROVAL',d/'synthetic-approval.json'),patch.object(module.helper,'_observe',no_scanner),patch.object(sys,'argv',[str(path)]):
  assert module.main()==0
 result=json.loads((d/'output/results.json').read_text());assert result['status']=='regression_rejected';assert result['disposable_checkout_cleanup']=='verified';assert not (d/'checkout').exists();assert not module.APPROVAL.with_suffix('.used.json').exists()
 result['qualification']='Synthetic orchestration check with retained baseline report injected instead of _observe. No native scanner, target execution or actual negative-control observation. Actual proof remains pending explicit approval.'
 (ROOT/'artifacts/phase23/regression-rejection-review-v1/synthetic-supervision.json').write_text(json.dumps(result,indent=2)+'\n')
print('Synthetic reverse-only checkout, failed assertion and cleanup pass; zero new scans.')
