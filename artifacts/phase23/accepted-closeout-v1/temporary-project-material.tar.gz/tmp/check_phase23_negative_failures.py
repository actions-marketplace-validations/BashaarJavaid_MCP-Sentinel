import importlib.util,json,sys,tempfile
from pathlib import Path
from unittest.mock import patch
ROOT=Path.cwd();path=ROOT/'artifacts/phase23/regression-rejection-review-v1/run.py';spec=importlib.util.spec_from_file_location('negative_failures',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=json.loads(m.PROPOSAL.read_text());manifest=json.loads((ROOT/original['manifest']['path']).read_text());item=next(x for x in manifest['inputs'] if x['id']=='minimized-vulnerable');reference=json.loads((ROOT/'artifacts/phase23/ci-review-v1/reports/minimized-vulnerable.json').read_text());report=json.loads((ROOT/'artifacts/phase23/baseline-v2/observations/03-minimized-vulnerable/report.json').read_text());records=[];real_cleanup=m.helper._cleanup
for mode in ['incomplete','cleanup_failure']:
 with tempfile.TemporaryDirectory(prefix='phase23-negative-boundary-') as temporary:
  d=Path(temporary).resolve();p={**original,'output':str(d/'output'),'disposable_checkout':str(d/'checkout')}
  def fake_observe(*args,**kwargs):return ({'state':'incomplete','cleanup':'verified'},None) if mode=='incomplete' else ({'state':'completed','cleanup':'verified'},report)
  def cleanup(*args):
   real_cleanup(*args)
   if mode=='cleanup_failure':raise TimeoutError('synthetic cleanup failure')
  with patch.object(m,'preflight',lambda:(p,item,reference)),patch.object(m,'APPROVAL',d/'approval.json'),patch.object(m.helper,'_observe',fake_observe),patch.object(m.helper,'_cleanup',cleanup),patch.object(sys,'argv',[str(path)]):
   try:m.main()
   except (AssertionError,TimeoutError):pass
   else:raise AssertionError('Failed boundary counted as regression proof')
  result=json.loads((d/'output/results.json').read_text());assert result['status']=='failed';assert not (d/'checkout').exists();records.append({'mode':mode,'status':result['status'],'reason':result.get('reason'),'cleanup':result.get('disposable_checkout_cleanup')})
(ROOT/'artifacts/phase23/regression-rejection-review-v1/failure-controls.json').write_text(json.dumps({'synthetic_only':True,'scanner_calls':0,'target_executions':0,'paid_calls':0,'controls':records},indent=2)+'\n')
print('Incomplete and cleanup-failure synthetic outcomes cannot count as regression proof; zero scans.')
