# Phase 22 technical expansion

## Current v93 accepted Phase 22 closeout

**Phase 22 is technically complete under the explicitly accepted revised scope.**
The user accepted the delivered V92 technical proposal, including all historical and
practical limitations. **Proxmox remains unsupported and recovery is deferred**;
its original and exposed failures remain failed. Ordinary **FAF completion within
1,800 seconds remains unestablished**; V68 remains unapproved and unimplemented.

The accepted-closeout packet is **`v93-accepted-closeout/`**. Its immutable acceptance
receipt and **493-row audit** preserve all previous evidence: **30 explicitly accepted
limitation rows**, two existing paid/pilot deferrals and unchanged raw measurements.
The supplemental delivery-verification and final-audit receipts bind actual closeout
completion to the exact delivered revision. Technical acceptance and that verified
delivery are distinct events; the sealed audit preserves its honest pre-delivery state.

Unchanged engineering at **`5142a3f`** retains **2,596 tests / 36 skips** locally and
in all 12 hosted suites, 29 normal jobs/docs, **90.28% combined / 86.23% branch coverage**,
six zero-call production replays and 19 runtime bindings. Taskwarrior and earlier
qualified conditions retain their actual measured sources and narrow qualifications.
Current Proxmox: six completed observations / three equal ordered pairs, two missed
vulnerable reads and four unsupported negatives. No failure becomes a retroactive pass.

Git remains **312/1,040 incomplete, 728 deferred**; the 396-request paid benchmark and
pilots remain user-deferred, Phase 21 incomplete and Phase 24/15 unchanged. No new
correction, scan, profile, retry, comparator, target execution or paid call occurred.
Historical spend **$0.071799; zero new paid calls**. Accepted Phase 22 completion does
not authorize merge, ready-state change, release, outreach, launch or Phase 23.

## Historical v92 technical review: Proxmox limitation accepted, technical acceptance pending

The user explicitly approved retaining **Proxmox upload-root as unsupported** and
**deferring further recovery**. Its original and exposed failures remain failed:
at current **`5142a3f`**, six observations completed with three equal ordered pairs,
but both vulnerable reads were missed and all four fixed/safe paths were unsupported.
The exact decision is recorded in the V92 Proxmox limitation receipt. No further
correction, scan, profile, retry, comparator, target execution or paid call ran.

The complete technical acceptance packet is **`v92-technical-acceptance/`**.
All **490 requirements** retain exact evidence: **six Proxmox limitation rows are
explicitly accepted; 24 other historical/practical limitations await technical
acceptance**. Every raw failure, unresolved surface, original qualification and
closed budget remains visible. Taskwarrior and earlier qualified conditions retain
their actual measured sources; exposed follow-ups do not establish fresh accuracy.

Unchanged engineering retains **2,596 tests / 36 skips** locally and in all 12
hosted suites, 29 normal jobs/docs, **90.28% combined / 86.23% branch coverage**,
six zero-call production replays and 19 runtime bindings. The 105 unaffected V87
observations retain original source/report identities and compatibility proof.
This review adds affected documentation/package checks, not a new hosted code pass.

Ordinary **FAF completion within 1,800 seconds remains unestablished**; its six
approved uncapped observations took 2,297.758–2,735.386 seconds. The proposal explicitly
leaves V68 unapproved and unimplemented. Git stays **312/1,040 incomplete, 728 deferred**;
paid benchmark/pilots remain user-deferred, Phase 21 incomplete and Phase 24/15 unchanged.
Historical spend **$0.071799; zero new paid calls**. **Phase 22 remains incomplete**
until separate explicit human technical acceptance of the delivered complete packet
and subsequent verified accepted-closeout delivery. No merge, ready-state change,
release, outreach or Phase 23 is authorized.

## Historical v91 Proxmox regression: failed gate, disposition pending

The approved **six Proxmox observations** at engineering-tested **`5142a3f`**
completed with **all three entire ordered pairs equal**, verified cleanup and
zero remaining budget. **Both vulnerable reads were missed; all four fixed/safe
observations remain unsupported.** All six complete reports equal their failed
`884d376` references; zero findings, six metadata warnings and six unsupported
registration surfaces are fully source-assessed. Raw failures remain unchanged.

Source review identifies the conservative builtin-protection guard rejecting
`importlib.metadata` package-version imports when literal dictionary copies occur.
This is a sufficient source-visible rejection, not a runtime trace or proof that
removing it establishes downstream support. No further correction, scan, profile,
retry, comparator or paid call occurred during this continuation.

Unchanged engineering retains **2,596 tests / 36 skips** locally and in all 12
hosted suites, 29 normal jobs/docs, **90.28% combined / 86.23% branch coverage**,
six zero-call production replays and 19 runtime bindings. The 105 unaffected V87
observations retain their original source/report identities and compatibility
proof. This continuation adds assessment and affected docs/package verification,
not a new hosted code pass or speedup claim.

All **486 requirements and 30 unaccepted limitation proposals** remain. The concrete
next decision is whether to retain Proxmox as unsupported for Phase 22 or continue
focused recovery. Neither is inferred from numerical approval. Ordinary FAF
completion within 1,800 seconds remains unestablished; V68 is unapproved/unimplemented.
**Phase 22 is incomplete:** failed-gate disposition, explicit human technical
acceptance and verified accepted-closeout delivery remain. Git stays 312/1,040
incomplete, 728 deferred; paid benchmark/pilots deferred, Phase 21 incomplete,
Phase 24/15 unchanged. Historical spend **$0.071799; zero new paid calls**.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v89 literal metadata correction: engineering passed, regression approval pending

The approved V87 regression at **`884d376`** completed **111 observations / 48 equal
entire ordered pairs**, with verified cleanup and zero remaining budget. Taskwarrior,
Lightning, Engram and prior Python conditions retain their exact qualifications,
including two Meta nominal-fixed operator errata. **Proxmox still fails: two missed
vulnerable reads and four unsupported negatives.** All 3,959 findings, 343,791
diagnostic occurrences, 5,686 surfaces and complete ordered differences are assessed.
Ten Meta reports retain 268 assessed changed occurrences; original failures remain.

The authorized literal metadata correction is engineering-verified at **`5142a3f`**:
**2,596 tests / 36 skips** locally and all 12 hosted suites, **29 normal jobs and docs**,
coverage **90.28% combined / 86.23% branch-only**. Six zero-call production
requests and 19 approved runtime bindings pass. Literal dictionary copies preserve
dispatch only with proved builtin, mapping and mutation/escape boundaries. Initial
deletion and typing failures remain preserved. No current candidate corpus scan or
speedup is claimed.

The exact **six-observation Proxmox regression is unapproved and unexecuted**:
three unchanged exposed inputs, vulnerable/fixed/safe then repeat, three entire ordered
pairs. Normal **1,800-second input / 10-second Semgrep / 15-second cleanup / four-worker**
limits remain; **200 minutes plus 15 seconds outer cleanup** is a worst-case cap.
Source-only inventory proves the other 105 V87 observations cannot reach the changed
metadata code; their original `884d376` report/source bindings remain, with no new scans.

All **479 requirements** and **28 unaccepted limitation proposals** remain. Ordinary
FAF completion within 1,800 seconds is unestablished; V68 stays unapproved/unimplemented.
**Phase 22 is incomplete**, pending the remaining actual gate, updated complete review,
explicit human technical acceptance and verified accepted-closeout delivery. Git remains
312/1,040 incomplete, 728 deferred; paid benchmark/pilots deferred, Phase 21 incomplete
and Phase 24/15 unchanged. Historical spend **$0.071799; zero new paid calls**.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v86 correctness recovery: engineering passed, regression approval pending

The approved Python module-dispatch and conservative global receiver correction
is engineering-verified at **`884d376`**: **2,553 tests / 36 skips** locally and in
all 12 hosted suites, **29 normal CI jobs plus docs**, combined coverage **90.26%**,
branch-only **86.20%**. Six zero-call production requests and 19 approved
runtime component bindings pass. The failed `8f0639f` candidate, its 45-pass
interrupted local suite and cancelled CI remain preserved. Candidate `1ee96cb`
passed its 2,549/36 local suite, then failed a class-call mutation control; its CI
was cancelled. The final correction removes that unproved class-call exception. No speedup is claimed.

The exact **111-observation exposed regression is unapproved and unexecuted**:
12 Proxmox/Taskwarrior, 12 Lightning/Engram and 87 earlier Python observations,
63 input records across 10 existing repositories, 48 entire ordered pairs and
15 development singles. Normal
1,800-second input / 10-second Semgrep / 15-second cleanup / four-worker limits
remain; the 3,455-minute outer cap is a worst-case bound, not an estimate.
No new repository, retry, profile, comparator, target execution or paid call.

All **463 requirements** retain previous states and evidence; **26 limitation
proposals remain unaccepted**. Original V80 Proxmox misses and unsupported
negatives remain failed. Actual corrected-source support is pending regression.
Historical V73/V75 results remain bound to `cec0322`; ordinary FAF completion
within 1,800 seconds remains unestablished. V68 is unapproved and unimplemented.

**Phase 22 remains incomplete**, pending actual affected regression, explicit human
technical acceptance and verified accepted-closeout delivery. Git stays 312/1,040
incomplete, 728 deferred; paid benchmark/pilots deferred, Phase 21 incomplete,
Phase 24/15 unchanged. Historical spend **$0.071799; zero new paid calls**.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v81 technical review: unseen check complete, one failed gate

The separately approved V80 check completed **12 observations / six equal ordered
pairs** at **`cec0322`**, using normal 1,800s input / 10s Semgrep / 15s cleanup and
four-worker limits. **Taskwarrior passes narrow shell discrimination; Proxmox misses
the vulnerable upload read and leaves both negatives unsupported** on each pass.
Its computed module-table dispatcher remains unsupported. All four findings,
504 diagnostics, 12 surfaces, 18 contexts and 14 ordered comparisons are assessed.
The initial V78 metadata failure remains one incomplete before analysis, zero reports,
eleven unstarted closed. Both budgets are closed; zero new paid calls or target execution.

All **448 requirements** and **26 unaccepted limitation proposals** remain explicit.
Existing V73/V75 retain 205 exposed observations / 95 pairs; unchanged engineering
retains 2,450 tests / 36 skips, all 12 hosted suites, 29 normal jobs/docs, six captured
production requests and 19 runtime bindings. Normal FAF completion within 1,800s
remains unestablished; V68 is unopened. Git stays 312/1,040 incomplete, 728 deferred;
paid benchmark/pilots deferred, Phase 21 incomplete, Phase 24/15 unchanged.

**Phase 22 remains incomplete** until explicit human technical acceptance of
`artifacts/phase22/integration/v81-technical-acceptance/`, including the failed
Proxmox gate and all historical/practical limits, and verified accepted-closeout
delivery. No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v79 metadata correction: new evaluation approval pending

The approved V77 sequence stopped in V78 before scanner analysis: **one incomplete,
zero reports, eleven unstarted closed, zero remaining**, with verified cleanup.
Strict identity comparison caught three omitted optional null fields in the proposal.
The corrected proposal binds complete validated inputs; all six source identities and
36 negative controls pass. Scanner, source archives, configurations, conditions,
order and normal limits remain unchanged. The original failed attempt remains visible.

**Two repositories / six records / twelve proposed observations at `cec0322`** are
separately unapproved: Taskwarrior TypeScript and Proxmox Python. Normal input 1,800s,
Semgrep 10s, cleanup 15s, maximum four workers; outer 380 minutes plus 15s cleanup.
See `artifacts/phase22/integration/v79-unseen-metadata-correction/`.
All **440 requirements** remain; **24 proposed historical/practical limitations are
unaccepted**. Existing 205 exposed observations / 95 pairs and unchanged 2,450 tests /
36 skips retain their actual bindings. Normal FAF completion remains unestablished;
V68 remains unopened. Git 312/1,040 incomplete, 728 deferred; paid benchmark/pilots
deferred, Phase 21 incomplete, Phase 24/15 unchanged. Zero new paid calls.

**Phase 22 is incomplete** pending the requested evaluation, updated delivered review,
explicit human technical acceptance and verified accepted closeout. No merge,
ready-state change, release, outreach or Phase 23 is authorized.

## Historical v77 unseen-source preparation: exact evaluation approval pending

Two previously unused repository cases are prepared at frozen **`cec0322`**:
TypeScript Taskwarrior shell interpolation and Python Proxmox upload containment.
The exact proposal is **6 source records × 2 passes = 12 observations**, unapproved
and unexecuted, using normal **1,800-second input / 10-second Semgrep / 15-second
cleanup**, four-worker maximum, **380-minute outer limit plus 15-second cleanup**.
Source novelty, complete upstream pairs, license qualifications and synthetic
approval/stop/cleanup checks are retained in
`artifacts/phase22/integration/v77-unseen-preparation/`.

All **435 requirements (422 retained + 13 new)** remain explicit. V73/V75 retain
205 exposed observations and 95 equal entire ordered pairs; unchanged `cec0322`
engineering remains 2,450 tests / 36 skips. The 23 historical/practical limitations
remain unaccepted, including ordinary FAF completion within 1,800 seconds and
leaving V68 unopened. Git stays 312/1,040 incomplete, 728 deferred; paid benchmark
and pilots deferred, Phase 21 incomplete, Phase 24/15 unchanged. **Zero new paid calls.**

**Phase 22 remains incomplete** pending the additional unseen check, a newly
delivered complete review, explicit human technical acceptance and verified
accepted closeout. No merge, ready-state, release, outreach or Phase 23.

## Historical v76 technical review: source gates passed, human acceptance pending

At engineering-tested **`cec0322`**, the separately approved **24 four-repository
observations and 181 prior-language observations are complete**, with **all 95
entire ordered pairs equal**, verified cleanup and both budgets closed. No-bash,
Lightning, Engram and FAF pass their narrow exposed conditions; TypeScript 94
and Python 87 preserve compatibility, including caller-specific DDG CGNAT support
and two retained nominal-fixed Meta operator errata. Calculator reports add two
source-assessed findings outside the original metadata condition. Fourteen qualified
Git repository-copy findings retain physical/identity uncertainty. Raw findings,
unresolved surfaces and original fresh failures remain visible.

**Normal FAF completion within 1,800 seconds remains unestablished.** Its six
approved uncapped observations took **2,297.758–2,735.386 seconds**; the ordinary
1,800-second policy remains unchanged. The 181 language observations used normal
1,800-second input / 10-second Semgrep limits, 15-second cleanup and the existing
four-worker maximum. No speedup, isolated benchmark or broader runtime safety is
claimed. The V68 performance proposal remains unapproved and unimplemented.

Unchanged `cec0322` engineering retains **2,450 tests / 36 skips** locally and in
all 12 hosted suites, **29 normal CI jobs and docs**, combined coverage **90.11%**,
branch-only **85.97%**, six zero-call production request replays and 19 approved
runtime component bindings. This continuation adds static assessment and affected
documentation/package checks, not a new hosted code pass. All **422 requirements
(89 original + 333 added)** retain their previous states and exact evidence.
Historical failures and practical limits are proposed for explicit acceptance.

**Phase 22 remains incomplete** until explicit human technical acceptance of the
review packet and subsequent verified accepted-closeout delivery. The packet is
`artifacts/phase22/integration/v76-technical-acceptance/`; its summary, complete audit
and acceptance proposal enumerate every proposed limitation. Git stays **312/1,040
incomplete, 728 deferred**; the 396-request paid benchmark and pilots are deferred,
Phase 21 is incomplete, and Phase 24/15 are unchanged. Historical paid spend stays
**$0.071799; zero new paid calls**. No merge, ready-state change, release, outreach
or Phase 23 is authorized.

## Historical v72 correctness recovery: engineering passed, regression pending

Ordinary approved-contract recovery is verified at **`cec0322`**. Supported
TypeScript constructor parameter properties retain actual argument/default and
receiver identity; Python initial URL guard qualification survives only proved
trailing-slash/path-suffix derivation. Wrong/escaped receivers, ambiguous field
initialization, hostname fallbacks, formatting and authority changes remain
conservative, including rejection of prototype-mutating `__proto__` properties.
The first candidate `42d6c7c` failed that additional control; its local suite was
interrupted after 1,408 passes/36 skips and CI 34845266890 cancelled. Initial five
synthetic failures, subset-coverage configuration and helper-normalization failure
also remain retained with their corrections; no partial suite becomes a pass.

Local and all 12 hosted suites pass **2,450 tests / 36 skips**; all 29 normal CI
jobs and docs pass in **34846514312 / 34846514328**. Combined coverage is
**90.11%**, branch-only **85.97%**.
Exact checkout/package bindings, six unchanged zero-call production requests and
19 approved runtime component bindings pass. No speedup is established.

The new **24-observation corrected four-repository proposal is unapproved and
unexecuted**: 12 inputs twice, 12 entire ordered pairs, 18 non-FAF observations
then six FAF. It proposes the previously tested experiment-only uncapped policy,
with finite 15-second cleanup and unchanged normal **1,800-second** deadline.
All 10 complete synthetic policy comparisons and cancellation/approval boundaries
pass. **181 earlier Python/TypeScript observations remain outside this proposal.**

The completed V70 experiment at `4145d35` remains unchanged: 24/24 complete,
12/12 ordered pairs equal, FAF 2,212.22–2,341.48 seconds; no-bash/Engram narrow
passes, FAF detection/support and Lightning negative-qualification failures.
Those results do not establish current-source gates. All **407 requirements
(89 original + 318 added)**, original fresh failures and six unaccepted historical
closure proposals remain. V68 performance optimization stays unapproved and
unimplemented. No new corpus/profile/comparator/target execution or paid call.

**Phase 22 remains incomplete**, pending current-source gates, explicit human
technical acceptance and accepted closeout. Git stays 312/1,040 incomplete with
728 deferred; paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15
unchanged. No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v70 uncapped experiment: complete run, two failed gates

The user-approved **24-observation uncapped four-repository experiment** at
**`4145d35`** completed, with **all 12 entire ordered report pairs equal**,
verified cleanup and zero remaining budget. The 18 non-FAF observations took
6.28–10.72 seconds each. FAF took **2212.221735–2341.484236
seconds** per input. **6 observations exceeded the ordinary
1,800-second policy**, which remains unchanged; no speedup is established.

**No-bash and Engram pass their narrow exposed conditions**, retaining the exact
lexical/physical and initial-home/reconstructed-use qualifiers. **Lightning
fails fixed/safe qualification; FAF misses the vulnerable read and leaves both
negative paths unsupported.** All 260 findings, 52,492 diagnostic occurrences,
282 surfaces, 4,963 source contexts and full ordered reference differences are
source-assessed. The original fresh failures remain source-bound and unchanged.

The pending v68 literal-serialization optimization remains **unapproved and
unimplemented**. No source tuning, profile, retry, comparator, target execution
or paid call ran during this experiment. The earlier Python/TypeScript schedule's
**181 observations are outside this approval**; current compatibility is pending.

All **399 requirements (89 original + 310 added)** and all historical failures
remain, including the explicit v68 audit-status correction. Unchanged engineering
retains **2,419 tests / 36 skips** locally and in all 12 hosted suites, 29 normal
jobs and docs passed; combined coverage 90.08%, branch-only 85.92%. Six zero-call
production replays and approved runtime bindings remain. This is no new hosted
code pass, broad accuracy result, accepted limitation or independent validation.

**Phase 22 remains incomplete**, pending the failed current-source gates,
earlier-language compatibility, explicit human technical acceptance and accepted
closeout. Git stays 312/1,040 incomplete with 728 deferred; paid benchmark/pilots
are deferred, Phase 21 is incomplete, and Phase 24/15 are unchanged. No merge,
ready-state change, release, outreach or Phase 23 is authorized.

## Historical v68 invalidation profile: source-only decision pending

The approved FAF profile at frozen **`4145d35`** timed out after **1800.013225
seconds**, retaining **148,001 verified parent samples** and no report. Cleanup
passed after forced termination; the periodic snapshot does not confirm final
snapshot completion or timer restoration. No worker snapshot exists; worker
launch history and costs are unestablished. The one-use budget is closed.
Registration discovery is 99.86% inclusive; literal serialization is 3.85% of
parent leaf samples. These overlapping partial shares establish no speedup,
removable fraction, detection or compatibility.

`v68-invalidation-sampling/optimization-proposal.json` prepares **one unapproved,
unimplemented source-only literal serialization reuse attempt**: a bounded
per-program cache for exact strings, with fresh Values and all analysis/state
updates retained. Full identity, cold/warm/eviction, error/deadline and ordered
report equivalence plus engineering are required. No corpus/profile/retry,
resource/deadline revision, target execution or paid call is included.

An initial read-only launch preflight failed before any input/token because files
had disappeared. Verified recovery restored 25,941 tracked files, six worktree
links, 7,667 expanded evidence files and two protected user documents without
overwriting existing bytes. The cause remains unknown. User-authorized Docker
cleanup removed five unused public base images; project images, all containers
and volumes remain. Logical image storage fell 2.89GB; delayed physical recovery
is separately recorded. The same unused profile approval then ran once.

All **391 requirements (89 original + 302 added)** remain, including seven native
timeouts, six valid partial profiles, invalid stale-root preparation, both
singleton failures, the original strict invalidation failure and six unaccepted
historical closure proposals. Product retains tested `4145d35`: **2,419 tests /
36 skips** locally and all 12 hosted suites, 29 normal CI jobs and docs passed.
Combined coverage is 90.08%, branch-only 85.92%; six zero-call production replays
and approved runtime bindings remain. This continuation adds profile/recovery
assessment and docs/package checks, not another hosted code pass.

**Phase 22 remains incomplete**, pending current-source gates, explicit human
technical acceptance and accepted closeout. Git stays 312/1,040 incomplete, with
728 deferred; paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15
unchanged. No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v67 invalidation regression: timed out, budget closed

The approved 205-observation sequence at frozen **`4145d35`** stopped on its first
FAF vulnerable input after **1800.008716 seconds** whole-input time.
**One incomplete, zero reports, 204 unstarted closed, zero remaining.** Cleanup
passed within its separate 15-second allowance. Findings, detection, fixed/control
support and ordered repeats remain unknown. No retry, profile or paid call ran.

`v67-invalidation-regression/diagnostic-proposal.json` prepares **one unapproved,
unexecuted parent-and-worker sampled FAF input**, maximum 1800 seconds plus
15 seconds cleanup. It reuses the existing sampler and worker layout with actual
source identities verified before timers/target access. Synthetic identity,
completion/interruption, timer and missing-approval controls pass. The older
`1948bf9` parent profile cannot establish residual costs after the accumulator
change. No optimization, resource/deadline revision or native speedup is included.

All **383 requirements (89 original + 294 added)** remain, including seven native
timeouts, five valid partial profiles, invalid stale-root preparation, both
singleton failures, the original strict invalidation failure and six unaccepted
historical closure proposals. Product retains tested `4145d35`: **2,419 tests /
36 skips** locally and all 12 hosted suites, 29 normal CI jobs and docs passed.
Combined coverage is 90.08%, branch-only 85.92%; six zero-call production replays
and approved runtime/image bindings remain compatible. This continuation adds
outcome, preparation and docs/package checks, not another hosted code pass.

**Phase 22 remains incomplete**, pending current-source gates, explicit human
technical acceptance and accepted closeout. Git stays 312/1,040 incomplete, with
728 deferred; paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15
unchanged. No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v66 invalidation contract: engineering passed, regression approval pending

The explicitly approved private mutation-domain revision and one source-only If
accumulator attempt are verified at **`4145d35`**, source
`41dd31a167c454bd9db3d720ce75ce6287312ce0e7799bbda1b2e59c61f77ea6`. All seven shipped flow classes preserve
monotone private invalidations and independent arm baselines. The candidate reuses
the first completed arm; all guard, statement and conservative union work remains.
The source-bound guard rejects removal/export/reflection mutations. Verification
passes 256 ordinary, 766 complete production-flow and 252 production-boundary
comparisons, 125 ordered discovery comparisons and six complete serial/parallel
results. Only the two explicitly named injected scanner callbacks are outside the
prospective domain; their exact deltas and **v65 strict failure remain retained**.
No other failure is excluded; no native speedup or 1800-second completion is proved.

Local and all 12 hosted suites pass **2,419 tests / 36 skips**; all **29 normal CI
jobs** and docs pass in **34808261686 / 34808261635**. Combined coverage is
**90.08%**, branch-only **85.92%**. Six complete production requests
replay identically with zero model calls; approved runtime/image bindings remain.
Verification-helper failures and their actual corrections remain preserved.

`v66-invalidation-contract/evaluation-proposal.json` prepares **205 exposed
observations on 110 inputs / 95 ordered pairs**, **unapproved and unexecuted**:
24 four-source, 94 TypeScript and 87 Python. Bounds remain 1800 seconds per input,
15 seconds cleanup and a 6275-minute worst-case outer cap, not an estimate.
No retry/profile/comparator, new repository, target execution or paid call.

All **376 requirements (89 original + 287 added)** retain every prior failed gate,
six native timeouts, five separately bound partial profiles, invalid stale-root
preparation, both singleton failures, the strict accumulator failure and six
unaccepted historical closure proposals. **Phase 22 remains incomplete**, pending
current-source gates, explicit human technical acceptance and accepted closeout.
Git stays 312/1,040 incomplete, 728 deferred; paid benchmark/pilots deferred,
Phase 21 incomplete and Phase 24/15 unchanged. No merge, ready-state, release,
outreach or Phase 23 is authorized.

## Historical v65 invalidation attempt: strict-equivalence failure retained

The approved If invalidation-accumulator attempt passes **256 ordinary full-state
comparisons**, then fails the required synthetic captured-arm alias and shrinking-arm
controls. Error/interruption states agree. Shipped source has no matching removal or
arm-set export; real-target reachability remains unestablished. The strict proposal
still required these controls. **One failed attempt closed; exact tested `1948bf9`
source restored.** The candidate and the initial helper-deadline correction remain.

`v65-if-invalidation-accumulator/optimization-proposal.json` prepares an **unapproved
explicit mutation-domain revision and one new source-only attempt**. Every shipped
writer/reader/subclass must first prove monotone private sets with no escaping arm
alias. Only the two named injected callbacks would become negative controls outside
that prospective domain after explicit approval; their original failures stay failed.
No current reclassification, implementation, corpus/profile/retry, paid call,
resource change or timeout revision is authorized. Full engineering remains required
if a later explicitly approved attempt passes its complete prerequisites.

All **365 requirements (89 original + 276 added)** and every earlier failed gate
remain. Restored `1948bf9` retains **2,418 tests / 36 skips** locally and in all 12
hosted suites, 29 normal CI jobs and docs passed; combined coverage 90.08%,
branch-only 85.92%. Six zero-call production replays and approved runtime bindings
remain compatible. This adds failed-attempt/restoration and docs/package checks,
not a new candidate engineering or hosted code pass.

**Phase 22 remains incomplete**, pending current-source gates, explicit human
technical acceptance and accepted closeout. Git stays 312/1,040 incomplete;
paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v64 parent-and-worker profile: source-only decision pending

The approved single FAF profile at frozen **`1948bf9`** timed out after
**1800.010375 seconds**, retaining **148,764 partial samples**
from **1 verified process snapshot(s): parent**. Cleanup passed;
no report exists and the one-use budget is closed. Parent and worker denominators
are separate. Missing worker snapshots do not prove workers never launched.
Partial shares establish no native speedup, removable-cost fraction or detection.

`v64-shared-discovery-sampling/optimization-proposal.json` prepares **one unapproved
source-only attempt** to avoid redundant If invalidation-accumulator construction.
The original baseline and every per-arm copy, guard, traversal and state update remain.
Complete branch-isolation, alias/state and report equivalence plus full engineering
are required. No implementation, corpus/profile/retry, paid call,
resource change or timeout revision is included. The 1800-second policy remains.

All **358 requirements (89 original + 269 added)** and every earlier failed gate
remain. Product retains tested `1948bf9`: **2,418 tests / 36 skips** locally and in
all 12 hosted suites, 29 normal CI jobs and docs passed. Combined coverage is
90.08%, branch-only 85.92%; six zero-call replays and approved runtime bindings
remain compatible. This continuation adds profile assessment and docs/package checks.

**Phase 22 remains incomplete**, pending current-source gates, explicit human
technical acceptance and accepted closeout. Git stays 312/1,040 incomplete;
paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v63 shared-discovery regression: timed out, budget closed

The approved 205-observation sequence at frozen **`1948bf9`** stopped on its first
FAF vulnerable input after **1800.010893 seconds** whole-input time.
**One incomplete, zero reports, 204 unstarted closed, zero remaining.** Cleanup passed
in its separate 15-second allowance. Detection, findings, fixed/control support and
ordered repeats remain unknown. No retry, profile, target execution or paid call ran.

`v63-shared-discovery-regression/diagnostic-proposal.json` prepares **one unapproved,
unexecuted parent-and-worker sampled FAF input**, maximum 1800 seconds plus 15 seconds
cleanup. Completed discovery now runs in the parent before worker dispatch; old
worker-only samples cannot establish current costs. Reuse the same CPU-timer sampler
in the parent and existing workers, with actual source identities verified before
timers/target access. Six-vector, stale-root, parent completion/interruption and
missing-approval controls pass. Sampling overhead and incomplete intervals remain
explicit; no optimization, resource/deadline change or speedup claim is included.

All **352 requirements (89 original + 263 added)** remain, including six native timeouts,
four valid partial profiles, invalid stale-root preparation, both singleton failures
and six unaccepted historical closure proposals. Product retains tested `1948bf9`:
**2,418 tests/36 skips** locally and all 12 hosted suites, 29 normal CI jobs and docs passed;
combined coverage 90.08%, branch-only 85.92%. Six zero-call production replays and
approved runtime/image bindings remain compatible; this adds outcome/preparation
and final docs/package checks, not another hosted code pass.

**Phase 22 remains incomplete**, pending actual current-source gates, explicit human
technical acceptance and accepted closeout. Git stays 312/1,040 incomplete, 728 deferred;
paid benchmark/pilots deferred, Phase 21 incomplete, Phase 24/15 unchanged. No merge,
ready-state, release, outreach or Phase 23 is authorized.

## Historical v62 shared discovery: engineering passed, regression approval pending

The approved single source-only discovery-reuse attempt is engineering-verified at
**`1948bf9`**, source `8f88940210e0f382f8c1cfa1b8af3bf7464ecb891122ae23539de1e4806fc408`.
The original traversal is preserved; completed TypeScript registration discovery is
shared through the existing four-worker IPC and parent coverage. Ordered warnings,
source-node aliases, option effects and all rule-specific analyses remain intact.
Synthetic checks include 125 complete baseline comparisons, complete worker reports,
empty/failed/deadline cases and one producer with every detector still invoked.
No native speedup or 1800-second completion has been established.

Local and all 12 hosted suites pass **2,418 tests / 36 skips**; all **29 normal CI
jobs** and docs pass in **34793663094 / 34793663105**. Combined statement/branch
coverage is **90.08%**, branch-only **85.92%**. Six complete production
requests replay identically with zero paid calls; approved runtime/image bindings
remain compatible. Initial fixture/import/format check errors retain their corrections.

`v62-shared-tool-discovery/evaluation-proposal.json` prepares **205 exposed observations,
110 inputs and 95 entire ordered pairs**, **unapproved and unexecuted**: 24 four-source,
94 TypeScript and 87 Python. The shared 1800-second input limit, 15-second cleanup,
120-second informational target and 6275-minute outer cap remain unchanged. The outer
cap is a worst-case bound, not a duration estimate. No retry/profile/comparator,
new repository, target execution or paid call is included.

All **345 requirements (89 original + 256 added)** retain every earlier failed gate,
five native timeouts, four valid partial profiles, invalid stale-root preparation,
both singleton failures and six unaccepted historical closure proposals. No old budget
is reopened. **Phase 22 remains incomplete**, pending current-source gates, separate
explicit human technical acceptance and accepted closeout. Git stays **312/1,040
incomplete**, 728 deferred; paid benchmark/pilots deferred, Phase 21 incomplete and
Phase 24/15 unchanged. No merge, ready-state, release, outreach or Phase 23.

## Historical v61 thirty-minute profile: source-only decision pending

The approved FAF profile at frozen **`7bf4c6e`** timed out after
**1800.090669 seconds**, retaining **four verified worker identities
and 432,756 partial samples**. Cleanup passed; no report exists and the
one-use budget is closed. Registration discovery appears in **99.93–99.93%**
of each worker's retained samples. These overlapping partial shares do not prove
native speedup, removable-cost fraction, detection or compatibility.

`v61-faf-long-timeout-sampling/optimization-proposal.json` prepares **one unapproved
source-only attempt** to reuse completed TypeScript tool discovery across the
existing workers and coverage. Preserve ordered warnings and source-node identity;
all rule-specific analysis still executes. Full synthetic/engineering verification
is required. No implementation, corpus/profile/retry/comparator, target execution,
paid call, resource change or timeout revision is included in current approval.
The shared 1800-second policy remains in place.

All **335 requirements (89 original + 246 added)** and every earlier failed gate
remain. Product/tests retain verified `7bf4c6e`: **2,403 tests / 36 skips** locally
and in all 12 hosted suites, 29 normal CI jobs and docs passed. Combined coverage
is 89.98%, branch-only 85.86%; six zero-call replays and approved runtime bindings
remain compatible. This continuation adds profile assessment and docs/package checks.

**Phase 22 remains incomplete**, pending current-source gates, explicit human
technical acceptance and accepted closeout. Git stays 312/1,040 incomplete;
paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v60 thirty-minute regression: timed out, budget closed

The approved 205-observation sequence at frozen **`7bf4c6e`** stopped on the first
FAF vulnerable input after **1800.021672 seconds**. **One incomplete,
zero reports, 204 unstarted closed and zero remaining**; cleanup passed. Findings,
detection, fixed/control discrimination and ordered repeats remain unknown.
The approved 1800-second shared policy remains in place; extending the deadline
alone did not establish completion. No retry, profile or paid call occurred.

`v60-long-timeout-regression/diagnostic-proposal.json` prepares **one sampled FAF
input**, **unapproved and unexecuted**, with a 1800-second maximum and 15-second
cleanup allowance. Existing sampler/worker layout, synthetic identity/timer and
missing-approval checks pass. Older `a36f696` samples do not establish current costs.
No optimization, uninstrumented run, comparator or target execution is included.

All **329 requirements (89 original + 240 added)** remain, including five native
timeouts, three valid partial profiles, invalid stale-root preparation, both
singleton failures and six unaccepted historical closure proposals. Product and
tests remain verified `7bf4c6e`: **2,403 tests / 36 skips** locally and in all 12
hosted suites, 29 normal CI jobs and docs passed. Combined coverage is 89.98%,
branch-only 85.86%; six zero-call replays and approved runtime bindings remain.
This continuation adds outcome, preparation and docs/package checks.

**Phase 22 remains incomplete**, pending current-source gates, explicit human
technical acceptance and accepted closeout. Git stays 312/1,040 incomplete;
paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v59 timeout policy: engineering passed, evaluation pending

The user confirmed **30 minutes per input**. The shared static deadline is now
1,800 seconds at **`7bf4c6e`**, source `40c194dcd47a152f78c9b9dc57b40e5e77026f6052035841c0af63b83f234af6`;
120 seconds remains informational. Source proof establishes one product AST
literal change; detector logic and cleanup are unchanged from `dc73715`.
Local and all 12 hosted suites pass **2,403 tests / 36 skips**; all 29 normal jobs
and docs pass in 34784085204 / 34784085193. Six production requests replay with
zero paid calls. Actual engineering and runtime bindings are retained.

`v59-timeout-policy/evaluation-proposal.json` is **unapproved and unexecuted**:
205 exposed observations, 110 input records, 95 ordered pairs; 30-minute input
ceiling, 15-second cleanup and 6,275-minute outer cap. This is a worst-case cap,
not a duration estimate. All original conditions, support requirements and
11 volatile exclusions remain. No retry, profile, comparator, new repository,
target execution or paid call. The pending v58 diagnostic is preserved unexecuted.

All four earlier native timeouts, partial/invalid profiles, singleton failures
and original fresh failures remain source-bound and unaccepted. No speedup,
current-source compatibility or new unseen-source discrimination is established.
The audit retains **323 rows (89 original + 234 added)**, including all 314 prior
rows and six unaccepted historical closure proposals. **Phase 22 is incomplete**:
actual regression, source assessment, explicit human acceptance and closeout remain.
Git stays 312/1,040 incomplete; paid benchmark/pilots deferred, Phase 21 incomplete
and Phase 24/15 unchanged. No merge, ready-state, release, outreach or Phase 23.

## Historical v58 credential regression timeout: budget closed

The approved 205-observation sequence at frozen **`dc73715`** stopped on the first
FAF vulnerable input at **300.005621 seconds** whole-input time.
**One incomplete, zero reports, 204 unstarted closed, zero remaining**; cleanup
passed. Detection, findings, fixed/control discrimination and ordered repeats are
unknown. Current-source four-repository and prior-language gates remain unresolved.
No retry, profile, comparator, target execution or paid call occurred.

`v58-credential-regression/diagnostic-proposal.json` prepares **one sampled FAF
input**, **unapproved and unexecuted**, with a 300-second maximum and 15-second
cleanup allowance. The existing sampler and worker layout remain unchanged;
actual worker/flow/source identities are verified before timer or target access.
Synthetic identity/timer checks and the missing-approval boundary pass.
Earlier `a36f696` samples do not establish residual costs at the corrected source.
No optimization, resource/deadline change or further measurement is authorized.

All **314 requirements (89 original + 225 added)** remain. All four native
timeouts, three partial profiles, invalid stale-root preparation, both singleton
failures and six unaccepted historical closure proposals retain their actual
source bindings. Product and tests remain engineering-tested `dc73715`: **2,399
tests / 36 skips** locally and in all 12 hosted suites, all 29 normal CI jobs and
docs passed. Combined coverage is 89.98%, branch-only 85.86%; six zero-call
production replays and approved runtime/image bindings remain compatible.

**Phase 22 remains incomplete**, pending current-source gates, explicit human
technical acceptance and accepted closeout. Git stays 312/1,040 incomplete;
paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v57 joint correction: engineering passed, regression pending

The approved equal-marker credential correction and canonical unknown bypass
are verified at **`dc73715`**, source `4f3e5b2e9c89f61d179ac82db94ced06e83033f9cf1640644cefb53326e96eb9`.
Across 4,050 correction cases, 552 marker and 552 derived cache-input deltas retain
the explicitly revised join contract; guard results agree. The bypass then
passes 2,430 complete Python/TypeScript state comparisons and two saturated-cache
evictions against a preserved correction-only reference. Seven existing synthetic
HTTP patterns preserve entire ordered rule output: four detections, three negatives.
Both original singleton failures remain reproduced, closed and unaccepted.

Local and all 12 hosted suites pass **2,399 tests / 36 skips**; all 29 normal CI jobs
and docs pass in 34779741236 / 34779741226. Combined local coverage is
89.98%, branch-only 85.86%. Packages, strict quality checks, six identical zero-call
production requests and approved runtime bindings pass. Initial synthetic fixture,
import-root and test-format check failures retain their individual corrections.

`v57-credential-merge/evaluation-proposal.json` is **unapproved/unexecuted**:
205 exposed observations on 110 inputs / 95 ordered pairs, comprising 24 four-source,
94 TypeScript and 87 Python observations. 120-second target, 300-second whole/native
maximum, 15-second cleanup, 1,150-minute outer sequence; zero retries, profiles,
comparators, target execution or paid calls. No speedup or 300-second completion
is established. All old timeouts, partial/invalid profiles and fresh failures
remain source-bound; no partial subsets become new whole Linux batches.

The audit retains **308 requirements (89 original + 219 added)**, including six
unaccepted historical closure proposals and both failed singleton rows.
**Phase 22 remains incomplete**, awaiting actual regression, explicit human
technical acceptance and accepted closeout. Git stays 312/1,040 incomplete;
paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v56 canonical bypass: eviction failure retained

The approved canonical `UNKNOWN_VALUE` bypass passes the two retained ordinary
identity cases, then fails synthetic environment equivalence after LRU eviction.
Skipping an empty entry changes whether a tainted value remains interned; the
identity-only credential-marker join then returns different environments. Full
flow fields agree and inputs are unchanged. Real-target reachability/impact of
the adversarial contained-false marker remains unestablished. **One attempt
consumed, zero remaining; exact tested `a36f696` source restored.**

`v56-canonical-unknown/optimization-proposal.json` prepares an **unapproved
prospective contract revision**: equal immutable credential markers would join
consistently by identity or complete equality, followed by the canonical bypass.
The specified baseline marker delta must remain visible; bypass equivalence must
then hold against a correction-only reference with no exclusions. Neither edit
is implemented. No speedup or 300-second completion is promised. No corpus,
profile, retry, target execution or paid call is included.

All prior native/profile/fresh failures and both singleton failures remain
source-bound and closed. The audit retains **297 rows (89 original + 208 added)**,
including six unaccepted historical closure proposals. Restored `a36f696`
retains 2,386 tests / 36 skips locally and in all 12 hosted suites, 29 normal CI
jobs and docs passed; combined coverage 89.98%, branch-only 85.85%. This is no
new hosted code pass. **Phase 22 remains incomplete.** Git stays 312/1,040
incomplete; paid benchmark/pilots deferred, Phase 21 incomplete, Phase 24/15
unchanged. No merge, ready-state change, release, outreach or Phase 23.

## Historical v55 singleton attempt: equivalence failure retained

The approved broad singleton cache bypass failed its synthetic environment
equivalence prerequisite and was reverted. A warm cache interns equal Values;
direct return changes identity-sensitive credential-marker merging for a tainted
contained-false internal state. Real-target reachability of that state is not
established. Initial whole-flow comparison flags were a helper-object comparison
defect; structural reassessment preserves equal full flow state and confirms the
independent environment delta. All evidence remains visible. **One failed attempt
consumed, zero remaining; product restored exactly to tested `a36f696`.**

`v55-singleton-combine/optimization-proposal.json` prepares one **unapproved,
unimplemented** attempt restricted to the canonical `UNKNOWN_VALUE` singleton
and empty requested key. Every other input must retain cache dispatch. Complete
state and interning checks remain required; eligibility frequency and speedup
are unknown. No corpus/profile/retry, target execution or paid call is authorized.

All three native timeouts, partial profiles, invalid stale-root attempt and
original fresh failures remain source-bound. The audit retains **290 rows
(89 original + 201 added)**, including six unaccepted historical closure proposals
and the new unresolved equivalence failure. Restored `a36f696` retains 2,386 tests /
36 skips in local and all 12 hosted suites, 29 normal CI jobs and docs passed;
combined coverage 89.98%, branch-only 85.85%. This is no new hosted code pass.
**Phase 22 remains incomplete.** Git remains 312/1,040 incomplete; paid benchmark
and pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged. No merge,
ready-state change, release, outreach or Phase 23 is authorized.

## Historical v54 sampled timeout: source-only decision pending

The approved single profile at frozen **`a36f696`** retains **four verified worker
identities and 78,769 partial samples**. Whole input **300.007176 seconds**;
cleanup passed, no report exists and the one-use budget is closed. Registration
traversal dominates; merge is 33.09–33.73% inclusive and shared combine/cache call
is 7.40–7.64% leaf sample share. These overlapping partial shares establish no
native speedup, removable-cost fraction or 300-second completion.

`v54-faf-fastpath-sampling/optimization-proposal.json` proposes **one unapproved
source-only singleton fast path** before the existing value-combination cache.
Only an unchanged sole Value with no key override or required safety stripping
could bypass the tuple/cache call. All other paths, cache and complete flow state
must remain compatible, including cold/warm and identity-sensitive controls.
No implementation, corpus/profile/retry, new cache, resource/deadline change or
paid call is authorized. Eligible-case prevalence remains unmeasured.

All three native timeouts/204 closed remainders, prior partial profiles, invalid
stale-worker preparation and original fresh failures remain unchanged. The audit
retains **283 requirements (89 original + 194 added)** and six unaccepted historical
closure proposals. Product retains tested `a36f696`: 2,386 tests / 36 skips locally
and in all 12 hosted suites, 29 normal CI jobs and docs passed; combined coverage 89.98%,
branch-only 85.85%, six unchanged zero-call production requests and runtime bindings.
**Phase 22 remains incomplete.** Git stays 312/1,040 incomplete with 728 deferred;
paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v53 fast-path regression timeout: budget closed

The approved 205-observation sequence at frozen **`a36f696`** stopped on its first
FAF vulnerable input at **300.000481 seconds** whole-input time.
**One incomplete, zero reports, 204 unstarted closed, zero remaining**; cleanup
passed. Findings, guards, negative discrimination and ordered repeats are unknown.
Corrected four-source and prior-language compatibility gates remain unestablished.
No retry, profile, target execution or paid call occurred. All earlier failures
and original fresh outcomes remain preserved with their actual scanner identities.

The next **single 300-second sampled FAF input** is prepared, **unapproved and
unexecuted** in `v53-fastpath-regression/diagnostic-proposal.json`. It retains the
existing CPU-timer sampler, source/configuration and worker layout, with verified
actual worker/flow/scanner identities before timer or target snapshot access.
The stale-root synthetic control and missing-approval boundary pass. Earlier
`6e4fd67` samples cannot establish remaining costs after the current reorder.
No further optimization, retry, resource/deadline change or paid call is authorized.

All **277 requirements (89 original + 188 added)** remain, including six unaccepted
historical closure proposals and the unresolved invalid stale-worker preparation.
Product/tests/workflows remain `a36f696`: 2,386 tests / 36 skips locally and in all
12 hosted suites; 29 normal CI jobs and docs passed, combined coverage 89.98% and
branch-only 85.85%. Six zero-call production requests and runtime bindings persist.
**Phase 22 remains incomplete.** Git stays 312/1,040 incomplete with 728 deferred;
paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v52 equal-value fast path: regression approval pending

The one approved source-only merge reorder is engineering-verified at **`a36f696`**.
It checks eligible equal values actually present in every branch before preparing
record fallbacks. **10,944 synthetic comparisons** preserve environment, complete
flow state and inputs; eight intended cases skip the registry lookup and all 13
needed defaults remain. No native speedup or 300-second completion is established.
Full local and all 12 hosted suites pass **2,386 tests / 36 skips**; local combined
statement/branch coverage **89.98%**, branch-only **85.85%**. All 29 normal CI jobs
and docs pass in **34767417083 / 34767417081**, with exact checkout/package bindings.
Six unchanged production requests checked-replay with zero model calls. No new
corpus observation, profile or Git campaign ran.

The **205-observation exposed regression** is prepared, **unapproved and unexecuted**:
24 four-source + 94 TypeScript + 87 Python, 110 inputs and 95 whole ordered pairs.
Bounds: 120-second target, 300-second native/whole maximum, 15-second cleanup, one
1,150-minute serial local sequence. No retries, profiles, comparators, new repository,
target execution or paid calls. See `v52-merge-fastpath/evaluation-proposal.json`
and `launcher-binding.json`. Earlier shared recovery still lacks completed corpus
validation, so both language schedules remain necessary; they are no new whole
Linux batch. Every original label, qualifier and source-support condition remains.

Both earlier native timeouts/204 closed remainders, sampled timeouts, invalid stale
worker preparation and all original fresh failures remain preserved. The corrected
v51 partial profile does not erase the invalid attempt or establish a native pass.
All **271 requirements (89 original + 182 added)** remain; six historical closure
proposals, corrected gates and human technical acceptance are unresolved.
**Phase 22 remains incomplete.** Git stays 312/1,040 incomplete with 728 deferred;
paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

## Historical v51 bound profile: source-only decision pending

The approved corrected profile at frozen `6e4fd67` retains **four verified worker
identities and 79,307 partial samples**. Its whole input timed out at 300 seconds;
cleanup passed, no report exists, and the one-use budget is closed. Shared
TypeScript branch merge is 43.02–44.46% inclusive sample share; its missing-branch
predicate is 8.40–9.08% leaf share. These are not speedup or removable-cost claims.
The [review packet](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v51-faf-bound-sampling/summary.md) proposes **one unapproved source-only optimization**:
recognize eligible all-present equal branch values before fallback preparation.
No implementation, corpus/profile/retry, resource change or paid call is authorized.
The invalid old-root profile and V49 preparation failure remain preserved; this
passes current diagnostic attribution only. Original native/fresh failures remain.
Product retains tested `6e4fd67`: 2,384 tests / 36 skips locally and in all 12 hosted
suites, 29 normal jobs and docs passed; combined coverage 89.98%, branch-only
85.85%. All **265 requirements** remain. **Phase 22 is incomplete**; explicit
human acceptance is separate. Git stays 312/1,040 incomplete, paid benchmark and
pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged. No merge,
ready-state, release, outreach or Phase 23.


## Historical v50 profile binding failure: stopped and closed

The approved single profile was deliberately stopped when the reused sampler's
worker import root was found to be `17b4784` instead of approved `6e4fd67`.
**One invalid interrupted attempt, no report or sample snapshot, zero remaining.**
Cleanup inventory is empty. Parent identity does not prove worker identity;
V49-DIAGNOSTIC-PREPARATION is corrected to unresolved with its prior row preserved.
The [review packet](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v50-faf-allocation-sampling/summary.md) retains this agent preparation error and the diagnostic-only
correction: actual worker/flow imports and full scanner identity checked before
sampling or target snapshot access, with a stale-root rejection control.
A new **single 300-second profile is unapproved and unexecuted**; no retry,
optimization or paid call is authorized. Prior native timeouts and all four
first-frozen failures remain unchanged. Product retains tested `6e4fd67`:
2,384 tests / 36 skips locally and in all 12 hosted suites; 29 normal jobs and
docs passed, combined coverage 89.98%, branch-only 85.85%. All 259 requirements
remain. **Phase 22 is incomplete**; human acceptance is separate. Git stays
312/1,040 incomplete; paid benchmark/pilots deferred, Phase 21 incomplete and
Phase 24/15 unchanged. No merge, ready-state, release, outreach or Phase 23.


## Historical v49 allocation regression timeout: budget closed

The approved 205-observation sequence at frozen `6e4fd67` stopped on its first
FAF vulnerable input at the 300-second whole-input maximum: **one incomplete,
zero completed reports, 204 unstarted closed, zero remaining**. Cleanup passed.
No finding, guard, negative-path or ordered-repeat result is available; corrected
four-repository and prior-language compatibility gates remain unestablished.
The [review packet](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v49-allocation-regression/summary.md) retains the failure and an **unapproved single
300-second CPU-sampling diagnostic** on the same FAF input. No new retry, profile,
target execution or paid call occurred in this sequence. The v47 profile remains
bound to the earlier scanner; another optimization is not authorized. All original fresh failures and
historical source-bound passes remain unchanged. Engineering retains `6e4fd67`:
2,384 tests / 36 skips locally and in all 12 hosted suites, 29 normal CI jobs and
docs passed; combined coverage 89.98%, branch-only 85.85%. The audit retains all
253 requirements. **Phase 22 remains incomplete**; no failure/limitation or human
technical acceptance is inferred. Git stays 312/1,040 incomplete; paid benchmark
and pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged. No merge,
ready-state change, release, outreach or Phase 23.


## Historical v48 allocation candidate: regression approval pending

The approved single source-only merge optimization is engineering-verified at
**`6e4fd67`**. It avoids constructing unused record fallbacks; **10,944 synthetic
comparisons** preserve environment, complete flow state and inputs. Allocation
checks preserve needed fallbacks. Full local and all 12 hosted suites pass
**2,384 tests / 36 skips**; local combined statement/branch coverage is
**89.98%**, branch-only **85.85%**. All **29 normal CI jobs** and docs
pass in **34743452798 / 34743452818**, with exact candidate checkout/package
bindings. Six production requests checked-replay unchanged with zero model calls;
Git runtime/image remains compatible. No new corpus observation or profile ran.

The new **205-observation exposed regression** is prepared, **unapproved and
unexecuted**: 24 four-repository, 94 TypeScript and 87 Python, on 110 inputs and
95 ordered repeat pairs. Bounds are 120-second target, 300-second native/whole
maximum, 15-second cleanup and one 1,150-minute serial local sequence; no retry,
profile, comparator, new repository, target execution or paid call. Exact scope
is in `v48-merge-allocation/evaluation-proposal.json` and `launcher-binding.json`.
The earlier shared source recovery still lacks completed corpus validation, so
both prior-language schedules remain necessary. Synthetic allocation reduction
establishes no native speedup or 300-second completion. The old native timeout
and 204 unstarted closed, sampled timeout and all original fresh failures remain
unchanged. No closed budget is reused and no failed gate is waived.

The audit retains **all 247 requirements**, including 89 original and 158 added
rows. Corrected corpus gates, six historical closure decisions and explicit human
technical acceptance remain unresolved. **Phase 22 remains incomplete.** Git
campaigns stay 312/1,040 incomplete with 728 deferred; paid benchmark/pilots stay
deferred, Phase 21 incomplete and Phase 24/15 unchanged. No merge, ready-state
change, release, outreach or Phase 23 is authorized.

## Historical v47 sampled timeout: source-only proposal pending

The separately approved single FAF worker profile at frozen `17b4784` timed out
at 300 seconds with verified cleanup: **one incomplete sampled input, four partial
snapshots / 86,659 samples, no report, zero budget remaining**. The [review packet](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v47-faf-sampling/summary.md)
attributes 58.36–59.06% of worker samples inclusively to TypeScript branch merging
and 25.78–26.41% as leaves in its fallback Value constructor. These overlapping
sample shares are not promised savings; unused allocations remain uncounted.
One narrow **source-only fallback-allocation optimization** is proposed, unapproved
and unstarted, with zero new corpus/profile/paid budget. The prior regression's
one incomplete attempt and 204 closed unstarted observations remain unchanged.
Corrected detection/compatibility gates remain unresolved. Engineering retains
tested `17b4784`: 2,380 tests / 36 skips locally and in all 12 hosted suites,
29 normal CI jobs and docs passed; combined coverage 89.98%, branch-only 85.85%.
All 239 audit rows and original fresh failures remain. **Phase 22 is incomplete**;
no limitation or human technical acceptance is inferred. Git remains 312/1,040
incomplete, paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15
unchanged. No optimization, retry, paid call, target execution, merge, ready-state,
release, outreach or Phase 23 occurred or is newly authorized.


## Historical v46 regression timeout: budget closed

The approved 205-observation sequence at frozen `17b4784` stopped on its first
FAF vulnerable input at the 300-second whole-input maximum: **one incomplete,
zero completed reports, 204 unstarted closed, zero remaining**. Cleanup passed.
No finding, guard, negative-path or ordered-repeat result is available; corrected
four-repository and prior-language compatibility gates remain unestablished.
The [review packet](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v46-four-source-regression/summary.md) retains the failure and an **unapproved single
300-second CPU-sampling diagnostic** on the same FAF input. No retry, profile,
target execution or paid call has occurred. All original fresh failures and
historical source-bound passes remain unchanged. Engineering retains `17b4784`:
2,380 tests / 36 skips locally and in all 12 hosted suites, 29 normal CI jobs and
docs passed; combined coverage 89.98%, branch-only 85.85%. The audit retains all
233 requirements. **Phase 22 remains incomplete**; no failure/limitation or human
technical acceptance is inferred. Git stays 312/1,040 incomplete; paid benchmark
and pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged. No merge,
ready-state change, release, outreach or Phase 23.


## Historical v45 source recovery: verified, regression approval pending

Source recovery at `17b4784` passes **2,380 tests / 36 skips** locally and in all
12 hosted suites; all 29 normal CI jobs and docs pass. Local combined branch-enabled
coverage is 89.98% (branch-only 85.85%). Packaging, isolation and six exact zero-call
production replays are verified. The [review packet](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v45-four-source-recovery/summary.md) binds the corrected
scanner and an **unapproved 205-observation exposed/compatibility proposal**:
24 four-repository + 94 prior TypeScript + 87 prior Python observations, 110 inputs,
95 ordered pairs; 120-second target, 300-second maximum, one 1,150-minute sequence.
**No corrected-scanner corpus observation or paid call has occurred.** Original
24 first-frozen observations and all four failed fresh gates at `2e0efb2` remain
unchanged. Later passes would be exposed regression. Accurate lexical/physical and
resolved-copy qualifiers retain their source prerequisites and unresolved safety.
The audit retains all 227 requirements; no historical failure or limitation is
accepted. **Phase 22 remains incomplete** pending separate evaluation approval,
source assessment, explicit technical acceptance and verified closeout. Git stays
312/1,040 incomplete, paid benchmark/pilots deferred, Phase 21 incomplete and
Phase 24/15 unchanged. No merge, ready-state, release, outreach or Phase 23.

## Historical v44 four-repository result: failed fresh gates, recovery proposed

The approved first-frozen batch at `2e0efb2` completes **24/24 observations**;
all **12 entire ordered report pairs agree**, all within 120 seconds (maximum
51.378262 seconds; sequence 455.321356 seconds). **All four repository gates fail**:
FAF, Lightning's Python member and Engram miss their named vulnerable sinks;
no-bash detects the vulnerable overwrite but falsely alerts on both fixed/safe
inputs per pass. Quiet negatives lack established named-path support.
The [completed review packet](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v44-four-fresh-evaluation/summary.md) source-assesses all 236 findings,
46,486 diagnostics and 270 surfaces and proposes focused source-only recovery.
No correction or limitation waiver is inferred. All 24 observations are consumed,
zero budget remains, and no extra paid/target/comparator/retry/profile call occurred.
All prior source-bound results and failures remain preserved; product/test/workflow
bytes still equal tested `2e0efb2`. **Phase 22 remains incomplete**: actual failed-gate
disposition/recovery, separate explicit technical acceptance and closeout remain.
Git 312/1,040 stays incomplete, paid benchmark/pilots deferred, Phase 21 incomplete,
Phase 24/15 unchanged. No merge, ready-state, release, outreach or Phase 23.

## Historical v43 four-repository preparation: exact evaluation approval pending

Two new TypeScript repositories (FAF and no-bash) and two Python repositories
(Lightning's Python member and Engram) are source-prepared at frozen `2e0efb2`.
The [reviewable preparation packet](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v43-four-fresh-preparation/summary.md) proposes 24 native observations;
**zero have run and no evaluation approval has been received**. Actual fixed-path
support and first-frozen detection/discrimination remain unmeasured. All prior
results, failures, closed budgets and proposed historical limitations remain intact.
The v42 acceptance-readiness statement below is historical and superseded by this
new requirement. **Phase 22 remains incomplete** pending exact evaluation approval,
execution/source assessment, explicit human technical acceptance and verified closeout.
No new paid calls; Git 312/1,040 remains incomplete, paid benchmark/pilots deferred,
Phase 21 incomplete and Phase 24/15 gates unchanged. No merge, ready-state, release,
outreach or Phase 23 is authorized.

## Historical v42 regression result and pending technical acceptance

The approved **94-observation exposed TypeScript regression passes** at frozen
scanner **`2e0efb2`**, source SHA-256 **`0eac8832012e213744d752c6c33a0ba6a2e378f6230e273030f5043f00cf6ebb`**.
All **47 input records completed twice**, with all **47 entire ordered report
pairs equal** after only the established 11 volatile exclusions. There were
**94 observations within the 120-second target** and
**0 using the extended allowance**; the maximum whole input was
**106.857020 seconds**, within the uniform 300-second maximum.
The serial sequence took **3936.245 seconds**. All 94 observations
are consumed and the budget is closed, with zero remaining. No comparator, retry,
profile, new repository, target execution or paid call occurred.

**Memory-keeper passes both original three-input batches:** one vulnerable import
read hit and zero matching alerts on the fixed and safe inputs in each batch.
The source assessment establishes the canonical operator root, component-bounded
guard, checked helper return and supported actual read. Exactly **four matching
fixed/control false-alert occurrences** and their derived counters disappear.
All other ordered findings, warnings, unresolved flows, coverage and surfaces equal
their bound references. The report has no positive per-sink guard trace; recognition
is established by the code/source path, measured delta, evaluated rule and synthetic
controls. Its unnamed MCP dispatch remains unresolved. Broader export and Git-message
candidates and the upstream fixture-secret false positive remain visible.

All affected prior TypeScript conditions pass: SearXNG, fetch-mcp, open-webSearch
and Lighthouse each retain two vulnerable hits and zero matching negative alerts
per five-input batch; the precise initial-destination qualifiers remain intact.
The ten TypeScript development records pass twice (four vulnerable hits and six
valid negatives per batch), and the 14 historical TypeScript records pass twice
(six vulnerable hits and eight valid negatives per batch). These language subsets
are never pooled into a new whole historical/development execution. The whole
45+45 Linux timing/condition passes and explicitly reused whole 25 development
batch retain their actual **`1f3f72f`** evidence and Meta operator erratum.
All 87 Python regression observations at **`8c62567`** remain source-compatible.
The frozen DDG manifest's TypeScript label error remains disclosed: its actual
hash-bound execution configuration selected Python.

**The original fresh memory-keeper result remains unchanged:** at **`8c62567`**,
one vulnerable hit and two matching fixed/control false alerts per batch, six
complete observations and three equal report pairs. The repository was absent
from eight prior manifests and 100 prior effective source trees. This demonstrates
one narrow vulnerable detection on a project-unused repository before tuning;
its discrimination correction is now exposed regression. It does **not** establish
clean unseen vulnerable/fixed discrimination at the final corrected scanner.
DDG's original fresh detections and initially unsupported fixed send, Lighthouse's
original misses, and all earlier corrections/failures remain source-bound.
The original held-out baseline stays 10 completed, 10 unsupported and five
incomplete, with zero hits among four completed vulnerable inputs out of ten
vulnerable inputs total. Same-agent curation/review is not independent human
validation, training-data novelty, broad accuracy or runtime safety proof.

Product, tests, workflows, schemas and lock remain identical to engineering-tested
**`2e0efb2`**: local and all 12 hosted suites passed **2,317 tests / 36 skips**,
local branch coverage **89.92%**, all 29 normal CI jobs passed in **34712751779**,
and docs passed in **34712751789**. Those are retained source-bound passes; this
continuation adds report validation, source assessments and final docs/package
checks, not a new hosted code pass. Six zero-call production replays and the
approved Git image/runtime bindings remain compatible. **Git campaigns remain
incomplete at 312/1,040**, as requested. Paid benchmark and pilots remain deferred;
Phase 21 is incomplete and Phase 24/15 gates are unchanged.

The audit retains **all 89 original requirements: 84 passed, two user-deferred,
two proposed documented limitations and one unresolved human acceptance**.
All **115 added requirements** remain: **109 passed and six historical closure
proposals awaiting decision**. R66/R88 and V39-EVALUATION explicitly propose
accepting the preserved fresh discrimination failure plus the later verified
exposed correction. Five older failed optimization/preparation/execution attempts
also retain their individual proposed closure decisions. None is relabeled as a
historical pass or silently waived. The exact proposed acceptance scope and
consequences are in `v42-path-guard-regression/acceptance-proposal.json`.
**Phase 22 remains incomplete until explicit human technical acceptance and
subsequent closeout delivery.** No merge, ready-state change, release, outreach
or Phase 23 is authorized.


## Historical v33 fresh detection and acceptance checkpoint

The approved **replacement-v6 fresh evaluation passes its frozen output gate**
at scanner **`f85a90f`**, selected before source curation. The new repository is
**isyuricunha/mcp-ddg-research**, absent from seven prior manifests and 96 unique
source trees. Both native batches detect **2/2 correlated vulnerable variants**
and produce **zero matching alerts on three fixed/control inputs**. All **five
entire ordered repeats agree**. All **15 observations** completed: 10 native and
five pinned Semgrep; Semgrep detected **0/2** vulnerable variants. The native
maximum is **8.452 seconds**, comparator maximum **21.079 seconds**, and local
sequence **201.977 seconds**. Zero retries, target execution or paid calls; the
budget is closed. This is one repository and one narrow vulnerability, not broad
accuracy, independent human review or runtime proof.

**Fixed guard recognition is not established.** The native finding identifies the
registered `web_fetch` caller URL reaching `client.get` without sufficient destination
restriction, which includes the missing `100.64.0.0/10` rejection. Upstream also
changed fixed HTTP access to `build_request`/`send`, which Sentinel explicitly
reports as unresolved. Zero fixed alerts therefore establish the measured output
contrast, not recognition of the CGNAT fix or complete fixed-path coverage. This
limitation is prominently proposed for explicit human acceptance, never silently
accepted. All **80 findings, 3,308 warnings, 3,058 unresolved-flow occurrences and
60 recognized surface occurrences** are source-assessed. The 76 unmatched findings
include framework-validation and hashed-cache-path false positives under stated
source prerequisites; raw findings and unresolved coverage remain visible.

Current exposed Lighthouse and the three prior SSRF repeat gates remain passed.
The existing 54-observation compatibility packet and historical whole 25 + 45 + 45
Linux evidence retain their actual source bindings; no new whole-batch timing
claim is made. Product/test/package/workflow bytes equal tested **`439c3fe`**:
**2,242 tests / 36 skips**, **89.76%** local branch coverage, all **29 normal CI
jobs** and docs passed. Six production-request replays retain zero-call evidence.
Git campaigns remain **312/1,040 incomplete**, as the user instructed.

Original fresh Lighthouse misses at `1f3f72f` and original held-out failures remain
unchanged; later Lighthouse passes are exposed regressions. All earlier failed
optimizations, stale-assessment stops, invalid v4 novelty and corrective attempts
remain preserved with closed budgets. The audit contains **89 original rows:
86 passed, two user-deferred and one pending acceptance**, plus **88 added rows:
82 passed and six proposed documented limitations awaiting decision**.
**Phase 22 remains incomplete** until explicit human technical acceptance and
verified closeout delivery. Paid benchmark/pilots remain deferred; Phase 21 stays
incomplete and Phase 24/15 gates are unchanged. No merge, ready-state, release,
outreach or Phase 23 is authorized.

## Historical v32 fresh preparation checkpoint

The user requires **detection on another previously unused repository before
Phase 22 technical acceptance**. Git runtime campaigns stay incomplete at
**312/1,040** as the retained limitation; no additional Git work is planned.
The earlier v31 acceptance packet is preserved and its readiness is superseded.

Replacement-v6 prepares **isyuricunha/mcp-ddg-research** at immutable scanner
**`f85a90f`**, frozen before new source research. Novelty checks cover seven prior
manifests and **96 unique source trees**, with no matching source files. The
upstream pair changes initial rejection of `http://100.100.200.200/` in shared
address space. Complete source archives, prerequisites, two correlated helper
renames and a fixed-tree public control are retained. Source review is by the
same implementation agent after freeze; no independent human review is claimed.

`artifacts/phase22/integration/v32-fresh-v6/evaluation-proposal.json` is
**unapproved and unexecuted**: one local macOS sequence, **10 native + 5 Semgrep
observations**, 120-second target, 300-second whole-input maximum, 90-minute
sequence cap, no retries, target execution or paid calls. The prospective native
gate requires both vulnerable hits and zero matching alerts on three negatives
in each five-input batch, plus all five ordered repeats. A later repair on this
same source cannot become an unseen-source success. Existing measurements and
all original failures remain unchanged.

The audit is **84 passed, two user-deferred and three unresolved**, plus
86 added rows: **80 passed, five proposed historical limitations awaiting
decision and one unresolved**. **Phase 22 remains incomplete**. Exact evaluation
approval, actual detection/source assessment, explicit human acceptance and
verified closeout delivery remain. Paid benchmark/pilots stay deferred;
Phase 21 remains incomplete and Phase 24/15 gates are unchanged.

## Historical v31 technical acceptance checkpoint

All current Phase 22 technical gates are ready for **explicit human acceptance**.
**Phase 22 remains incomplete** until that decision and subsequent closeout delivery.

At frozen scanner **`f85a90f`**, the approved local compatibility sequence passes
**54/54 observations**: each of SearXNG, fetch-mcp and open-webSearch completes two
whole five-input batches with two correlated vulnerable hits and zero matching
condition alerts on three negatives per batch. All **15 entire ordered repeats**
agree after only the established 11 volatile exclusions. The ten development and
14 historical TypeScript inputs each complete once with unchanged ordered findings
and named-condition outcomes: **4/4** and **6/6** vulnerable hits, respectively,
and zero matching alerts on six and eight negatives. These are partial compatibility
checks, never a pooled whole-batch execution claim.

All 54 observations meet the **120-second target**, with a longest whole input of
**114.274 seconds**, within the uniform 300-second maximum. The single serial
sequence took **2,363.732 seconds**. JSON/SARIF and owned process cleanup validate.
All **3,216 changed diagnostic occurrences** are individually source-assessed:
1,080 warnings and 2,126 unresolved flows added; five warnings and five flows removed.
Unchanged findings retain their exact source-assessed references. Diagnostic removal
does not prove runtime safety; unresolved coverage and raw unmatched scorer keys remain
visible. **One sequence and all 54 observations consumed; zero budget remains.**

The separately approved Lighthouse regression passes **10/10** at the same scanner,
workflow `75142f0`, run
[34648036083](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34648036083).
Both whole batches detect two correlated vulnerable variants and preserve the narrow
IPv4 link-local qualifier on fixed/control sources; all five ordered repeats agree.
Its 10 findings, 974 warnings, 624 unresolved-flow occurrences and 20 unresolved
surfaces are source-assessed. Broader SSRF candidates remain visible.

The accepted whole **25 development + 45 historical + 45 historical** Linux gate
retains measured scanner **`1f3f72f`**. The 98-observation refresh completed all inputs:
72 within 120 seconds, 26 using extended time, maximum **176.032 seconds**.
Each whole historical batch has 20/20 vulnerable hits and zero matching alerts on
25 negatives. Whole development reuse retains ten vulnerable hits, two raw Meta
operator erratum alerts and zero matching alerts on 13 valid negatives. Source-only
AST/configuration proof establishes unchanged Python paths for 15 development and
31 historical inputs. Current TypeScript compatibility does not relabel old timing
or establish a new whole-batch Linux performance result.

Product, tests, packages and workflows still equal verified **`439c3fe`**: local
and all 12 hosted suites pass **2,242 tests / 36 skips**, local branch coverage
**89.76%**, all **29 normal jobs** and docs pass. Packaging, installed-wheel/Docker/
isolation, Ruff/format/strict mypy, lock/schema/notices/offline artifacts and six
production-request replays retain their exact source bindings. **Zero additional
paid calls.** Git runtime/image are unchanged; 13 campaigns remain incomplete at
**312/1,040** tested attempts.

The proposed acceptance explicitly retains the original fresh-source result at
`1f3f72f`: **15 completed observations, 0/2 vulnerable hits in each native batch and
comparator**. The later corrections and passes are exposed regressions, not fresh
generalization or independent human review. The original held-out result remains
ten completed, ten unsupported and five incomplete, with zero hits among four
completed vulnerable inputs out of ten vulnerable inputs total. All earlier failed
optimizations, stopped sequences and invalid v4 novelty are preserved with their
superseding evidence; no failed attempt is turned into a pass or reopened budget.

The audit contains **89 original rows: 84 passed, two user-deferred, two proposed
documented limitations and one pending human acceptance**. Its **83 added rows**
contain 78 passed and five proposed dispositions of superseded historical failures.
Those dispositions require the actual acceptance decision; no new limitation is
accepted in advance. Pilots/full paid benchmark remain deferred and nonblocking;
Phase 21 remains incomplete and Phase 24/15 gates are unchanged. No merge, ready-state,
release, outreach, participant source sharing or Phase 23 is authorized.

## Historical v30 Lighthouse regression checkpoint

The approved Lighthouse regression **passes all 10 observations** at scanner
**`f85a90f`**, workflow **`75142f0`**, run
[34648036083](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34648036083).
Both whole five-input batches detect both correlated vulnerable variants and retain
the required narrow IPv4 link-local rejection qualifier on both fixed variants and
the public control. Broader SSRF candidates remain visible. All five entire ordered
reports repeat equally after only the established 11 volatile exclusions.
Whole-input times are **11.992–14.300 seconds**, all within the 120-second target
and 300-second maximum. JSON/SARIF and owned process cleanup validate.
**Ten observations and one dispatch consumed; zero budget remains.**
All **10 findings, 974 warnings, 624 unresolved-flow occurrences and 20 unresolved
surfaces** are individually source-assessed, with zero unassessed entries.
Dispatch remains incompletely resolved; this is no runtime proof or complete coverage.

This is an **exposed regression pass**. The original independent-source evaluation
at `1f3f72f` remains 15 completed observations with **0/2 vulnerable hits per native
batch and comparator**. The stopped `6db3858` vulnerable miss and `4a2359d` fixed
qualification failure retain their closed nine- and seven-observation remainders.
No earlier failure is replaced, and no fresh generalization or independent human
review is claimed. The original held-out result remains 10 completed, 10 unsupported
and five incomplete, with zero hits among four completed vulnerable inputs out of
ten vulnerable inputs total.

Product, test, package and workflow bytes still equal verified `439c3fe`: local and
all 12 hosted suites pass **2,242 tests / 36 skips**, local branch coverage **89.76%**,
all **29 normal CI jobs** and docs pass. Packaging, installed-wheel/Docker/isolation,
Ruff/format/strict mypy, lock/schema/notices/offline artifacts and six production
request replays retain their actual source bindings. **Zero additional paid calls.**
Git runtime/image remain unchanged; 13 campaigns are incomplete, **312/1,040** tested.

The next exact proposal is **unapproved**:
`artifacts/phase22/integration/v30-compatibility-proposal/evaluation-proposal.json`.
It requests **54 serial local macOS rules-only observations** at immutable `f85a90f`:
three earlier exposed SSRF families twice each (30), followed by the 10 development
and 14 historical TypeScript inputs once (24). Bounds are 120 seconds as target,
300 seconds per whole input, 15 seconds cleanup, one 300-minute sequence, zero
retries, profiles, comparators, target executions or paid calls. Stop at the first
incomplete, late, identity/schema/cleanup, ordered-finding/condition or repeat failure;
close every unstarted observation. Every other report delta requires source assessment.
No new compatibility observation has run. Source-only AST/configuration checks bind
unchanged Python analysis for the other 15 development and 31 historical inputs.
The accepted whole 25 + 45 + 45 Linux timing/condition results retain measured scanner
`1f3f72f`; partial compatibility observations will not be called a new whole batch.

The audit contains **89 original rows: 82 passed, two user-deferred, five unresolved**,
and **81 added rows: 75 passed, six unresolved**, including closed historical failed
gates. Earlier TypeScript compatibility, the explicit disposition of fresh-result
limitations and final human technical acceptance remain open. **Phase 22 remains
incomplete.** Pilots and the full paid benchmark remain deferred; Phase 21 is
incomplete and Phase 24/15 gates are unchanged. No merge, release, outreach or Phase 23.

## Historical v29 loopback qualification checkpoint

The approved Lighthouse regression at scanner **`4a2359d`**, workflow **`b53581d`**,
run **34641101185**, detects both correlated vulnerable variants, then **fails**
the first fixed-input condition: its finding lacks the required initial link-local
rejection qualifier. All **three observations complete within 120 seconds**
(12.500–14.805 seconds whole input), with valid JSON/SARIF and verified cleanup.
**Seven unstarted observations are closed; zero budget remains.** No complete
five-input batch, control or repeat was observed. All three findings, 261 warnings,
164 unresolved-flow occurrences and six unresolved surfaces are source-assessed.

The minimal correction at **`f85a90f`** preserves the narrow IPv4 link-local fact
on a helper's IPv6 loopback equality return. It adds two shared URL-analysis lines;
broader SSRF candidates remain visible. Six synthetic checks cover loopback and
unsafe literal exceptions, compound range iteration, URL parsing and DNS branches.
All **518 affected tests pass**. Full local and all 12 hosted suites pass
**2,242 tests / 36 skips**, with **89.76%** local branch coverage and
**89.75–89.78%** hosted coverage. All **29 normal jobs** and documentation
pass at workflow **`439c3fe`**
([CI](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34642059839),
[docs](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34642059977)).
Wheel/sdist source members match actual Git blobs. Ruff/format/strict mypy,
lock/schema/notices/offline artifact checks pass. Six production requests regenerate
and checked-replay with unchanged fingerprints/request hashes and zero paid calls.
The owned Docker demo completes 20/20 attempts with 14 findings and cleanup.
Git runtime/image bindings remain unchanged; its campaigns remain incomplete.
No corpus observation has occurred at this corrected scanner.

The next exact proposal is **unapproved**:
`artifacts/phase22/integration/v29-loopback-fix/evaluation-proposal.json`,
SHA-256 `db93996f070f824b72b9bf2383e82efcde5d674c16e37d339ab7d521b7ace016`.
It retains the same five exposed sources twice: **ten native observations**, one
standard Linux job capped at **60 minutes**, 120-second target / 300-second
whole-input maximum and 15-second cleanup cap. Stop on the first execution,
condition or complete ordered-repeat failure and close the remainder. Zero retries,
profiles, comparators, target executions or paid calls. Normal CI skips this job.

The original fresh `1f3f72f` result remains 15 completed with 0/2 vulnerable hits
per native batch and comparator. The stopped `6db3858` result remains one completed
miss and nine unstarted closed. These later exposed corrections cannot establish
fresh generalization or independent human review. Earlier historical timing and
three exposed-family passes retain their actual `1f3f72f` / `2ac39aa` sources;
current-source compatibility and fresh-result disposition remain unresolved.

The **89 original rows remain 82 passed, two user-deferred and five unresolved**.
The **78 added rows are 71 passed and seven unresolved**, including five closed
historical failed gates. No stopped budget is reopened. The original held-out result
remains 10 completed, 10 unsupported and five incomplete, with zero hits among
four completed vulnerable inputs out of ten vulnerable inputs total.

**Phase 22 remains incomplete**, pending the remaining technical gates and explicit
human technical acceptance. Pilots and the full paid benchmark remain user-deferred;
Git campaigns remain incomplete (312/1,040 attempts), Phase 21 incomplete and
Phase 24/15 unchanged. Zero additional paid calls. No merge, ready-state, release,
outreach or Phase 23. The evidence labels v28/v29 do not change phase numbering.

## Historical v27 constructor-scope checkpoint

The approved exposed Lighthouse regression **fails** at scanner **`6db3858`**,
workflow **`fc3a49a`**, run **34621524649**. The first vulnerable input completes
in **9.835 seconds** whole-input time (**2.071 seconds** native) but produces zero
findings and no matching sink candidate. Its JSON/SARIF and cleanup pass.
**One observation completed; nine unstarted observations are closed; zero budget
remains.** No fixed/control or ordered-repeat result exists. All 21 warnings and
six unresolved-flow occurrences are source-assessed. No retry or paid call occurred.

The constructor-scope correction is verified at scanner **`4a2359d`**.
Constructor eligibility now excludes returns owned by nested callbacks/functions/
classes; a constructor's own returned object remains unsupported. Five synthetic
counterexamples fail at `6db3858`; all 81 class/SDK tests and 315 affected tests
pass with the correction. No current-source corpus observation has occurred.

Full local and all 12 Linux/macOS/Windows × Python 3.10–3.13 suites pass
**2,236 tests / 36 skips**. Local branch coverage is **89.76%**; hosted
coverage is **89.75–89.78%**. All **29 normal jobs** and documentation
pass at workflow **`2998b79`**
([CI](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34622991759),
[docs](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34622991696)).
Wheel/sdist sources match actual Git blobs. Ruff/format/strict mypy, lock, schemas,
notices and offline artifacts pass. Six actual production requests regenerate
and checked-replay with unchanged fingerprints/request hashes and **zero paid calls**.
The owned Docker demo completes 20/20 attempts with 14 findings and cleanup.
Git's unchanged runtime/image retains 13 incomplete campaigns, 312/1,040 attempts.
The earlier 2,230-test pass remains bound to `6db3858`.

The new exact **unapproved** proposal is
`artifacts/phase22/integration/v27-constructor-fix/evaluation-proposal.json`
(SHA-256 `3ee50c9d652f1cd4d897348a1b77ecf2efb60d78c2b56beb163b286623f6fd8b`): the same five exposed inputs twice, ten native observations,
one standard Linux job capped at 60 minutes, 120-second target / 300-second
whole-input maximum, 15-second cleanup cap, zero retries/profiles/comparators/
target execution/paid calls. Stop on the first execution, condition or ordered-repeat
failure and close the unstarted remainder. The optional workflow remains disabled
in normal CI. No corpus observation has occurred at `4a2359d`.

The **89-row audit remains 82 passed, two user-deferred and five unresolved**.
The 72 added rows are 66 passed and six unresolved, including four closed historical
failure rows. No failed measurement is relabeled as accepted or reopened.
The original held-out baseline remains10 completed,10 unsupported and5 incomplete,
with0 hits among4 completed vulnerable inputs out of10 vulnerable inputs total.

Both the original fresh `1f3f72f` miss (15 completed, 0/2 vulnerable hits per batch)
and this later failed exposed regression remain preserved. The existing fix-it
instruction authorizes the root-cause source correction and ordinary engineering;
the measurement approval does not reopen a stopped budget. Earlier timing and
three exposed-family gates retain `1f3f72f` / `2ac39aa`; current-source compatibility,
fresh-result disposition and final human technical acceptance remain unresolved.
**Phase 22 is incomplete.** Paid benchmark/pilots remain deferred, Git campaigns
incomplete (312/1,040), Phase 21 incomplete and Phase 24/15 unchanged. No merge,
ready-state, release, outreach or Phase 23 work. v26/v27 identify evidence only.

## Historical v25 Lighthouse correction checkpoint

The requested Lighthouse source correction is implemented at **`6db3858`**.
It follows actual module class construction and saved SDK setter forwarding,
recognizes Lighthouse URL sinks, and retains narrow initial link-local IPv4
rejection evidence. Replaced/escaped methods, wrong receivers, callback changes,
unknown array aliases and ineffective guards remain conservative. A qualified
finding still leaves other destinations, DNS, redirects and IPv6 unresolved.

The initial `b830027` candidate passed 2,229 tests locally and in all 12 suites,
but a later synthetic import-alias counterexample found another binding gap.
Canonical SDK identity invalidation corrects it at `6db3858`. That counterexample,
the original successful engineering results and both unexecuted proposals are
preserved; no corpus observation was consumed during this correction.

Verification passes **2,230 tests / 36 skips** locally and in all 12 hosted
Linux/macOS/Windows × Python 3.10–3.13 suites. Local branch coverage is **89.76%**;
hosted coverage is **89.75–89.78%**. All **29 normal CI jobs**
and documentation pass at workflow **`51fd2cb`**
([CI](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34615835606),
[docs](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34615835565)).
Wheel/sdist sources are byte-verified. Six actual production requests regenerate
and checked-replay with unchanged fingerprints/request hashes and **zero paid
calls**. The owned Docker demo completes 20/20 attempts with 14 findings and
cleanup; the unchanged approved Git runtime retains 13 incomplete campaigns,
312/1,040 attempts. This demo is separate from corpus evaluation.

The exact **unapproved** proposal is
`artifacts/phase22/integration/v25-lighthouse-fix/evaluation-proposal-final.json`
(SHA-256 `26ac27d01740faa0ac664a13963ef7a4d91f199818bba29d9a257d98f1f4206a`). It requests the same five exposed Lighthouse inputs twice:
**ten native observations**, one standard Linux job capped at **60 minutes**,
120-second target / 300-second whole-input maximum, 15-second cleanup cap,
**zero retries, profiles, comparator runs, target execution or paid calls**.
Stop at the first execution, named-condition or ordered-repeat failure and close
all unstarted observations. All four optional corpus jobs are disabled in normal
CI. No corrected-source corpus observation has occurred.

The first fresh result stays **0/2 vulnerable hits** per native batch and in
Semgrep at frozen **`1f3f72f`**: all 15 observations completed, all five ordered
native repeats equal, zero findings, unknown tool coverage and 232 source-assessed
diagnostics. Its budget is closed. The user chose correction rather than accepting
the limitation-only proposal. Any corrected Lighthouse result is an exposed
regression, not fresh generalization or independent human review.

The **89-row audit is 82 passed, two user-deferred and five unresolved**;
66 added rows are 61 passed and five unresolved, including three closed historical
failures. Current-source compatibility of the three earlier exposed SSRF families
and whole timing/condition gates remains to be established after the TypeScript
changes. Their passes retain measured `2ac39aa` / `1f3f72f`; no pooled or new
whole-batch claim, silent waiver or reopened budget. R66/R88 and explicit final
human technical acceptance remain open. **Phase 22 is incomplete.** Paid benchmark
and pilots remain deferred, Phase 21 incomplete, Phase 24/15 unchanged. No merge,
release, ready-state, outreach or Phase 23 work. “v25” names evidence only.

## Historical v24 replacement-v5 result and proposed disposition

The approved replacement-v5 evaluation completed **15/15 observations** in
[run 34605934302](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34605934302),
workflow **`86cbdc9`**, immutable scanner **`1f3f72f`**. All ten native observations
and five pinned Semgrep observations completed within 120 seconds; maximum whole
input was **10.437 seconds native / 22.052 seconds comparator**. All five entire
ordered native repeats match after only the established 11 volatile exclusions.
Native JSON/SARIF, input/configuration identities and owned-child cleanup pass.
The single dispatch and all 15 observations are consumed; no remaining budget,
retry, profile, paid call or target execution.

**The fresh detection result is 0/2 vulnerable hits in each native batch and
0/2 for Semgrep.** Both tools emit zero findings on all five correlated inputs.
The two fixed variants and public control also have zero matching alerts; this
silence does not establish discrimination because vulnerable inputs are silent too.
Sentinel reports no discovered MCP surfaces, an unknown total surface count,
and 19 binding warnings on each vulnerable input versus 26 on each fixed/control.
All **232 native diagnostic occurrences** are individually source-assessed.
The upstream SDK prototype patch makes the scanner's binding resolution ambiguous;
its TypeScript request-sink list also does not include Lighthouse. Neither gate
has been bypassed or changed. Completed analysis is not proof of handler coverage,
detection accuracy, safe navigation or runtime protection.

The novel repository/source pair was curated by the implementation agent after
scanner freeze, with source exposure and correlated variants disclosed. This is
one narrow link-local-before-Chrome condition, not five independent vulnerabilities,
independent human review or unseen-source evidence. Loopback remains intentionally
allowed upstream; DNS/redirects/IPv6 and actual startup/navigation are outside labels.
First frozen misses, source archives and the disqualified replacement-v4 proposal
remain preserved. No scanner tuning, case substitution or new evaluation is authorized.

The concrete limitation proposal is
`artifacts/phase22/integration/v24-fresh-v5/limitation-proposal.json`.
Its assessment, all 15 outcome rows, diagnostic source references, audit and review
summary are in the same directory. **The limitation is proposed, not accepted.**
The original 89 rows are 84 passed, two user-deferred, two proposed documented
limitations awaiting decision (R66/R88), and one unresolved human acceptance (R84).
The 60 added rows are 56 passed, three historical unresolved checkpoints with
closed scopes, and one proposed limitation disposition. Phase 22 remains incomplete;
final technical acceptance is a separate decision after the fresh disposition.

Unchanged product/workflow bytes retain CI **34578515990** and docs **34578515965**
at **`e1ab15c`**: all 29 normal jobs and all 12 suites **2,194 passed / 36 skipped**,
89.67–89.69% hosted branch coverage, and byte-verified wheel/sdist sources. This is
compatible reuse, not a new full-suite pass at the evidence-only delivery. The
whole 25 development reuse and 45 + 45 historical gates remain passed under their
actual approval, as do the three exposed SSRF families at measured `2ac39aa`.
Original held-out misses/failures, the Meta erratum and separate Kubernetes
suspicion remain visible. Git campaigns remain incomplete (312/1,040 attempts);
six production requests retain zero-call replay bindings. Paid benchmark/pilots
remain deferred, Phase 21 incomplete, Phase 24/15 unchanged. No merge, release,
ready-state, outreach or Phase 23 work is authorized. “v24” names evidence only.

## Historical v23 source-novelty checkpoint

Replacement-v4 **fails the independent-fresh-source checkpoint before execution**.
Its vulnerable 21-file extracted tree is byte-identical to the original held-out
`auth-fetch-mcp` tree. All fixed `src/` files are also identical; only package
version/dependency metadata differs. Those earlier inputs already completed
native and Semgrep evaluation on September 9. Different Git revisions and new
helper renames do not establish fresh independent sources.

The comparison and original report hashes are retained in
`artifacts/phase22/integration/v23-freshness-assessment.json`. Earlier v4
preparation/hash checks and proposals remain preserved; they did not check
novelty against the original corpus. The prepared v4 runner was delivered for
review but remains unapproved and undispatched. No new native/comparator
observations, target execution or paid calls occurred; its proposed 15-run
budget was never authorized.

R66, R88 and R84 remain unresolved; the 89 original rows remain 84 passed and
two user-deferred. Historical whole-batch timing and all three exposed SSRF
regressions retain their passing source-bound evidence. Phase 22 remains
incomplete. The user approved source-only recovery; the exact receipt is
`artifacts/phase22/integration/v23-source-only-recovery-authorization.json`.
Replacement-v5 is prepared in `artifacts/phase22/corpus-replacement-v5/`: one
Lighthouse MCP source pair outside all prior repositories and 92 effective trees,
with no matching source-file hashes. All 12 files per revision and MIT license
are retained. The narrow condition is literal link-local rejection before Chrome
launch through `run_audit`; two reversible predicate renames and a public control
are correlated variants. Upstream intentionally permits loopback; DNS/redirects,
IPv6, successful navigation and runtime exploit proof are outside these labels.
The same agent curated after scanner `1f3f72f` froze; no independent human or
unseen-source claim. The Git command-injection research candidate was rejected
because it cannot fill the unchanged SENT-015 slot. The new exact evaluation
proposal is **unapproved and unevaluated**: 10 native plus five Semgrep observations,
one standard Linux 90-minute job, 120-second target/300-second whole-input maximum,
zero retries, target executions or paid calls. No v4 or historical budget transfers.

Current preparation CI **34578515990** and docs **34578515965** pass at
**`e1ab15c`**: all **29 normal jobs**, all **12 quality suites with
2,194 passed / 36 skipped**, and three optional measurement jobs skipped.
CI checkout is synthetic merge `c044a1a`, whose complete tree equals `e1ab15c`.
Hosted branch coverage is **89.67–89.69%**; wheel/sdist source members
are byte-verified against that Git revision. The earlier `1942760` CI
retains 28 successful jobs and one cancelled final hook job; all its
12 test suites completed, but it is **not** a whole CI pass.
The new 56-row added-scope audit retains three historical failed checkpoints
with budgets closed or never approved; its other 53 rows pass. The original 89-row audit
remains 84 passed, two user-deferred and three unresolved. Zero fresh
observations or additional paid calls. Exact source-only preparation,
novelty, approval and execution-proposal bindings are retained; evaluation
and technical acceptance remain unapproved.

Final human technical acceptance has not been requested. Paid benchmark/pilots
remain deferred, Phase 21 incomplete and Phase 24/15 unchanged.


## Historical v22 historical assessment refresh

The approved **98-observation assessment refresh passes** at
scanner **`1f3f72f`**, final workflow **`61b19ae`**, run **34566835295**.
It consumed **98/98** observations; **98** completed.
**72** completed within the 120-second target and
**26** used extended time within the 300-second maximum.
The longest whole-input execution took **176.032 seconds**.
All consumed attempts and any closed remainder are retained in `v22-refresh-disposition-corrected.json`.

Both whole historical batches pass **45/45**, each with **20/20 vulnerable
condition hits** and **zero matching alerts on 25 negatives**. All 45 entire ordered
reports match across the pair, excluding only the established volatile fields.
The previously passed whole **25-input development batch** at identical scanner
bytes is reused under the user's explicit scope amendment: 10 vulnerable hits,
exactly two raw Meta operator erratum alerts, and zero matching alerts on 13 valid
negatives. These results measure completion under the approved timing policy.

The eight preparatory observations completed, and all 45 historical assessments
were frozen before the final dispatch. The retained 37 plus new eight reports
were used only for source assessment, never presented as a whole-batch execution
pass. Five preparatory report deltas include 1,191 individually source-assessed
diagnostic changes. The additional `kubectl_logs` command-injection suspicion is
separate from the unchanged `kubectl_get` benchmark condition; it remains visible,
without claiming runtime proof. Final reports have no new canonical deltas.

The original **15/25** Linux result at `7555a9d`, its ten 120-second Meta timeouts,
and the later **62-attempt stale-assessment stop** in run 34555414891 remain
preserved failures. Neither result is relabeled or its closed budget reopened.
No detector, condition label, prerequisite, deadline or target source changed.
No paid calls, profiles, benchmark retries or target execution occurred.

Final CI **34566768988** passes all **29 normal jobs** and documentation
**34566768974** passes. All 12 quality suites pass **2,194 tests with 36 skips**.
The wheel and sdist retain byte-verified source bindings. Local coverage, six
zero-call production replays and Git runtime compatibility retain their exact
source evidence. Git's 13 campaigns remain incomplete (312/1,040 attempts);
the three exposed SSRF families retain their passing regressions at `2ac39aa`.

The next separate checkpoint is **replacement-v4 freeze/evaluation**, prepared
but **unapproved and unevaluated** in `artifacts/phase22/corpus-replacement-v4/`:
10 native and five Semgrep observations, one standard Linux job, 300 seconds per
whole input, a 90-minute job limit and zero paid calls. Its independent repository
pair was curated after the immutable scanner freeze; source exposure and
correlated variants are disclosed. No independent human or unseen-source review
is claimed.

The 89-row audit is **84 passed, two user-deferred and 3 unresolved**.
**Phase 22 remains incomplete** pending actual remaining gates and explicit final
human technical acceptance. The original held-out result remains 10 completed,
10 unsupported and five incomplete, with zero hits among four completed vulnerable
inputs out of ten vulnerable inputs total. Paid benchmark and pilots remain
deferred; Phase 21 stays incomplete, and Phase 24/15 gates are unchanged.
No merge, release, outreach or Phase 23 work is authorized.

### Historical v21 sequence and proposal checkpoint

The approved full Linux sequence at scanner **`1f3f72f`**, workflow **`e7131f0`**,
run **34555414891**, **does not pass**. It consumed
**62/115 native observations**: **40** completed within
the 120-second target and **22** used extended time within the uniform
300-second native/whole-input maximum. Raw durations, cleanup, reports, condition
scores and source-assessed deltas are retained in `v21-sequence-assessment/` and
`v21-source-delta-assessment/`. The dispatch budget is closed; no retry, profile,
source tuning, target execution or paid call occurred.

Development passes **25/25**. All **37 attempted** historical inputs also complete within
300 seconds; there are **zero timeouts among 62 attempts**. The run stops on
`kubernetes-shell-vulnerable` because the old assessment expects 24 findings and
the current scanner produces 25. Source review confirms the added `kubectl_logs`
cronjob command-injection suspicion is separate from the named `kubectl_get`
condition, whose existing hit remains. Post-run source review records **19/19**
observed vulnerable condition hits and **0 matching alerts on 18 observed** negatives.
The original gate stays failed, **8 inputs** in the first historical batch remain
unstarted, and the entire 45-input repeat is skipped. All **53 unused** observations
are closed; these are not timeout failures or permission to resume.

The next exact proposal is **unapproved**:
`v21-historical-assessment-refresh-proposal.json`. It requests **98 new native
observations**, two dispatches: 8 preparatory inputs to freeze complete source-bound
assessments, then two **whole 45-input historical batches**. It explicitly asks
to reuse the already passed whole 25-input development batch at identical `1f3f72f`
bytes. The 37 + 8 preparatory reports never count as a whole 45-input execution pass. The
limits remain 300 seconds per whole input and 120 seconds as the target, with
60/245/245-minute job limits, zero retries, profiles, comparators or paid calls, and
no detector/label change. A failing or unresolved preparatory condition closes
the 90-run final budget. Strict identity and ordered-repeat checks remain in the
final pair. See the disposition for exact source evidence and timing.

This is a completion result under the approved timing policy, not a speedup.
The original Linux result at `7555a9d` remains **15/25 complete, ten Meta timeouts
at 120 seconds and both historical batches skipped**. Scanner/test/package bytes
remain `1f3f72f`. Fresh CI **34555415861** passes all **29 normal jobs**; every one
of 12 quality suites passes **2,194 tests with 36 skips**. Docs **34555415860**
passes. Prior local coverage, six zero-call production replays and Git runtime
compatibility retain their exact source bindings. Git campaigns remain incomplete;
all three exposed SSRF families retain their passing regressions at `2ac39aa`.

A later separate checkpoint is the **unapproved replacement-v4 freeze/evaluation** in
`artifacts/phase22/corpus-replacement-v4/`. Its independent auth-fetch-mcp source
pair was curated after the scanner freeze, without running a detector/comparator.
The proposal permits **10 native and 5 Semgrep observations** in one standard
Linux job, 300 seconds per whole input, 75 nominal input-minutes, a 90-minute job
limit and zero paid calls. Source exposure and correlated variants are disclosed;
there is no independent human or unseen-source review claim.

All 89 original requirements are **72 passed, 2 user-deferred,
15 unresolved**. **Phase 22 remains incomplete** pending the
remaining gates and explicit final human acceptance. The original held-out result
remains 10 completed, 10 unsupported, 5 incomplete, with 0 hits among 4 completed
vulnerable inputs out of 10 vulnerable inputs total. Paid benchmark/pilots remain
deferred; Phase 21 incomplete and Phase 24/15 unchanged. No merge/release/outreach.

### Historical v20 diagnostic and full-sequence proposal checkpoint

The approved Linux diagnostic **passes all four observations** at scanner
`1f3f72f`, workflow `71906a7`, run **34550284556**. Both named Meta inputs complete
twice, with valid native JSON/SARIF and **entire ordered reference/repeat equality**.
Whole-input times range from **137.833 to 144.225 seconds**;
**0/4** meet the 120-second target and **4/4** use the extended allowance.
All are within the approved 300-second maximum. Each owned process group is
reaped. Four observations and the single dispatch are consumed; no retries,
profiles, tuning, target execution or paid calls occurred. The raw fixed-label
Meta operator alert and approved source erratum remain unchanged.

Only the optional diagnostic workflow changed. Scanner/test/package bytes equal
`1f3f72f`; the prior local **2,194 passed / 36 skipped**, **89.68%** branch coverage
and six zero-call production replays remain valid source-bound evidence.
Fresh CI **34550284081** passes all **29 normal jobs**, with **2,194 passed /
36 skipped** in every one of 12 suites; docs **34550284214** passes. The unchanged
Git image/runtime evidence still describes 13 incomplete campaigns: 1,040 planned,
312 tested and 728 remaining; this is not complete Git coverage. All three
exposed SSRF families retain their passing source-bound
regressions at `2ac39aa`; they are not fresh generalization results. The original
held-out baseline remains 10 completed, 10 unsupported and 5 incomplete, with zero
hits among 4 completed vulnerable inputs out of 10 vulnerable inputs total.

This is a two-input diagnostic, **not a full corpus timing pass or a speedup**.
The original Linux gate at `7555a9d` remains **15/25 complete, ten Meta timeouts at 120 seconds,
both historical batches skipped**. The prospective policy remains a 120-second
target and uniform 300-second maximum. No earlier result is relabeled.

The next exact proposal is `v20-full-linux-sequence-proposal.json`, **unapproved**:
one 25-input development batch then two 45-input historical batches,
**115 native observations**, one
dispatch across three dependent standard Linux jobs with **145/245/245-minute**
limits (635 minutes total maximum), no retries/profiles/paid calls. The next job
starts only after its predecessor's completion and condition gate passes. Stop
on the first incomplete, late or mismatching result; do not pool attempts.
The existing condition requirements and ordered historical repeat gate remain.

All 89 requirements remain **70 passed, 2 user-deferred, 17 unresolved**.
**Phase 22 remains incomplete.** Full timing, fresh freeze/evaluation and final
human acceptance remain separate checkpoints. Paid benchmark/pilots remain
deferred; Phase 21 incomplete and Phase 24/15 unchanged. No merge/release/outreach.

### Historical v19 timeout policy and unapproved diagnostic checkpoint

The approved **120-second performance target / 300-second static maximum** is
implemented and verified at `1f3f72f`. The same deadline applies to every input;
fast scans return immediately. The TypeScript parser and source-flow workers use
the remaining shared budget, shorter caller deadlines are honored, and coverage/
report assembly checks expiry. No detector rules or model/dynamic budgets change.

Local full verification passes **2,194 tests / 36 skipped**, with **89.68%**
branch coverage. Fresh CI **34545976337** passes all **29 normal jobs**; each of
12 suites passes **2,194 / 36**. Docs **34545976336** and the final local docs build
pass. Six production requests regenerate/replay with **zero paid calls**; Git
runtime components/image remain compatible with the retained incomplete campaigns.
Initial failing deadline regressions, lint/type-check corrections and all earlier
failures are preserved. The scanner bytes now differ from `592a9cd` and `2ac39aa`;
prior exposed detections remain source-bound regressions with deadline-only
compatibility explained in `v19-source-verification.json`.

**No new corpus timing run has occurred.** The original Linux result remains
15/25 development complete, ten Meta timeouts at 120 seconds and both historical
batches skipped. The user approved revising the prospective hard timing criterion
to 300 seconds; completion within the original 120-second target must still be
reported separately. This is no speedup or completed timing-gate claim.

`v19-linux-timeout-diagnostic-proposal.json` is prepared and **unapproved**:
two named slow Meta inputs twice each, four native observations, 300 seconds each,
one 30-minute standard Linux job, no profiles/retries/paid calls. Stop at the first
incomplete or mismatching result. Full 25+45+45 verification, fresh evaluation and
human acceptance remain separate checkpoints. **Phase 22 remains incomplete.**
Paid benchmark/pilots remain deferred; Phase 21 incomplete and Phase 24/15 unchanged.

[Timing policy](phase22-timeout-policy.md)

## Historical v18 throughput probe at `0b71a29`

The approved Stage 0 synthetic throughput probe is complete at `0b71a29`.
Run **34536965288** completed **12/12 observations** in an 88-second job;
all checksums match, all children were ready before the shared monotonic start,
and every child was reaped. No scanner or corpus input executed in the probe.

Median throughput relative to one process is **2.029× at three processes,
2.136× at four, and 2.125× at six**. Four processes add only **5.25%** over
three; six add **4.71%**. The runner reports four vCPUs, two cores and two
threads per core, with Python 3.12.14. The prospective **E3 ≥ 2.7 premise
fails**. This result does not support proceeding to the proposed partitioning
experiment; it is not proof that all scanner parallelism is ineffective.
See `v18-scaling-assessment.json` and its retained raw observations.

**One dispatch consumed; zero scanner runs, optimization attempts or paid model
calls.** Stage 1 and partitioning remain unapproved. The normal CI jobs are
structurally unchanged, but the optional workflow changed, ending workflow
equality to `592a9cd`. Fresh CI **34536886816** verifies all 29 normal jobs;
all 12 suites pass **2,183 tests / 36 skipped**. Docs **34536886750** pass.
Scanner/test/package bytes remain identical to `592a9cd`; prior local checks,
production replay and Git compatibility retain their executed sources, and the
three exposed SSRF gates retain measured `2ac39aa`. Initial probe lint issues
and an immediate post-push PR-readback assertion are preserved with corrections.

**Phase 22 remains incomplete.** The retained Linux scanner result is still
15/25 development complete, ten Meta timeouts and both historical batches
skipped. No current-source full timing pass, fresh evaluation, scope waiver or
final human acceptance is inferred. Further source-design work may investigate
reducing repeated analysis, but no safe reuse design or new experiment is
established here. Pilots/full paid benchmark remain deferred, Phase 21 incomplete,
and Phase 24/15 unchanged. No merge, release, outreach or next phase.

## Historical v17 diagnostic at `127763c`

The approved whole-worker sampling scope is complete at `127763c`:
**one Meta operator input**, **69.906s native / 71.578s outer**, 49 findings,
full ordered baseline equivalence after established volatile exclusions and valid
native JSON/SARIF. Four final snapshots restore timer/signal state. The sampler
changes no scanner methods and records no locals or target values.

Active workers retain 4,220 / 5,093 / 4,903 samples (SENT-012/015/016).
Shared merge inclusive shares are 24.81% / 19.18% / 22.58%; expression leaf
shares are 11.66% / 15.92% / 14.28%, mostly at function entry. Caller shares
overlap, signal delivery biases attribution, and no share is wholly removable
cost. **No safe larger optimization or native speedup is established.** See
`v17-sampling-assessment.json` and the source review in `v17-timing-disposition.json`.

The one-profile budget is closed: **zero optimization attempts, additional native
observations, comparator runs, full retries or paid calls**. No scanner/test code
changed. Existing local and 12 hosted suites retain 2,183 passed / 36 skipped,
29 normal jobs and docs, replay and Git compatibility at actual `592a9cd`.
All three exposed SSRF gates remain source-compatible at measured `2ac39aa`.
The read-only cleanup check initially encountered sandbox Docker permission;
the authorized recheck passed and both records are retained.

**Phase 22 remains incomplete.** The Linux result remains 15/25 development
complete, ten Meta timeouts and both historical batches skipped. Retain the
timing gate; no scope revision, fresh evaluation or final acceptance is inferred.
Further performance experiments need a justified bounded proposal and approval;
this profile does not justify another speculative micro-optimization. Any timing
scope revision needs an explicit user decision and would still require fresh
evaluation and final human acceptance. Pilots/full paid benchmark remain deferred,
Phase 21 incomplete, and Phase 24/15 unchanged. No merge, release or next phase.

## Historical v16 diagnostic at `46b8786`

The user approved `v15-next-combine-proposal.json`; the exact receipt is
`v16-combine-authorization.json`. Its one Meta operator diagnostic completed in
**81.271s** (**82.947s** including measurement setup/finalization). The full
ordered report matches the retained native baseline after established volatile
exclusions. Native JSON/SARIF validate, all four workers have final snapshots,
and 24 synthetic comparisons preserve all Value fields, keys and cache behavior.

The prospective predicate **fails in all three active workers**. Eligible generic
combinations are frequent (83.72%, 85.54%, 84.47%), but their body CPU shares are
only **7.81% SENT-012, 5.34% SENT-015 and 6.81% SENT-016**, below the required
**10% in each worker**. Timing excludes classification counters but includes field
reductions/helpers and construction; it is instrumented attribution, not wholly
removable cost or a native gain. See `v16-combine-assessment.json`.

The stopping condition was enforced before optimization. **One profile used,
zero optimization attempts, zero native performance observations and zero exposed
regression observations.** All 12 performance and 30 conditional SSRF observations
are cancelled; no unused maximum remains open. No scanner/test code changed and
no reversion was needed. Zero paid calls.

Source/test/workflow/package inputs at diagnostic `46b8786` equal verified
`592a9cd`. The existing local and 12 hosted suites each retain 2,183 passed and
36 skipped; 29 normal jobs and docs, production replay and Git compatibility
retain their actual executed sources. No new full suite or hosted pass is claimed.
All three exposed SSRF gates remain source-compatible at measured `2ac39aa`.

The next `v16-next-worker-sampling-proposal.json` is **unapproved**: one
120-second CPU sampling profile of the same Meta operator input, at most 100Hz
per worker, zero optimizations or additional native/comparator observations and
zero paid calls. It seeks a larger whole-worker CPU concentration before another
code proposal. No further measurement, full Linux retry or fresh evaluation is
inferred. Timing/fresh evaluation/final acceptance remain unmet; Phase 22 remains
incomplete. Pilots/full paid benchmark stay deferred, Phase 21 incomplete and
Phase 24/15 unchanged. No merge, release, outreach or next phase.

## Historical v15 diagnostic at `77ea21f`

The user's “okay go ahead” approved the single merge diagnostic in
`v14-next-merge-diagnostic-proposal.json`; `v15-merge-authorization.json` records
that decision. The sole Meta operator profile completed in **88.533s**
(**90.084s** including measurement setup/finalization), below 120 seconds.
All four workers have final snapshots. Its full ordered report matches the
retained native baseline after only established volatile exclusions; native JSON
and SARIF validate. The revised synthetic control passes 24 state comparisons.
The initial control-coverage assertion and documentation-binding check failures
are preserved with their corrections. No scanner code changed or optimization
was attempted. The one-profile budget is closed; zero paid calls.

Shared multi-branch value processing accounts for **17.8–21.3 instrumented
CPU-seconds** per active worker. About **85% of 19.01 million key visits** reuse
existing values. Those counts do not imply that reuse consumes 85% of the time:
the block also includes nested combining, lookups, equality and instrumentation.
URL pre-processing adds 3.79 CPU-seconds. Timings overlap where explicitly marked
and include instrumentation overhead; this is not a native performance gain.
See `v15-merge-assessment.json` and `v15-combine-source-review.json`.

Code/test/workflow/package inputs at measured `77ea21f` equal verified `592a9cd`.
The existing local and 12 hosted suites each retain 2,183 passed/36 skipped,
29 normal jobs and docs passed, production replay and Git compatibility, all at
their actual executed source. No repeated full suite or new hosted pass is
claimed. All three exposed SSRF gates remain source-compatible at `2ac39aa`.

The next `v15-next-combine-proposal.json` is **unapproved**: one counter profile,
one conditional shortcut using the existing two-value combination, up to
12 native performance observations and 30 conditional exposed regressions,
120 seconds each, zero paid calls. Its diagnostic threshold must pass before
any optimization; unused maxima close on failure. No new measurement is inferred.
Full Linux timing, fresh evaluation and final human acceptance remain unmet.
Phase 22 remains incomplete; pilots/full paid benchmark stay deferred, Phase 21
incomplete and Phase 24/15 unchanged. No merge, release, outreach or next phase.

## Historical v14 verification at `592a9cd`

Phase 22 remains incomplete. The user's “go ahead” approved the exact helper-fact
proposal in `v13-next-performance-proposal.json`; the new receipt is
`v14-performance-authorization.json`. Its one counter profile completed and
observed 3,402,980 empty-fact visits among 3,422,804 binding visits (99.42%).
One ordered-pass optimization was attempted at `e57ce95` and reverted in
`a7d7de0`. Scanner bytes again equal measured `2ac39aa` and delivered `424c443`.
The new semantic regression is retained; no detector behavior change remains.

The first operator candidate took 77.556s and 195.041848 child CPU-seconds,
exceeding baseline maxima of 75.134s and 188.048785 CPU-seconds. That irrecoverably
fails the prospectively approved per-observation retention rule. Four candidate
attempts had started when the queue was stopped: three completed, and the active
Atlassian repeat ended without a completion record. It is retained as interrupted,
not completed or timed out. Two remaining performance observations were cancelled;
the 30 conditional SSRF observations were never activated. Total usage is one
completed counter profile and ten native attempts (nine complete, one interrupted).
All ten completed ordered reports, including the profile, match their baselines.
No complete candidate pair or median performance gain is claimed. The failed
lint/format checks, queue termination, partial files and all original evidence
remain preserved. See `v14-performance-disposition.json` and
`v14-queue-stop-outcome.json` under integration evidence.

All three exposed SSRF families retain their passing v13 gates at `2ac39aa`:
five inputs twice per family, two vulnerable matches and zero matching negative
alerts per batch. Current scanner/harness bytes are identical; these results keep
their original measured revision. SearXNG's broader URL candidates and unresolved
MCP dispatch remain visible. Original misses and source assessments are preserved.

Final local and all 12 hosted quality suites pass **2,183 tests, 36 skips and
no expected failures** at corrected `592a9cd`. Local branch coverage is
**89.66%**; hosted coverage is **89.65–89.68%**. All 29 normal jobs and
docs pass ([CI](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34518818910),
[docs](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34518818938)).
Wheel/sdist source members match actual Git blobs; all 12 wheel combinations,
Docker replay, network isolation, dependencies and hooks pass. Configured strict
mypy checks all 146 files; Ruff/format, lock, schemas, notices and offline
artifacts pass. Both approved production requests regenerate and checked-replay
without new paid calls. The approved Git runtime/image bindings match; its
13 campaigns remain incomplete (312 tested, 728 remaining).

The candidate's 1,034 affected tests and semantic before/after control passed.
Initial `12748e4` CI failed all 12 quality jobs because its source-only local mypy
check missed a required test-helper annotation. The annotation is corrected;
initial failed/cancelled CI and the superseded local suite interrupted after
365 passing tests are retained. Detector source and measurements are unchanged.
The current 89-row audit records 70 passed, two explicitly user-deferred and
17 unresolved, with current test/evidence bindings. Seven additional v14 scope
requirements are mapped separately: six passed and the performance-retention
requirement remains unresolved.

The retained full Linux gate still fails at `7555a9d`: 15/25 complete, ten Meta
timeouts and both historical batches skipped. No further optimization, profile,
native/comparator measurement, full Linux retry, runner/deadline waiver or fresh
freeze/evaluation is authorized by unused maxima. The prepared `v14-next-merge-diagnostic-proposal.json` requests only one
120-second merge diagnostic on the named Meta input, with no optimization or
additional native/comparator run; it is unapproved. A new measurement scope
requires separate approval. Timing, fresh evaluation and final human
acceptance remain unmet; final acceptance is not requested. Zero paid calls.
Pilots and the paid benchmark remain deferred; Phase 21 is incomplete and
Phase 24/15 are unchanged. No merge, release, outreach or next phase.

## Historical v13 continuation at `2ac39aa`

Phase 22 remains incomplete. At scanner `2ac39aa` (source bytes equal the
SearXNG correction `523320f`), all three exposed SSRF families pass their native
repeat gates. Each family completes five inputs twice, detects both correlated
vulnerable variants and has zero condition-matched fixed/control alerts.
SearXNG takes at most 12.821s per input, fetch-mcp 5.104s and open-webSearch
65.265s. Complete ordered repeats agree except recorded volatile fields;
JSON/SARIF and source assessments pass.

The shared correction keeps TypeScript receiver invalidation local to mutually
exclusive `if` arms, then conservatively unions possible invalidations at the
join. An HTTP-arm unknown `process` effect no longer contaminates ordinary
stdio startup. No callback or unknown function is exempted. SearXNG's fixed
sources now retain the native default-loopback qualification; their broader
URL candidates and unresolved MCP dispatch remain visible. Its 23 unmatched
scorer keys per batch (20 prior HTTP candidates and three qualified negative-source
URL candidates) are all separately source-assessed. Original frozen native and
comparator 0/2 results remain unchanged; these are exposed regressions, not fresh
generalization or runtime proof.

The separately approved immutable-Value experiment used one optimization attempt,
two counter profiles and all 12 native observations. Ordered native reports all
match, but Meta operator median wall time increased 4.58% and child CPU 1.31%.
Atlassian improved 16.70% in median wall time; Meta image improved 5.35% in wall
but only 1.64% in CPU. These mixed results fail the retention rule. The
optimization at `de2a02f` is reverted in `2ac39aa`; the test, original commit,
profiles, deadline failures and all results are retained. No full Linux retry
occurred. The retained `7555a9d` Linux result still completes 15/25, with ten Meta
timeouts and both historical batches skipped.

Final-source local and all 12 hosted quality suites pass **2,182 tests, 36 skips
and no expected failures**. Local branch coverage is **89.66%**; hosted coverage
is **89.65–89.68%**. All 29 normal jobs and docs pass at `1be0650`, whose
code/test/workflow/package inputs equal measured `2ac39aa`
([CI](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34509664451),
[docs](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34509664440)). Actual
wheel/sdist source members match Git. Ruff/format, strict mypy, lock, schemas,
notices, offline artifacts, dependencies, wheel smoke, Docker replay, isolation
and hook checks pass. Both approved production requests regenerate and replay
without new paid calls. The exact approved Git image/runtime bindings match;
its 13 campaigns remain incomplete (312 tested, 728 remaining).
See integration `v13-searxng-assessment/packet.json`,
`v13-exposed-assessment/packet.json`, `v13-performance-disposition.json` and
`v13-performance-revert-receipt.json`. The current SearXNG receipt consumes
31 of its maximum 32 executions: one fixed trace and 30 final observations;
the optional vulnerable trace was not needed. Both approved scopes have reached
their stopping conditions. The separate `v13-next-performance-proposal.json`
is prepared but unapproved; it does not reopen either budget.

Timing, a post-stabilization fresh freeze/evaluation and final human acceptance
remain unmet/separately gated. No final acceptance is requested. There were zero
new paid calls. Pilots and the full paid benchmark remain user-deferred; Phase 21
is incomplete and Phase 24/15 gates are unchanged. No merge, release, outreach or
next phase is authorized.

## Historical v12 follow-up at `6eb482c`

Phase 22 remains incomplete. The user's “go ahead” approved both v10 proposals;
`v11-follow-up-authorization.json` preserves their exact hashes and bounds.
One helper-context counter profile found no safely reusable result. No
optimization, native timing comparison or further full Linux retry occurred;
the retained timing failure remains authoritative.

Shared TypeScript factory/else discovery and narrow loopback/default guard
facts are implemented. The canonical finding/review contract is unchanged.
All 18 focused guard controls pass, but the full SearXNG correction gate fails:
both native batches complete 5/5 and detect 2/2 vulnerable variants, while both
fixed variants retain an unqualified SSRF alert. The public-IPv4 control also
retains a broad candidate, separately assessed outside its exact public-input
condition. That distinction does not waive the two fixed false alerts. The
new MCP dispatch surface remains unresolved. All ten authorized SearXNG runs
are consumed; original frozen native/comparator 0/2 results are preserved.

The earlier draft guard-contract stop was premature: existing URL evidence can
represent these narrow facts within the approved correction. Its correction is
recorded in `v12-scope-interpretation-correction.json`. The actual remaining
boundary is loss of that qualification in the complete source flow, not a
request for another ordinary editing approval. The exact cause is not established
by the native report; no callback or unknown effect is assumed harmless.

See `v12-searxng-assessment/packet.json` and the prepared, unapproved
`v12-next-searxng-proposal.json`. Any additional SearXNG observations, full timing
retry, new fresh freeze/evaluation or paid calls require their separate approval.
Final human acceptance is not requested. Phase 21 remains incomplete; pilots and
the full paid benchmark are user-deferred, and Phase 24/15 gates are unchanged.

Final-source verification at `6eb482c`: the local full suite and all 12 hosted
quality suites each pass **2,169 tests with 36 skips and no expected failures**.
Local branch coverage is 89.66%; hosted coverage is 89.65–89.67%.
All 29 normal hosted jobs and docs pass ([CI](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34492040679),
[docs](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34492040778)).
Wheel/sdist source members match Git; ordinary Docker replay, network isolation,
dependency checks, Ruff/format/strict mypy, schemas, notices and offline generated
artifacts pass. Both approved production review requests were regenerated and
replayed without paid calls. The approved Git environment and 13 incomplete
campaigns retain exact compatibility; no complete Git coverage is claimed.
Intermediate local socket failures and hosted dependency-download failures remain
preserved with their actual source; they are not relabeled as successful runs.

Fetch-mcp and open-webSearch each pass both five-input native regression batches:
2/2 vulnerable matches and zero matching fixed/control alerts per batch. Entire
ordered repeats match except recorded volatile fields; retained findings and
all changed diagnostics are source-assessed. SearXNG's two fixed false alerts
remain a separate failed correction gate. There is no final whole-corpus timing
pass, new fresh-source evaluation or final human acceptance.

The **89-row** current audit records **69 passed,
2 user-deferred and
18 unresolved** requirements. See
`v12-closeout-audit/packet.json`, `v12-current-source-test-bindings/packet.json`,
`v12-exposed-assessment/packet.json` and `v12-hosted-audit/packet.json`.


## Historical v10 checkpoint

**Current scanner: `7555a9d`; tested regression delivery: `bbb5fbc`. Phase 22 remains
incomplete.** Both exposed SSRF families complete five inputs twice, detect both
correlated vulnerable variants and have zero matching fixed/control alerts.
Their original frozen misses and source-assessed residual uncertainty remain.
The final Linux sequence failed: **15/25 completed, ten Meta timeouts**, with
both historical batches correctly skipped. No retry or timing waiver occurred.
Final human technical acceptance is unavailable while this gate is unmet.

Linux run [34435283462](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34435283462)
detects six of ten vulnerable inputs; nine of thirteen valid negatives complete
with zero matching alerts. Both raw Meta erratum negatives are incomplete,
leaving nine of fifteen raw negatives completed. The two vulnerable operator
variants newly time out compared with the prior Linux run. All 15 completed
reports equal current local entire ordered reports except recorded volatile
fields. See `v9-linux-assessment/packet.json` and `v9-linux-execution-delta.json`.

The user approved the exact frozen SearXNG evaluation with “start with 1 and 2.”
All five inputs complete twice natively and once with pinned Semgrep: **both tiers
miss both correlated vulnerable variants**, with zero matching fixed/control
alerts. Maximum wall times are 11.311s/14.926s native and 20.219s comparator.
Entire ordered native reports match except recorded volatile fields; JSON/SARIF
validate. The implementation agent's source exposure after freeze is disclosed.
No new paid call, target execution, retry, source tuning or replacement occurred.

Native coverage recognizes four optional HTTP routes but misses the MCP tool
surface and its ordinary stdio factory/dispatch path. The complete URL flow also
includes structural argument validation, source defaults and casted undici fetch.
Every unrelated finding and diagnostic has a source assessment. This is a
substantive fresh detection limitation, not protection or human acceptance.
See `v9-fresh-assessment/packet.json` and `v10-fresh-review.md`; the separate
`v10-searxng-exposure-fix-proposal.json` is prepared but unapproved. Original
frozen results and manifest `275c98478617c76f92c6e0450b52c62f370a9ae22386022051b50ee792adffdd`
remain unchanged.

The current source SHA-256 is
`b7b7d4d4d5b6c0382769471249c7ea6bcc18465ac2b6d0bfcb3107b6047a089c`.
All 29 normal CI jobs and documentation pass at `bbb5fbc`. Scanner and package
bytes equal `7555a9d`; the sole test change adds a branch-guard invariant. Each of
12 hosted quality suites reports 2,141 passed and 36 skipped, with 89.63–89.66%
branch coverage. All 153 wheel and 166 sdist source/schema/fixture/capture members
match Git blobs. Full logs and 225 uploaded files are retained in
`v10-hosted-bbb5fbc/packet.json`; verification is in
`v10-final-hosted-audit/packet.json`. The local suite passes 2,141 tests with
36 skips and 89.64% branch coverage. The preceding `05309f9` hosted run also
passes and is retained separately. Pinned historical reproductions retain their
original scanner and do not replace the current timing gate. Exact unchanged
source/harness/input/capture compatibility is in `v10-source-compatibility.json`.
No additional paid call occurred. Pilots and the full paid benchmark remain
user-deferred; Phase 21 is incomplete and Phase 24/15 gates are unchanged.

The separately approved Linux diagnostic ran once as
[34446017571](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34446017571):
all four native observations and both profiles time out at 120 seconds. The job's
successful diagnostic completion is not a native timing pass. Worker profiles
show CPU-bound call/expression traversal, merging and Value allocation across
SENT-012/015/016. Missing reports remain missing; see
`v10-linux-diagnostic-assessment/packet.json` and `v10-linux-review.md`.

One bounded local experiment used eight native observations and one count profile
on the two exposed Meta inputs. Removing duplicate immutable merge inputs
preserved all ordered reports, but median wall gains of 2.29%/1.84% and CPU gains
of 2.43%/1.40% were small relative to variability, with a first operator regression.
The optimization was reverted; the useful branch-guard invariant test remains.
Scanner bytes still equal `7555a9d`. See `v10-local-performance-disposition.json`.
No full benchmark retry, deadline waiver or runner change occurred. Further
execution decisions and final human acceptance remain separate; Phase 22 stays
incomplete while the timing gate is unmet.

See [implementation status](phase22-implementation-status.md) for the complete current evidence and limitations.

## Historical v8 checkpoint at scanner `62987a6`

**Current scanner: `62987a6`; workflow delivery: `88a559e`. Phase 22 remains
incomplete pending execution reliability and final human technical acceptance.** The user approved both the revised Linux execution and exact
fresh-corpus checkpoint with “go ahead with these two”. Their separate decision
records preserve the exact proposal/manifest hashes and stopping conditions.

Linux development fails its gate: 17/25 inputs complete and eight time out;
maximum end-to-end time is 120.043s. Eight of ten vulnerable inputs complete and
are detected. Nine of thirteen valid negatives complete with zero matching alerts.
Both raw Meta erratum inputs are incomplete, so the raw negative denominator is
nine completed out of fifteen. Both historical batches are skipped after this failure.

The Linux run is 34421737148. No retry, pooling or deadline waiver occurred.
Earlier local historical 43/45 and development 24/25 failures remain preserved.
Seven Linux timeouts are new versus that local development run; one persists.
All 17 completed Linux reports match the prior entire ordered reports except
documented volatile fields. The next bounded Meta performance proposal is
prepared in `v8-next-performance-proposal.json` and remains unapproved.
The approved Meta erratum remains separate from raw scores and execution status.

The fresh fetch-mcp evaluation completes all five inputs twice natively and once
with Semgrep 1.176.0. Both tiers miss both correlated vulnerable variants and
have zero condition-matched alerts on the three fixed/safe inputs. Native reports
match in full except documented volatile fields; maximum wall times are 5.771s
and 5.075s (Semgrep: 16.374s). Native dispatch/schema/class flows remain unresolved.
All 50 unrelated Semgrep JQuery alerts have source-bound false-positive
assessments. No detector tuning or fresh accuracy threshold is introduced;
curation exposure remains disclosed.

The exposed open-webSearch regression remains 2/2 detections in both final runs,
with zero matching negative alerts. Its original 0/2 results are unchanged.
Original held-out evidence remains 10 completed/10 unsupported/5 incomplete,
with zero detections among four completed vulnerable variants. The original
historical 70-warning unadjudicated backlog remains distinct from source-assessed
exposed-regression warnings. Native full-report comparisons and all new finding/
coverage assessments are retained in the v8 evidence.

All 29 normal CI jobs pass at workflow delivery `88a559e`, with the optional benchmark job skipped in ordinary CI; documentation also passes. The 12 quality suites each report 2,121 passed and 36 skipped, with 89.63–89.65% branch coverage. Complete logs/artifacts and source-verified distributions are retained.

The full paid benchmark and external pilots remain explicitly user-deferred,
not passed. No additional paid model calls or target execution occurred in these
two evaluations. Compatible capture/Docker/Git evidence remains bound to the
unchanged scanner. Final human acceptance is separate; Phase 21, Phase 24 and
Phase 15 gates remain unchanged. No merge, release, outreach or next phase.

The user subsequently authorized the bounded offline
[replacement SSRF follow-up](phase22-ssrf-follow-up.md). Those five inputs are now
exposed regressions; their original frozen measurements remain unchanged.

The [execution correction record](phase22-execution.md) describes the implemented
first increment. The complete [independent corpus proposal](phase22-corpus-review.md)
was approved by the user's subsequent “continue” instruction. The exact manifest
and tested Git environment are bound in `artifacts/phase22/authorization.json`;
the original proposals remain unchanged. Detector development now uses exposed
Phase 20 cases and approved development cases. Fresh holdout source remains
separate from tuning.

The [description-poisoning increment](phase22-description-poisoning.md) records
SENT-013 implementation and its bounded development measurement.

## Evidence and acceptance

Preserve all Phase 20 source, configurations, labels, captures, costs and results.
Its 45 inputs are exposed regression evidence, including the historical held-out
split; improvement on them is not fresh held-out performance. Record Phase 22
measurements separately under `artifacts/phase22/` using the existing archive,
provenance, condition scorer, capture ledger and report infrastructure.

Before freezing new evidence, independently review ten vulnerable/fixed pairs
(one development and one separate held-out repository per new rule), ten safe
controls and paired structural mutations. Approval binds exact revisions,
licenses, conditions and repository split. Keep holdout source out of tuning;
exposing a case requires relabeling it and replacement holdout evidence.

The deterministic tier must complete all 45 historical inputs, detect all 20
vulnerable conditions and produce no condition-matched fixed/safe alerts in two
entire batches. The original 120-second and later 300-second hard limits are superseded
prospectively by the explicitly approved 1,800-second native and whole-input
maximum; 120 seconds remains informational; see [the timing policy](phase22-timeout-policy.md).
Both whole historical batches now pass at `1f3f72f`; the complete 25-input
development batch is reused only under the explicit scope amendment. Earlier
failed measurements remain failed, and successes are not pooled across batches. The original requirement for the reviewed tier to match
that completion and retain correct candidates is explicitly deferred for cost,
not passed. Accepted captures verify recorded review compatibility only. Any
future reviewed comparison must count `needs_review`, suppressions and abstentions.
Report holdout results separately without an invented accuracy threshold. Keep
unrelated warnings explicitly unadjudicated unless reviewed. Repeat deterministic
measurements. Pilots are no longer a Phase 22 completion prerequisite.

## Rule contracts

| Rule | Meaning | OWASP | Impact |
| --- | --- | --- | --- |
| SENT-012 | Path containment failure | ASI02:2026 | High |
| SENT-013 | Tool-description poisoning | ASI01:2026 | High |
| SENT-014 | Command-option injection | ASI05:2026 | Critical |
| SENT-015 | Server-side request forgery | ASI02:2026 | High |
| SENT-016 | Operator-credential fallback across a caller boundary | ASI03:2026 | High |

Enable these rules by default when implemented. Preserve selection, suppression,
baseline identity, severity calculation and candidate-bound Finding provenance.
SENT-002 retains its execution meaning, including Kubernetes shell construction.
Each new rule needs independent pairs, applicable Python/TypeScript controls,
remediation, OWASP justification and the existing rule acceptance checklist.

Containment requires a relevant input/boundary/sink relationship, including
traversal, absolute paths, prefix collisions and source-supported symlink failures.
Poisoning requires explicit instruction override, secret exfiltration or cross-tool
redirection in statically recoverable tool/parameter descriptions; ordinary
imperatives, suspicious vocabulary and quoted security warnings are controls.
Option injection follows caller values into supported command-specific positions,
starting with Git references; recognize enforced rejection and safe argument
handling. SSRF follows service URLs into requests and covers prohibited schemes
and literal private/loopback destinations, without claiming DNS-rebinding coverage.
Credential fallback must establish an unauthorized caller/operator boundary;
nearby middleware or unrelated checks are insufficient.

## Compatibility and execution contract

Reuse the current parsers and Semgrep. Support imported handlers/schemas, local
aliases/re-exports, statically bound helpers/methods, cross-file guards/sinks,
low-level registration/dispatch, and declared uv/npm/pnpm workspaces. Resolve local
package exports and TypeScript aliases inside the repository boundary. An aggregate
static scan includes both languages with per-member coverage and root configuration;
disclose nested configurations not applied. Individual package scans use their own
configuration. Dynamic scanning still selects one Python stdio package in Docker.

Unresolved dynamic imports, reflection, ambiguous dispatch, unsupported schemas,
and inaccessible members stay visible. Never follow symlinks, import target code,
render charts or execute target tooling during static analysis.

Recognized Helm chart templates keep their original bytes for text/secret checks;
disclose omission of structured YAML analysis. Ordinary YAML and Sentinel
configuration remain strict. Historical profiling scopes are closed; any new
profile or optimization experiment requires a separately approved bounded proposal.
Do not exclude relevant source or disable detectors to satisfy the timing policy. A separate Git benchmark environment needs an exact tested
SDK pin and dependency packet approved before adoption. Preserve original upstream
source and Phase 20 environment; prove startup/discovery inside Docker.

## Review, campaigns and schema specification

Review stays candidate-bound. Supply repository-relative resolved flow blocks
inside the existing 160-line total, validate references against supplied blocks,
retain redaction and disclose omissions. Invalidate changed request/cache identities;
reuse captures only after request compatibility verification.

The frozen-corpus runner supports source-only rules, offline request preparation
(`prepare-live`), checked replay and the pinned local Semgrep comparator. Preparation
uses a recording reviewer and replay uses checked cassettes; neither makes live
model calls. Phase 22 replay reads its separate `artifacts/phase22/captures` ledger.
The separately approved replacement manifest is supplied through an explicit
`phase22_approval` file. The runner validates the exact manifest hash, unchanged
metadata and selected input records, and enforces the approval's five-input and
`rules`/`semgrep` limits. Results retain both manifest and authorization hashes.
The original approval remains the default; it cannot authorize replacement inputs.
New paid capture still requires the exact bounded approval packet after offline
gates. The source-only corpus runner rejects dynamic treatments; the separately
approved Git runtime environment retains its own verification path.

Expand only SENT-008 through SENT-011. Enumerate supported probe/tool/argument/
mutation combinations and schedule deterministic round-robin coverage with GPT
priorities inside that schedule. Defaults: 24 attempts or 120 seconds, whichever
comes first. Every attempt has separate fresh baseline and attack containers.
`--max-probe-attempts` and `--campaign-timeout-seconds`, matching `SENTINEL_*`
variables and `[sandbox]` settings accept positive integers with CLI > environment
> file precedence. Rules-only bypasses runtime settings. Action uses repository
configuration. Preserve baseline validity, schema checks, observable effects,
isolation, interruption cleanup and runtime-proof protection.

The integration's native schema 1.7.0 adds workspace coverage and one `probe_outcomes` record per
planned attempt, stable attempt IDs and campaign budget/coverage totals. Record all
untested remainders; exhausting a budget with eligible work remaining returns 3.
Migrate 1.3–1.6 reports/baselines without changing Finding identities, suppression,
nullable reviews or runtime proof; old outcomes become legacy attempts without
invented historical coverage. SARIF stays 2.1.0. This integration emits 1.7.0;
migration/consumer engineering is verified at `cec0322`; explicit technical acceptance remains pending.
Historical native reports retain their recorded schema versions.

## Delivery and outstanding decisions

The [implementation status map](phase22-implementation-status.md) separates
verified draft increments from the still-unfinished full technical plan.

The [filesystem condition follow-up](phase22-containment-conditions.md) records
enforced collection/parent guards and four exposed-input adjudications.

The [shared containment follow-up](phase22-shared-containment.md) records
bounded caller/context and helper identity fixes; full discovery remains pending.

The [workspace increment](phase22-workspaces.md) records aggregate scanning,
parent corrections, verification evidence and the remaining technical gates.

The [Python containment increment](phase22-python-containment.md) records its
implementation, repeated exposed-input measurements and remaining technical gates.
The [TypeScript containment increment](phase22-typescript-containment.md) records
parser-backed bindings, repeated completion checks and unresolved fixed guards.

The user approved consolidated delivery on September 7, 2026 to reduce repeated
CI and PR overhead. Preserve existing draft PRs as checkpoints and complete the
remaining work on `phase22/integration`, with separate reviewable commits in
contract/evidence, execution, containment/shared discovery, remaining
detectors/compatibility, review/campaign, report/acceptance order. Do not create
or update a PR for each increment. Batch delivery when the integrated candidate
is ready; branch consolidation does not imply implementation acceptance.

During implementation, run focused regressions and applicable lint/type checks.
Run full local checks at substantial integration milestones and the complete
benchmark and hosted OS matrix on the final candidate. Rerun affected checks
after fixes or newly identified risks. Retain raw commands, exit codes, logs and
commit identities as work proceeds; batch evidence packaging and delivery docs.
Existing CI workflows and final acceptance requirements remain unchanged: Ruff,
format, strict mypy, schemas, the full branch-coverage suite, dependency and
notices checks, strict docs, and applicable Docker/CI checks. Report completion,
support, recall, retained findings, abstentions, incorrect suppressions, false
alarms, timing and cost. Rerun comparable pinned Semgrep measurements; Snyk/Cisco
performance stays unmeasured.

The corpus freeze, Git SDK environment and paid evaluation require concrete
approval packets. Paid packets name requests, purpose, model, request/dollar caps
and stopping conditions; offline checks precede them. Merge and publication await
user decision. No new parser, language, remote runtime, independent AI discovery,
stateful exploitation, telemetry or outreach is authorized. Technical acceptance
does not satisfy pilot, adoption or whole-repository safety gates.
