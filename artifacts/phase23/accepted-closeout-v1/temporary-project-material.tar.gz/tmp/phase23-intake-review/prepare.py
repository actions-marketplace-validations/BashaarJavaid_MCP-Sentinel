import copy
import difflib
import json
from pathlib import Path
import yaml

class FormDumper(yaml.SafeDumper):
    def increase_indent(self, flow=False, indentless=False):
        return super().increase_indent(flow, False)

root = Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
stage = Path('/private/tmp/phase23-intake-review')
packet = root / 'artifacts/phase23/intake-review-v1'
changed = {}
def propose(path, text):
    changed[path] = text
    target = stage / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)
def field(kind, ident, label, description, required=True):
    return {'type': kind, 'id': ident, 'attributes': {'label': label, 'description': description}, 'validations': {'required': required}}

notice = {'type': 'markdown', 'attributes': {'value': 'Submit only sanitized, publicly shareable evidence. For sensitive Sentinel vulnerabilities, use [private reporting](https://github.com/BashaarJavaid/MCP-Sentinel/security/advisories/new). For third-party vulnerabilities, follow the upstream security policy before public disclosure. Reporter expectations are unreviewed proposals; maintainers review labels and changes. See the [maintenance process](https://bashaarjavaid.github.io/MCP-Sentinel/phase23-maintenance/).'}}
rights = field('textarea', 'source-rights', 'Source provenance and reuse rights', 'Give public source URLs, immutable revisions, file paths and applicable license/notice links. For your own examples, state authorship. If rights are unknown, say unknown. Public posting alone does not authorize corpus reuse.')
sanitize = {'type': 'checkboxes', 'id': 'no-secrets', 'attributes': {'label': 'Sensitive data confirmation', 'options': [{'label': 'I removed secrets, credentials, personal data, internal endpoints and private source, and this report is suitable for public disclosure.', 'required': True}]}}
consent = {'type': 'checkboxes', 'id': 'example-reuse', 'attributes': {'label': 'Optional example reuse consent', 'description': 'This is separate from sanitization and is not required to report an issue. Without consent or an applicable license, maintainers must obtain permission before incorporating examples.', 'options': [{'label': "I have the right to license my submitted examples and permit their reuse and modification in Sentinel's regression corpus under the project's MIT license.", 'required': False}]}}
rules = [f'SENT-{i:03d}' for i in range(1, 17)]
for name in ('false-positive', 'rule-proposal'):
    form = yaml.safe_load((root / f'.github/ISSUE_TEMPLATE/{name}.yml').read_text())
    form['body'].insert(0, copy.deepcopy(notice))
    form['body'] = [item for item in form['body'] if item.get('id') != 'no-secrets']
    if name == 'false-positive':
        for item in form['body']:
            ident = item.get('id')
            if ident == 'rule':
                item['attributes']['options'] = rules
            elif ident == 'version':
                item['attributes']['description'] = 'Paste sentinel --version and the commit if using a source checkout.'
                item['attributes']['placeholder'] = 'Version or exact commit'
            elif ident == 'command-configuration':
                item['attributes']['description'] = 'Include the exact command and sanitized configuration, scan mode, rule selection, ignores, baselines and suppressions. Remove credentials and internal endpoints.'
            elif ident == 'finding':
                item['attributes']['description'] = 'Include the matching finding and complete sanitized JSON/SARIF report, exit status, diagnostics and analysis/support status. Link a sanitized attachment if needed.'
            elif ident == 'reproduction':
                item['attributes']['description'] = 'Provide minimal publicly shareable source, manifests and relevant SDK versions. Include a vulnerable counterpart if known, or say unavailable. Do not execute an unsafe target to report it.'
            elif ident == 'expected':
                item['attributes']['label'] = 'Reporter expectation (unreviewed)'
                item['attributes']['description'] = 'Explain the exact source condition that makes this finding a false positive, including file/line evidence. Maintainers must review the label.'
    else:
        form['body'].insert(1, {'type': 'dropdown', 'id': 'related-rule', 'attributes': {'label': 'Related current rule', 'options': ['New rule / unsure', *rules]}, 'validations': {'required': True}})
        form['body'].insert(2, field('textarea', 'environment-configuration', 'Reproduction environment and configuration', 'Give the Sentinel version/commit, language/SDK versions, command, sanitized configuration including ignores/baselines/suppressions, and existing report/diagnostics if available. For a source-only proposal, say not run.'))
        for item in form['body']:
            if item.get('id') == 'detection':
                item['attributes']['label'] = 'Proposed detection (unreviewed)'
            elif item.get('id') == 'clean-example':
                item['attributes']['description'] = 'Provide paired fixed and safe-control source that should not be reported, or explain what is unavailable. Empty output without established support is not evidence of safety.'
            elif item['type'] == 'markdown' and item is not form['body'][0]:
                item['attributes']['value'] = 'Maintainers review labels and allocate a new stable rule ID only for an accepted new detection meaning. Corrections preserve existing IDs. AI-assisted drafts receive the same source, test and human review; no automatic promotion.'
    form['body'].extend(copy.deepcopy([rights, sanitize, consent]))
    propose(f'.github/ISSUE_TEMPLATE/{name}.yml', yaml.dump(form, Dumper=FormDumper, sort_keys=False, width=88))

missed = {'name': 'Missed vulnerability', 'description': 'Report a reproducible missed finding using publicly shareable source evidence.', 'title': '[Missed vulnerability] ', 'labels': ['bug'], 'body': [
    notice,
    field('input', 'version', 'Sentinel version or commit', 'Paste sentinel --version and the commit if using a source checkout.'),
    {'type': 'dropdown', 'id': 'rule', 'attributes': {'label': 'Expected rule (unreviewed)', 'options': ['Unsure / proposed new detection', *rules]}, 'validations': {'required': True}},
    field('input', 'language-framework', 'Language and framework', 'Include language/runtime and MCP SDK versions.'),
    field('textarea', 'command-configuration', 'Command and configuration', 'Include the exact command, scan mode, sanitized configuration, rule selection, ignores, baselines and suppressions.'),
    field('textarea', 'observed-report', 'Observed result and diagnostics', 'Attach complete sanitized JSON/SARIF, exit status, diagnostics and analysis/support status. Distinguish zero findings from unsupported, timed-out or incomplete analysis.'),
    field('textarea', 'reproduction', 'Minimal source reproduction', 'Provide publicly shareable source and manifests, with immutable upstream revision links and file/line evidence for the registration-to-sink path. No unsafe target execution is needed.'),
    field('textarea', 'expected', 'Reporter expectation (unreviewed)', 'Explain the exact vulnerable condition and expected finding. Link a public advisory if one exists. Maintainers review the label; a report alone does not establish a vulnerability.'),
    field('textarea', 'fixed-safe', 'Fixed and safe controls', 'Provide paired fixed source and a safe control if available; otherwise say unavailable. Explain why the condition is absent. Unsupported negatives cannot count as passes.'),
    rights, sanitize, consent,
]}
propose('.github/ISSUE_TEMPLATE/missed-vulnerability.yml', yaml.dump(missed, Dumper=FormDumper, sort_keys=False, width=88))
propose('.github/ISSUE_TEMPLATE/config.yml', yaml.dump({'blank_issues_enabled': False, 'contact_links': [
    {'name': 'Sensitive Sentinel vulnerability', 'url': 'https://github.com/BashaarJavaid/MCP-Sentinel/security/advisories/new', 'about': 'Report Sentinel vulnerabilities privately; use the upstream security policy for third-party vulnerabilities.'},
    {'name': 'Feedback and maintenance process', 'url': 'https://bashaarjavaid.github.io/MCP-Sentinel/phase23-maintenance/', 'about': 'Source sanitization, optional example reuse, label review and regression releases.'},
]}, Dumper=FormDumper, sort_keys=False, width=88))
propose('docs/phase23-maintenance.md', (stage / 'docs/phase23-maintenance.md').read_text())
for path, addition in {
    'CONTRIBUTING.md': '\n## Feedback and maintained regressions\n\nUse the separate false-positive, missed-vulnerability and rule-proposal forms.\nReporter expectations require maintainer label review. Include sanitized source,\nrevision/configuration and complete report evidence; use private reporting for\nsensitive Sentinel vulnerabilities and upstream policies for third-party issues.\nExample reuse under MIT requires separate optional consent or an applicable\nlicense, with notices retained. AI-assisted drafts receive the same review.\nSee the [maintenance process](https://bashaarjavaid.github.io/MCP-Sentinel/phase23-maintenance/)\nfor reproductions, offline regression gates, timings and reviewed releases.\n',
    'docs/contributing.md': '\n## Feedback and maintenance\n\nUse separate false-positive, missed-vulnerability and rule-proposal forms;\ninclude sanitized source/configuration, immutable revisions and complete report\nevidence. Expectations remain unreviewed until the maintainer checks source\nconditions and analysis support. Optional MIT example reuse consent is separate\nfrom sanitization; obtain permission or establish an applicable license before\ncorpus incorporation. Follow private Sentinel reporting and upstream disclosure\npolicies. AI-assisted drafts receive the same review. The [maintenance\nprocess](phase23-maintenance.md) covers the weekly checklist, lifecycle records,\noffline regression tests and human-approved versioned releases.\n',
    'SECURITY.md': '\n## Public detector feedback\n\nAfter disclosure is appropriate, submit sanitized false-positive or\nmissed-vulnerability evidence through the separate issue forms. Reporter labels\nrequire maintainer review. Public submission does not by itself grant corpus\nreuse rights: retain an applicable license or obtain separate optional MIT\nexample reuse consent before incorporation. See the [maintenance\nprocess](https://bashaarjavaid.github.io/MCP-Sentinel/phase23-maintenance/).\n',
}.items():
    propose(path, (root / path).read_text() + addition)
path = '.github/PULL_REQUEST_TEMPLATE.md'
text = (root / path).read_text().replace('Rule change: maintainers assigned a new stable ID and paired vulnerable/clean fixtures pass.', 'Rule change: existing IDs retain their meanings; maintainers assigned an ID for any new meaning, and paired vulnerable/fixed/safe fixtures pass.')
text += '\n## Feedback regression (when applicable)\n\n- [ ] Link the lifecycle record, reviewed source labels/match conditions, source rights and corpus hashes.\n- [ ] Link baseline/corrected reports, complete ordered comparisons, all changed findings/support judgments and retained failures.\n- [ ] Link the offline current-candidate CI result and the approved deliberate-regression rejection evidence.\n- [ ] Record meaningful coverage changes, limitations, actual milestones and waiting intervals; leave unknown times unknown.\n- [ ] AI-assisted drafts received the same review; no automatic label/rule promotion or private-source upload occurred.\n\nTechnical review does not authorize publication. Link the separately approved\nrelease contents, version and actions before merge/tag/publication.\n'
propose(path, text)
path = 'docs/hackathon.md'
text = (root / path).read_text().replace('## Release evidence\n', '## Release evidence\n\nFor new feedback-driven releases, follow the [maintenance release review and\nverification checklist](phase23-maintenance.md#release-review-and-verification).\nThe version and exact merge/tag/publication actions require maintainer approval.\nHistorical release evidence below retains its original version bindings.\n', 1)
propose(path, text)
path = 'mkdocs.yml'
propose(path, (root / path).read_text().replace('  - Contributing: contributing.md\n', '  - Contributing: contributing.md\n  - Maintenance: phase23-maintenance.md\n'))
path = 'CHANGELOG.md'
propose(path, (root / path).read_text().replace('### Added\n', '### Added\n\n- Missed-vulnerability intake, current rule choices, optional example reuse consent,\n  and maintainer guidance for source label review, weekly SDK/advisory checks,\n  lifecycle timing evidence and offline regression releases.\n', 1))
patch = ''
for path, after in changed.items():
    before = (root / path).read_text() if (root / path).exists() else ''
    patch += ''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True), fromfile=f'a/{path}' if before else '/dev/null', tofile=f'b/{path}'))
(packet / 'proposed-changes.patch').write_text(patch)
(stage / 'changed-paths.json').write_text(json.dumps(list(changed), indent=2) + '\n')
print(f'Prepared unapplied patch for {len(changed)} files.')
