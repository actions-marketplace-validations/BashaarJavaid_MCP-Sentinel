import json
from pathlib import Path
packet = Path('/Users/bashaarjavaid/Projects/MCP-Sentinel/artifacts/phase23/intake-review-v1')
record = {
    'schema_version': 1,
    'case_id': 'GHSA-5w57-2ccq-8w95',
    'status': 'template_pending_review',
    'owner': 'BashaarJavaid',
    'advisory': {
        'url': 'https://github.com/alfonsograziano/node-code-sandbox-mcp/security/advisories/GHSA-5w57-2ccq-8w95',
        'published_at_utc': None, 'publication_evidence': [],
    },
    'intake': {
        'received_at_utc': None, 'recorded_at_utc': None, 'evidence': [],
        'channel': 'public_advisory',
        'scope': 'sandbox_stop.container_id shell injection; source-only; one advisory',
        'proposed_revisions': {
            'vulnerable_1.2.0': '7fd7fb88be2cb2a03702915d05d03bdf6bc8ac80',
            'fixed_1.3.0': '19a1ff3386c5bc00eb1f2052a4fa8f8379bb8fea',
        },
    },
    'source_rights': {'status': 'pending', 'license': None, 'consent': None, 'evidence': [], 'reviewed_by': None, 'reviewed_at_utc': None},
    'reporter_expectation': {'rule_id': 'SENT-002', 'condition': 'container_id reaches a shell-interpreted command', 'expected_behavior': 'source-matched finding on vulnerable inputs; supported absence on paired negatives', 'evidence': []},
    'reviewed_labels': [],
    'identities': {key: None for key in ('corpus_version', 'manifest_sha256', 'source_inventory_sha256', 'scanner_revision', 'scanner_tree_sha256', 'rule_tree_sha256', 'helper_sha256', 'configuration_sha256')},
    'milestones': [], 'waiting_intervals': [],
    'elapsed_seconds': {key: None for key in ('advisory_to_intake', 'intake_to_triage', 'intake_to_reproduction', 'intake_to_fix_verification', 'intake_to_human_review', 'intake_to_publication')},
    'evaluations': [],
    'release': {key: None for key in ('version', 'reviewed_contents', 'revision', 'package_hashes', 'package_pins', 'action_exact_pin', 'action_alias', 'approvals', 'workflow', 'assets', 'provenance', 'rollback', 'released_regression_evidence')},
}
weekly = {
    'schema_version': 1, 'owner': 'BashaarJavaid', 'scheduled_local': None,
    'timezone': 'America/Los_Angeles', 'scheduled_at_utc': None,
    'status': 'template_pending_review', 'started_at_utc': None,
    'completed_at_utc': None, 'sources_checked': [], 'decisions': [],
    'missed_reason': None, 'catch_up_record': None,
}
for name, value in [('lifecycle-template.json', record), ('weekly-review-template.json', weekly)]:
    (packet / name).write_text(json.dumps(value, indent=2) + '\n')
