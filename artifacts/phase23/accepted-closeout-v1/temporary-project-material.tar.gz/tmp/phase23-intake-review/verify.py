import ast
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import yaml

root = Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
stage = Path('/private/tmp/phase23-intake-review')
packet = root / 'artifacts/phase23/intake-review-v1'
module = ast.parse((root / 'src/sentinel/owasp_mapping.py').read_text())
catalog = next(ast.literal_eval(node.value) for node in module.body if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'RULE_OWASP_IDS' for t in node.targets))
forms = []
for name in ('false-positive', 'missed-vulnerability', 'rule-proposal'):
    form = yaml.safe_load((stage / f'.github/ISSUE_TEMPLATE/{name}.yml').read_text())
    items = {item['id']: item for item in form['body'] if 'id' in item}
    assert len(items) == len([item for item in form['body'] if 'id' in item])
    assert len(form['body']) <= 20
    rule = items['related-rule' if name == 'rule-proposal' else 'rule']
    assert {opt for opt in rule['attributes']['options'] if opt.startswith('SENT-')} == set(catalog)
    assert items['no-secrets']['attributes']['options'][0]['required'] is True
    assert items['example-reuse']['attributes']['options'][0]['required'] is False
    assert 'validations' not in items['example-reuse']
    assert items['source-rights']['validations']['required'] is True
    for item in form['body']:
        assert item['type'] in ('markdown', 'input', 'textarea', 'dropdown', 'checkboxes')
        if item['type'] == 'dropdown':
            assert len(item['attributes']['options']) == len(set(item['attributes']['options']))
    forms.append(name)
for name in ('lifecycle-template.json', 'weekly-review-template.json'):
    value = json.loads((packet / name).read_text())
    assert value['status'] == 'template_pending_review'
    assert value['schema_version'] == 1
value = json.loads((packet / 'lifecycle-template.json').read_text())
assert value['reviewed_labels'] == value['evaluations'] == value['milestones'] == []
assert all(v is None for v in value['elapsed_seconds'].values())
subprocess.run(['git', 'apply', '--check', str(packet / 'proposed-changes.patch')], cwd=root, check=True)
assert subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True) == ''
paths = json.loads((stage / 'changed-paths.json').read_text())
checks = {
    'recorded_at_utc': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
    'base_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'patch_apply_check': 'passed; not applied to working repository',
    'form_checks': {'result': 'passed', 'forms': forms, 'catalog': list(catalog), 'checks': ['YAML parse', 'unique input IDs', 'current rule choices', 'required sanitization', 'separate optional consent', 'source-rights field', 'field types and dropdown uniqueness', 'at most 20 form fields']},
    'record_checks': 'passed; templates, no invented milestones, approvals or elapsed times',
    'strict_docs': {'result': 'passed', 'command': '/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/mkdocs build --strict --config-file /private/tmp/phase23-intake-review/mkdocs.yml --site-dir /private/tmp/phase23-intake-review/site', 'scope': 'temporary copy with proposed docs/nav; no publication'},
    'tracked_repository_files_changed': [],
    'full_suite': 'not run; proposal-only checkpoint',
    'hosted_checks': 'not run',
    'scans': 0, 'advisory_target_executions': 0, 'paid_calls': 0,
    'files': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(packet.iterdir()) if p.name != 'verification.json'},
    'proposed_files': {path: {'before_sha256': hashlib.sha256((root/path).read_bytes()).hexdigest() if (root/path).exists() else None, 'after_sha256': hashlib.sha256((stage/path).read_bytes()).hexdigest()} for path in paths},
}
(packet / 'verification.json').write_text(json.dumps(checks, indent=2) + '\n')
print('PASS: three form checks, two draft JSON records, patch applicability and unchanged tracked files.')
