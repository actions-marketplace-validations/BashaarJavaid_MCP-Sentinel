import difflib
import hashlib
import json
import re
from pathlib import Path
from scripts.phase20_corpus import archive_files, digest, tree_digest

ROOT=Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
CORPUS=ROOT/'tests/evals/phase23'
PACKET=ROOT/'artifacts/phase23/source-review-v1'
REVS=['7fd7fb88be2cb2a03702915d05d03bdf6bc8ac80','19a1ff3386c5bc00eb1f2052a4fa8f8379bb8fea']
REPO='alfonsograziano/node-code-sandbox-mcp'
def artifact(path):
    return {'path':str(path.relative_to(ROOT)), 'sha256':digest(path.read_bytes())}
def save_json(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')
def evidence(files,path,start,end,role):
    return {'path':path,'start_line':start,'end_line':end,'sha256':digest(files[path]),'role':role}
def line(files,path,needle):
    found=[i for i,s in enumerate(files[path].decode().splitlines(),1) if needle in s]
    assert len(found)==1,(path,needle,found)
    return found[0]

snapshots=[]
trees=[]
for rev,kind,version in zip(REVS,['vulnerable','fixed'],['1.2.0','1.3.0']):
    path=CORPUS/'snapshots'/(rev+'.tar.gz')
    files=archive_files(path.read_bytes(),strip_root=True)
    tree=json.loads((PACKET/'provenance'/(kind+'-tree.json')).read_text())
    assert tree['truncated'] is False
    blobs={x['path']:x for x in tree['tree'] if x['type']=='blob'}
    assert set(blobs)==set(files)
    for name,data in files.items():
        assert blobs[name]['mode'] in ('100644','100755')
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blobs[name]['sha'], name
    commit=json.loads((PACKET/'provenance'/(kind+'-commit.json')).read_text())
    assert commit['sha']==rev and commit['commit']['tree']['sha']==tree['sha']
    tag=json.loads((PACKET/'provenance'/('v'+version+'-tag.json')).read_text())
    ref=json.loads((PACKET/'provenance'/('v'+version+'-ref.json')).read_text())
    assert tag['object']['type']=='commit' and tag['object']['sha']==rev
    assert ref['object']['sha']==tag['sha']
    assert json.loads(files['package.json'])['version']==version
    license_start=line(files,'README.md','## License')
    snapshots.append({'revision':rev,'version':version,'repository':REPO,'archive':artifact(path),'strip_root':True,'tree_sha256':tree_digest(files),'files':{name:digest(data) for name,data in sorted(files.items())},'git_tree_sha':tree['sha'],'license_evidence':evidence(files,'README.md',license_start,len(files['README.md'].decode().splitlines()),'Explicit repository MIT permission notice; exact README retained; no top-level LICENSE file or added copyright attribution')})
    trees.append(files)
    # Convenient, byte-identical evidence copies for human review; archives remain inputs.
    for name in ['src/server.ts','src/tools/stop.ts','src/utils.ts','src/types.ts','src/containerUtils.ts','README.md','website/LICENSE.md']:
        out=PACKET/'source'/kind/name
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_bytes(files[name])

server="""import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import stopSandbox, { argSchema as stopSchema } from './tools/stop.ts';

const server = new McpServer({ name: 'phase23-stop-reproduction', version: '1.0.0' });
server.tool('sandbox_stop', 'Remove a sandbox container.', stopSchema, stopSandbox);
await server.connect(new StdioServerTransport());
"""
vulnerable="""import { z } from 'zod';
import { execSync } from 'node:child_process';

export const argSchema = { container_id: z.string() };

export default async function stopSandbox({ container_id }: { container_id: string }) {
  execSync(`docker rm -f ${container_id}`);
  return { content: [{ type: 'text' as const, text: 'Container removed.' }] };
}
"""
fixed="""import { z } from 'zod';
import { execFileSync } from 'node:child_process';
import { sanitizeContainerId } from '../utils.ts';

export const argSchema = {
  container_id: z.string().regex(/^[a-zA-Z0-9_.-]+$/, 'Invalid container ID'),
};

export default async function stopSandbox({ container_id }: { container_id: string }) {
  const validId = sanitizeContainerId(container_id);
  if (!validId) {
    return { content: [{ type: 'text' as const, text: 'Invalid container ID' }] };
  }
  execFileSync('docker', ['rm', '-f', validId]);
  return { content: [{ type: 'text' as const, text: 'Container removed.' }] };
}
"""
# Copy the entire upstream validator, including its source comments.
utils_lines=trees[1]['src/utils.ts'].decode().splitlines(keepends=True)
validator=''.join(utils_lines[150:157])
assert validator.startswith('export function sanitizeContainerId') and validator.endswith('}\n')
package={'name':'phase23-stop-reproduction','version':'1.0.0','private':True,'type':'module','dependencies':{'@modelcontextprotocol/sdk':'^1.10.2','zod':'^3.24.3'}}
# Version declarations describe syntax context only; no package installation occurs.
minimal=[]
for source,files in zip([vulnerable,fixed],trees):
    minimal.append({'package.json':(json.dumps(package,indent=2)+'\n').encode(), 'src/server.ts':server.encode(), 'src/tools/stop.ts':source.encode(), 'UPSTREAM-README.md':files['README.md']})
minimal[1]['src/utils.ts']=validator.encode()
safe=dict(minimal[0])
safe['src/tools/stop.ts']=vulnerable.replace('execSync(`docker rm -f ${container_id}`);',"execSync('docker rm -f phase23-safe-container');").encode()
renames={'server':'mcpServer','stopSandbox':'removeSandbox','argSchema':'argumentsSchema','stopSchema':'inputSchema','container_id':'sandbox_ref','validId':'checkedRef','sanitizeContainerId':'validateSandboxRef'}
# Rename identifiers only in code: token replacements exclude quoted strings,
# except protocol object-key container_id (unquoted in these files). The import
# path /server/mcp.js must remain unchanged, so handle server uses specifically.
def rename(files):
    out=dict(files)
    for path,data in files.items():
        if not path.endswith('.ts'): continue
        text=data.decode()
        for old,new in renames.items():
            if old=='server':
                text=text.replace('const server =','const mcpServer =').replace('server.tool(', 'mcpServer.tool(').replace('server.connect(', 'mcpServer.connect(')
            else:
                text=re.sub(r'\b'+old+r'\b',new,text)
        out[path]=text.encode()
    return out
variants=[('minimized-vulnerable','vulnerable','minimized',REVS[0],minimal[0],None),('minimized-fixed','fixed','minimized',REVS[1],minimal[1],None),('safe-literal','safe','safe_control',REVS[0],safe,'minimized-vulnerable'),('renamed-vulnerable','vulnerable','renamed',REVS[0],rename(minimal[0]),'minimized-vulnerable'),('renamed-fixed','fixed','renamed',REVS[1],rename(minimal[1]),'minimized-fixed')]
inputs=[]
def record(ident,label,group,rev,files,source,parent):
    path='src/tools/stop.ts'
    sink_needle="execFileSync('docker'" if label=='fixed' else ('execSync(`docker rm' if label=='vulnerable' else "execSync('docker rm")
    sink_line=line(files,path,sink_needle)
    regline=line(files,'src/server.ts',"'sandbox_stop'")
    handlerline=line(files,path,'export default async function')
    renamed=group=='renamed'
    ev=[evidence(files,'src/server.ts',regline if group!='full' else regline-1,regline if group!='full' else regline+4,'MCP sandbox_stop registration'),evidence(files,path,handlerline,handlerline,'Destructured tool-input handler'),evidence(files,path,sink_line,sink_line,'Shell sink' if label=='vulnerable' else 'Non-shell argv sink' if label=='fixed' else 'Literal shell-command control')]
    return {'id':ident,'proposed_label':label,'group':group,'origin_revision':rev,'parent':parent,'source':source,'files':{n:digest(d) for n,d in sorted(files.items())},'tree_sha256':tree_digest(files),'tool':'sandbox_stop','parameter':'sandbox_ref' if renamed else 'container_id','handler':'removeSandbox' if renamed else 'stopSandbox','evidence':ev,'match':{'rule_id':'SENT-002','sink_path':path,'sink_line':sink_line,'shell_sink':label=='vulnerable','minimum_matching_findings':1 if label=='vulnerable' else 0,'maximum_matching_findings':None if label=='vulnerable' else 0},'support':{'status':'pending_evaluation','require_recognized_surface':True,'require_rule_visit':'SENT-002','require_resolved_relevant_flow':True},'label_review':{'status':'proposed_pending_user_review','reviewer':None,'reviewed_at_utc':None}}
for kind,rev,files,snapshot in zip(['vulnerable','fixed'],REVS,trees,snapshots):
    inputs.append(record('full-'+kind,kind,'full',rev,files,{'kind':'archive','artifact':snapshot['archive'],'strip_root':True},None))
for ident,label,group,rev,files,parent in variants:
    dest=CORPUS/'inputs'/ident
    for path,data in files.items():
        target=dest/path
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
    inputs.append(record(ident,label,group,rev,files,{'kind':'directory','path':str(dest.relative_to(ROOT))},parent))
for name,before,after in [('upstream-stop-fix',trees[0],trees[1]),('minimized-fix',minimal[0],minimal[1]),('safe-literal',minimal[0],safe),('renamed-vulnerable',minimal[0],rename(minimal[0])),('renamed-fixed',minimal[1],rename(minimal[1]))]:
    patch=''
    paths=sorted(set(before)|set(after))
    if name=='upstream-stop-fix': paths=['src/server.ts','src/tools/stop.ts','src/utils.ts']
    for path in paths:
        if path.endswith('.md') or not path.endswith('.ts'):continue
        patch+=''.join(difflib.unified_diff(before.get(path,b'').decode().splitlines(keepends=True),after.get(path,b'').decode().splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
    (PACKET/(name+'.patch')).write_text(patch)
manifest={'schema_version':1,'corpus_version':'phase23-ghsa-5w57-v1-proposed','status':'proposed_pending_user_freeze','freeze_approved':False,'case_id':'GHSA-5w57-2ccq-8w95','independent_advisory_count':1,'source_only':True,'snapshots':snapshots,'inputs':inputs,'proposed_order':[x['id'] for x in inputs], 'proposed_passes_per_stage':2, 'rename_map':renames,'provenance':[artifact(p) for p in sorted((PACKET/'provenance').iterdir()) if p.is_file()]}
save_json(CORPUS/'manifest.json',manifest)
print('Prepared seven inputs; verified all 173 upstream blobs against complete Git trees and both annotated tag bindings.')
print('Manifest SHA-256:',digest((CORPUS/'manifest.json').read_bytes()))
print('Upstream lock zod:',json.loads(trees[0]['package-lock.json'])['packages']['node_modules/zod']['version'])
