import json
from pathlib import Path
from scripts.phase20_corpus import archive_files, digest
root=Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
p=root/'tests/evals/phase23/manifest.json'
m=json.loads(p.read_text())
for item in m['inputs']:
    source=item['source']
    files=archive_files((root/source['artifact']['path']).read_bytes(),strip_root=True) if source['kind']=='archive' else {n:(root/source['path']/n).read_bytes() for n in item['files']}
    item['match'].pop('shell_sink')
    item['match']['source_text']=files['src/tools/stop.ts'].decode().splitlines()[item['match']['sink_line']-1].strip()
    item['evidence'].append({'path':'src/tools/stop.ts','start_line':next(i for i,s in enumerate(files['src/tools/stop.ts'].decode().splitlines(),1) if 'export const ' in s),'end_line':next(i for i,s in enumerate(files['src/tools/stop.ts'].decode().splitlines(),1) if 'export const ' in s)+ (2 if item['proposed_label']=='fixed' else 0),'sha256':digest(files['src/tools/stop.ts']),'role':'Tool input schema'})
    if item['proposed_label']=='fixed':
        lines=files['src/utils.ts'].decode().splitlines()
        start=next(i for i,s in enumerate(lines,1) if s.startswith('export function sanitizeContainerId') or s.startswith('export function validateSandboxRef'))
        item['evidence'].append({'path':'src/utils.ts','start_line':start,'end_line':start+6,'sha256':digest(files['src/utils.ts']),'role':'Identifier validation helper; no shell enabled at downstream argv sink'})
m['matching_contract']={
 'finding':'Canonical rule_id SENT-002 with file location.path equal to match.sink_path and inclusive location.range spanning match.sink_line, with static evidence at that source-bound sink. No message-only, count-only, severity-only or unrelated-location match.',
 'support':'Complete successful report; static stage succeeded; SENT-002 evaluated and selected; exact sandbox_stop registration and source-bound handler recognized; SENT-002 in examined_rule_ids; no relevant unresolved flow, skipped analysis or warning indicating missing support. An unlocated warning whose relevance cannot be ruled out leaves support unresolved. All diagnostics and unrelated findings require source assessment.',
 'negative':'Zero matching SENT-002 findings plus established support; empty findings or evaluated rule status alone is insufficient.',
 'repeat':'Entire ordered report equality; volatile exclusions and scanner configuration will be proposed in the separate execution packet before any scan. No exclusions approved by this source freeze decision.',
 'scope':'shell interpretation of the named tool field at the named sink; not general Docker safety, option injection, other tools, sandbox escape at runtime or independent generalization.'}
p.write_text(json.dumps(m,indent=2)+'\n')
print(digest(p.read_bytes()))
