import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from scripts.phase20_corpus import archive_files, digest, tree_digest
from scripts.phase23_regression import validate, source_files

root=Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
p=root/'artifacts/phase23/source-review-v1'
m=validate()
inputs={i['id']:source_files(i) for i in m['inputs']}
for source in m['snapshots']:
    files=archive_files((root/source['archive']['path']).read_bytes(),strip_root=True)
    assert {name:digest(data) for name,data in files.items()}==source['files']
    assert tree_digest(files)==source['tree_sha256']
    kind='vulnerable' if source['version']=='1.2.0' else 'fixed'
    commit=json.loads((p/'provenance'/(kind+'-commit.json')).read_text())
    tree=json.loads((p/'provenance'/(kind+'-tree.json')).read_text())
    assert tree['truncated'] is False
    assert tree['sha']==commit['commit']['tree']['sha']==source['git_tree_sha']
    blobs={i['path']:i for i in tree['tree'] if i['type']=='blob'}
    assert set(blobs)==set(files)
    for name,data in files.items():
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blobs[name]['sha']
    for copy in (p/'source'/kind).rglob('*'):
        if copy.is_file():assert copy.read_bytes()==files[copy.relative_to(p/'source'/kind).as_posix()]
for kind in ['vulnerable','fixed']:
    mini=inputs['minimized-'+kind]
    original=inputs['full-'+kind]
    assert mini['UPSTREAM-README.md']==original['README.md']
    expected=dict(mini)
    for name,data in mini.items():
        if not name.endswith('.ts'):continue
        text=data.decode()
        for old,new in m['rename_map'].items():
            if old=='server':text=text.replace('const server =','const mcpServer =').replace('server.tool(','mcpServer.tool(').replace('server.connect(','mcpServer.connect(')
            else:text=re.sub(r'\b'+old+r'\b',new,text)
        expected[name]=text.encode()
    assert expected==inputs['renamed-'+kind]
safe=dict(inputs['minimized-vulnerable'])
safe['src/tools/stop.ts']=safe['src/tools/stop.ts'].replace(b'execSync(`docker rm -f ${container_id}`);',b"execSync('docker rm -f phase23-safe-container');")
assert safe==inputs['safe-literal']
assert inputs['minimized-fixed']['src/utils.ts']==b''.join(inputs['full-fixed']['src/utils.ts'].splitlines(keepends=True)[150:157])
assert len(set(i['tree_sha256'] for i in m['inputs']))==7
assert inputs['full-vulnerable']['src/server.ts']==inputs['full-fixed']['src/server.ts']
assert len([i for i in m['inputs'] if i['proposed_label']=='vulnerable'])==3
print('PASS: seven complete inventories and trees; 173 Git blob bindings; exact source copies, README notices, safe-line change, shared identifier mutations and upstream validator.')
result={'schema_version':1,'recorded_at_utc':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),'status':'source_preparation_verified_local_gate_pending','manifest_sha256':digest((root/'tests/evals/phase23/manifest.json').read_bytes()),'source_checks':{'result':'passed','input_count':7,'upstream_file_count':173,'independent_advisory_count':1,'git_blob_sha1_verification':True,'full_sha256_inventory_verification':True,'complete_nontruncated_git_trees':True,'annotated_tag_resolution':True,'package_version_bindings':True,'exact_convenience_copies':True,'retained_readme_licenses':True,'one_line_safe_control':True,'same_identifier_map_on_both_parents':True,'fixed_validator_copied_byte_for_byte':True},'focused_checks':{'maintenance_and_archive':'41 passed, 7 deselected; ../intake-and-archive-checks.log','new_preparation':'7 passed; preparation-tests.log','ruff':'passed for helper and affected tests','mypy':'configured full invocation passed in make check; limited positional invocation below was invalid','docs':'passed; ../intake-docs-check-approved.log'},'full_local_gate':{'status':'running','log':'artifacts/phase23/preparation-make-check.log'},'failures_retained':[{'action':'initial gh advisory fetch','result':'error connecting to api.github.com; sandbox network blocked','resolution':'read-only retrieval succeeded after sandbox escalation'},{'action':'initial make docs-check','result':'uv cache Operation not permitted','evidence':'artifacts/phase23/intake-docs-check.log','resolution':'approved cache access; docs passed in intake-docs-check-approved.log'},{'action':'commit-addressed Git tree identity assertion','result':'AssertionError: commit tree SHA differed from echoed commit-addressed tree response SHA; stopped before source generation','evidence':['provenance/vulnerable-tree-by-commit.json','provenance/fixed-tree-by-commit.json'],'resolution':'fetched exact commit-referenced tree objects, verified all blobs and asserted tree identity'},{'action':'existing maintenance form test','result':'failed old expectation of empty contact links; also retained old 11-rule assumptions','evidence':'artifacts/phase23/intake-form-check-before.log','resolution':'updated the affected test for approved form changes and canonical catalog; 41 focused checks passed'},{'action':'initial new-test Ruff check','result':'two RUF043 regex strings required raw literals','resolution':'made both intended regex strings raw; Ruff and focused tests passed'},{'action':'limited positional mypy invocation','result':'import-untyped: sentinel.owasp_mapping not included as source in the limited invocation','resolution':'configured full mypy invocation in make check discovers src and passed; no suppression or source change'}],'adopted_path_note':'The approved patch spells .github/PULL_REQUEST_TEMPLATE.md; this case-insensitive checkout maps it to the existing tracked .github/pull_request_template.md. Actual tracked lowercase path is preserved. Applied bytes match the approved hash.','bound_files':{str(f.relative_to(root)):digest(f.read_bytes()) for f in [root/'scripts/phase23_regression.py',root/'tests/test_phase23.py',root/'tests/test_maintenance.py',p/'README.md',p/'freeze-proposal.json']},'scans':0,'advisory_target_executions':0,'paid_calls':0,'freeze_approved':False,'hosted_checks':'not dispatched'}
(p/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
