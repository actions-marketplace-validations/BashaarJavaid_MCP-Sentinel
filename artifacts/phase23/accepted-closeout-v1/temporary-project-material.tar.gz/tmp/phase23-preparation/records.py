import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo
from scripts.phase20_corpus import digest

root=Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
p=root/'artifacts/phase23'
now=datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def write(name,value):
 path=p/name
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(value,indent=2)+'\n')
a=json.loads((p/'intake-adoption.json').read_text())
local=datetime.fromisoformat(a['recorded_at_utc'].replace('Z','+00:00')).astimezone(ZoneInfo('America/Los_Angeles'))
next_review=local.replace(hour=9,minute=0,second=0,microsecond=0)+timedelta(days=(0-local.weekday())%7)
if next_review<=local:next_review+=timedelta(days=7)
weekly=json.loads((p/'intake-review-v1/weekly-review-template.json').read_text())
weekly.update({'status':'scheduled','scheduled_local':next_review.replace(tzinfo=None).isoformat(),'scheduled_at_utc':next_review.astimezone(timezone.utc).isoformat().replace('+00:00','Z')})
write('weekly/2026-09-21.json',weekly)
record=json.loads((p/'intake-review-v1/lifecycle-template.json').read_text())
record['status']='source_review_pending'
record['advisory']['published_at_utc']=json.loads((p/'source-review-v1/provenance/advisory.json').read_text())['published_at']
record['advisory']['publication_evidence']=['artifacts/phase23/source-review-v1/provenance/advisory.json']
record['intake']['recorded_at_utc']=now
record['intake']['evidence']=['Conversation: user supplied the Phase 23 implementation plan naming this advisory; exact message receipt time is unavailable.']
record['source_rights'].update({'status':'explicit_license_identified_pending_human_review','license':'MIT permission text in each upstream README','evidence':['artifacts/phase23/source-review-v1/source/vulnerable/README.md','artifacts/phase23/source-review-v1/source/fixed/README.md']})
record['identities']['corpus_version']='phase23-ghsa-5w57-v1-proposed'
record['identities']['manifest_sha256']=digest((root/'tests/evals/phase23/manifest.json').read_bytes())
record['identities']['helper_sha256']=digest((root/'scripts/phase23_regression.py').read_bytes())
record['milestones']=[{'event':event,'occurred_at_utc':now,'recorded_at_utc':now,'actor':'Codex','status':'completed_source_only','evidence':['artifacts/phase23/source-review-v1/README.md','tests/evals/phase23/manifest.json'],'identities':{'manifest_sha256':record['identities']['manifest_sha256']}} for event in ['triage','source_reproduction_prepared']]
# These are preparation milestones, not observed detector reproduction, human
# label acceptance, fix verification or publication.
write('lifecycle/ghsa-5w57-v1-source-preparation.json',record)
review={'schema_version':1,'status':'pending_user_review','recorded_at_utc':now,'approval':None,'manifest':{'path':'tests/evals/phase23/manifest.json','sha256':record['identities']['manifest_sha256']},'decision_scope':['seven exact source inputs','minimization and identifier transformations','proposed source labels','source-matched finding conditions','negative support conditions','ordered input sequence','freeze these source bytes'], 'does_not_authorize':['baseline or candidate scanning','volatile exclusions','detector correction','merge','tag','publication','release version selection'],'review_documents':{str(f.relative_to(root)):digest(f.read_bytes()) for f in sorted((p/'source-review-v1').glob('*.patch'))},'summary_sha256':digest((p/'source-review-v1/README.md').read_bytes())}
write('source-review-v1/freeze-proposal.json',review)
print('Actual source-preparation milestones recorded; first weekly slot:',weekly['scheduled_local'],weekly['timezone'])
